package com.faceId;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.faceId.util.BaseActivity;

/*
 * This is the splashscreen  
 */

public class SplashActivity extends BaseActivity {
	
	private String indicator_num;
	private String user_id;
	private String is_model_created, has_faceid;
	private String has_completed_tag, account_type="";


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.splash);
		
		new Handler().postDelayed(new Runnable() {
			
			@Override
			public void run() {
				getPref_indicator();
				if (!user_id.equalsIgnoreCase("")) {

					if(!has_completed_tag.equalsIgnoreCase("yes")&&account_type.equalsIgnoreCase("individual")&&!has_faceid.equalsIgnoreCase("yes")){
						startActivity(new Intent(SplashActivity.this , MemberIdActivity.class));
						finish();
						overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
					}
					else if (!has_completed_tag.equalsIgnoreCase("yes")&&account_type.equalsIgnoreCase("individual")) {
						startActivity(new Intent(SplashActivity.this , CreateModelActivityFromCamera.class));
						finish();
						overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
					}else {
						startActivity(new Intent(SplashActivity.this , MemberIdActivity.class));
						finish();
						overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
					}
				} else {
					startActivity(new Intent(SplashActivity.this , LoginActivity.class));
					finish();
					overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
				}


			}
		}, 2000);
	}
	
	public void getPref_indicator() {
		SharedPreferences shre = PreferenceManager.getDefaultSharedPreferences(this);
		indicator_num = shre.getString("indicator_num", "");
		user_id = shre.getString("user_id", "");
		is_model_created = shre.getString("is_model_created", "");
		has_faceid = shre.getString("has_faceid", "");
		has_completed_tag = shre.getString("hasCompletedTag", "");
		account_type = shre.getString("accountType", "");
		Log.e("abcd", "indicator_num" + indicator_num);
	}
}
