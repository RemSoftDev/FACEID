package com.faceId;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.hardware.Camera;
import android.hardware.Camera.CameraInfo;
import android.hardware.Camera.PictureCallback;
import android.media.CamcorderProfile;
import android.media.MediaMetadataRetriever;
import android.media.MediaRecorder;
import android.media.session.MediaSession;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import com.faceId.crashreport.ExceptionHandler;
import com.faceId.customprogressbar.ProgressWheel;
import com.faceId.scan.CDrawer;
import com.faceId.scan.CSampler;
import com.faceId.util.BaseActivity;
import com.faceId.util.MyConstant;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.ByteArrayBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Formatter;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

/*
 * This class is for registration phase
 *  Here all 8 models get created
 */

public class CreateModelActivityFromCamera extends BaseActivity {

	private Camera mCamera;

	private CameraPreview mPreview;
	private PictureCallback mPicture;
	Camera.AutoFocusCallback mAutoFocusCallback1;
	private Context myContext;
	private FrameLayout cameraPreview, fram_bg;
	RelativeLayout rl_bg;
	private boolean cameraFront = false;

	private CDrawer.CDrawThread mDrawThread;
	private CDrawer mdrawer;

	private View.OnClickListener listener;
	private Boolean m_bStart = Boolean.valueOf(false);
	private Boolean recording = false;
	private CSampler sampler;

	ImageView sliding_image_reg, changeCamera_iv, back_iv;
	Animation animationSlideDownIn, animationSlideDownOut;
	ImageView curSlidingImage;
	TextView scan_time_tv;
	Button scane;
	int count = 0;
	private boolean isBottom = true;
	boolean running = false;
	int progress = 0;
	boolean isNetworkAvailable = false;
	ProgressWheel pw_two;
	String model_id, filePath, face_response, face_model_response, member_id, trader_name, status, model_id_face, modality;
	ArrayList<String> filePathArray;
	ArrayList<String> base64Array;
	byte[] image1, image2, image3, image4, image5;
	InputStream inputStream;
	String encodedString = "", encodedString1 = "";
	byte[] bytes;
	byte[] buffer = new byte[8192];
	int bytesRead;
	boolean isFront = true;
	Bitmap rotatedBitmap;
	// ProgressDialog pDialog;
	boolean isCapture = false;
	ArrayList<Long> file_size;
	ArrayList<Integer> image_res, int_height, int_width;
	String status_response;
	byte[] bArray;
	ArrayList<byte[]> bARRAY;
	String binary, faces_faces = null;
	JSONArray errors, faces = null;
	String score;
	String message;
	private boolean isApiCalling = false;
	ArrayList<String> score_face_array;
	String face_max_value;
	String stream_res;
	private String stream_id;
	String closed;
	int temp_count;
	int api_temp_count;
	String authenticated;
	private String thoreshold;

	Timer timer;
	TimerTask timerTask;
	final Handler handler = new Handler();

	// Chronometer chronometer;
	String base64_time, frams_time, service_time;
	int total_count;
	int img_sent_count;
	Dialog dialog;
	boolean visible = true;
	private String identities_id;
	private MediaRecorder mediaRecorder;
	private ArrayList<Bitmap> bit_array = new ArrayList<Bitmap>();
	int status_code;
	int api_count = 0;
	ArrayList<String> model_array = new ArrayList<String>();
	String created_identity_id;
	TextView start_scann_tv;
	TextView indicator_tv;

	// viewflipper for slide animation
	ViewFlipper flipper;
	TextView hint_tv;
	TextView done_tv;
	ImageView accept_iv;

	// viewflipper for indicator
	ViewFlipper flipper_top;
	TextView ind_1, ind_2, ind_3;
	TextView ind_11, ind_21, ind_31;

	TextView strok_1, strok_2, strok_3, strok_4, strok_11, strok_21, strok_31, strok_41;
	boolean isTimerCalling = false;
	String indicator_num = "0";
	private String user_id;
	private String model_created;
	int model_array_size;
	String model_no = "";
	String identity_id;
	RelativeLayout congo_rl , congo_rl_second;
	TextView skip_tv , skip_tv_second;
	RelativeLayout reg_fl;
	ArrayList<String> hint_array = new ArrayList<String>();

	// Strings were here
	private boolean isDone = false;
	private String created_nb_faces, created_model_id, user_id_login, old_model_deleted;
	private boolean isBack = false;
	private ProgressDialog pDialog;
	private boolean isWrong = false;

	private String modelTodelete;

	protected boolean isBack_reg = false;
	private String image_str;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.reg_with_camera);
		Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(this));
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		myContext = this;

		initialize();

		String s1 = getString(R.string.bioString1);
		String s2 = getString(R.string.bioString2);
		String s3 = getString(R.string.bioString3);
		String s4 = getString(R.string.bioString4);
		String s5 = getString(R.string.bioString5);
		String s6 = getString(R.string.bioString6);
		String s7 = getString(R.string.bioString7);
		String s8 = getString(R.string.bioString8);

		hint_array.add(s1);
		hint_array.add(s2);
		hint_array.add(s3);
		hint_array.add(s4);
		hint_array.add(s5);
		hint_array.add(s6);
		hint_array.add(s7);
		hint_array.add(s8);

		filePathArray = new ArrayList<String>();
		base64Array = new ArrayList<String>();
		animationSlideDownIn = AnimationUtils.loadAnimation(this, R.anim.slidedown_in);
		animationSlideDownOut = AnimationUtils.loadAnimation(this, R.anim.slidedown_out);
		curSlidingImage = sliding_image_reg;

		changeCamera_iv.setClickable(true);
		animationSlideDownIn.setAnimationListener(animationSlideInListener);
		animationSlideDownOut.setAnimationListener(animationSlideOutListener);
		getPref_user_id();
		getPref_indicator();
		model_no = getIntent().getStringExtra("model_no");
		identity_id = getIntent().getStringExtra("identity_id");
		modelTodelete = getIntent().getStringExtra("modelTodelete");

		if (model_no != null) {
			api_count = Integer.parseInt(model_no);
		}

		if (indicator_num.equalsIgnoreCase("") && model_no == null) {
			api_count = 0;
			congo_rl.setVisibility(View.VISIBLE);
			reg_fl.setVisibility(View.INVISIBLE);
		} else if (!indicator_num.equalsIgnoreCase("")) {
			api_count = Integer.parseInt(indicator_num);
		}


		if (api_count == 0)
		{

			if (model_no != null) {
				strok_1.setVisibility(View.INVISIBLE);
				ind_1.setVisibility(View.INVISIBLE);
				strok_11.setVisibility(View.INVISIBLE);
				ind_11.setVisibility(View.INVISIBLE);
				strok_2.setVisibility(View.INVISIBLE);
				strok_21.setVisibility(View.INVISIBLE);

				congo_rl.setVisibility(View.INVISIBLE);
				reg_fl.setVisibility(View.VISIBLE);

			} else
			{

				strok_1.setVisibility(View.INVISIBLE);
				strok_2.setVisibility(View.INVISIBLE);
				hint_tv.setText(hint_array.get(api_count));
				strok_11.setVisibility(View.INVISIBLE);
				strok_21.setVisibility(View.INVISIBLE);

				ind_1.setVisibility(View.INVISIBLE);
				ind_11.setVisibility(View.INVISIBLE);

				congo_rl.setVisibility(View.VISIBLE);
				reg_fl.setVisibility(View.INVISIBLE);
			}

			hint_tv.setText(hint_array.get(api_count));

			ind_2.setText(String.valueOf(api_count + 1));
			ind_3.setText(String.valueOf(api_count + 2));

		} else if (api_count == 7) {

			ind_3.setVisibility(View.INVISIBLE);
			ind_31.setVisibility(View.INVISIBLE);
			hint_tv.setText(hint_array.get(api_count));
			strok_3.setVisibility(View.INVISIBLE);
			strok_31.setVisibility(View.INVISIBLE);

			strok_4.setVisibility(View.INVISIBLE);
			strok_41.setVisibility(View.INVISIBLE);

			ind_1.setText(String.valueOf(api_count));
			ind_2.setText(String.valueOf(api_count + 1));
		} else {

			ind_1.setVisibility(View.VISIBLE);
			ind_2.setVisibility(View.VISIBLE);
			ind_3.setVisibility(View.VISIBLE);
			ind_11.setVisibility(View.VISIBLE);
			ind_21.setVisibility(View.VISIBLE);
			ind_31.setVisibility(View.VISIBLE);
			strok_1.setVisibility(View.VISIBLE);
			strok_2.setVisibility(View.VISIBLE);
			strok_3.setVisibility(View.VISIBLE);
			strok_11.setVisibility(View.VISIBLE);
			strok_21.setVisibility(View.VISIBLE);
			strok_31.setVisibility(View.VISIBLE);

			ind_1.setText(String.valueOf(api_count));
			ind_2.setText(String.valueOf(api_count + 1));
			ind_3.setText(String.valueOf(api_count + 2));

			hint_tv.setText(hint_array.get(api_count));

			ind_11.setText(String.valueOf(api_count));
			ind_21.setText(String.valueOf(api_count + 1));
			ind_31.setText(String.valueOf(api_count + 2));

		}

		skip_tv.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				strok_1.setVisibility(View.INVISIBLE);
				strok_2.setVisibility(View.INVISIBLE);
				hint_tv.setText(hint_array.get(api_count));
				strok_11.setVisibility(View.INVISIBLE);
				strok_21.setVisibility(View.INVISIBLE);

				ind_1.setVisibility(View.INVISIBLE);
				ind_11.setVisibility(View.INVISIBLE);

				congo_rl.setVisibility(View.INVISIBLE);
				congo_rl_second.setVisibility(View.VISIBLE);
				reg_fl.setVisibility(View.INVISIBLE);
				isBack_reg = true;
			}
		});

		skip_tv_second.setOnClickListener(new  OnClickListener() {

			@Override
			public void onClick(View v) {
				strok_1.setVisibility(View.INVISIBLE);
				strok_2.setVisibility(View.INVISIBLE);
				hint_tv.setText(hint_array.get(api_count));
				strok_11.setVisibility(View.INVISIBLE);
				strok_21.setVisibility(View.INVISIBLE);

				ind_1.setVisibility(View.INVISIBLE);
				ind_11.setVisibility(View.INVISIBLE);

				congo_rl.setVisibility(View.INVISIBLE);
				congo_rl_second.setVisibility(View.INVISIBLE);
				reg_fl.setVisibility(View.VISIBLE);
				isBack_reg = false;
			}
		});
	}

	// slide animation methods in out

	private Animation inFromRightAnimation() {

		Animation inFromRight = new TranslateAnimation(
				Animation.RELATIVE_TO_PARENT, +1.0f,
				Animation.RELATIVE_TO_PARENT, 0.0f,
				Animation.RELATIVE_TO_PARENT, 0.0f,
				Animation.RELATIVE_TO_PARENT, 0.0f);
		inFromRight.setDuration(500);
		inFromRight.setInterpolator(new AccelerateInterpolator());

		Log.v("anim", "animat_log" + inFromRight);

		return inFromRight;
	}

	private Animation inFromRightAnimation1() {

		Animation inFromRight = new TranslateAnimation(
				Animation.RELATIVE_TO_PARENT, +1.0f,
				Animation.RELATIVE_TO_PARENT, 0.0f,
				Animation.RELATIVE_TO_PARENT, 0.0f,
				Animation.RELATIVE_TO_PARENT, 0.0f);
		inFromRight.setDuration(500);
		inFromRight.setInterpolator(new AccelerateInterpolator());

		Log.v("anim", "animat_log" + inFromRight);

		inFromRight.setAnimationListener(new AnimationListener() {

			@Override
			public void onAnimationStart(Animation animation) {
				// TODO Auto-generated method stub
				if (api_count < 7) {
					strok_1.setVisibility(View.VISIBLE);
					strok_2.setVisibility(View.VISIBLE);
					strok_11.setVisibility(View.VISIBLE);
					strok_21.setVisibility(View.VISIBLE);
					ind_1.setVisibility(View.VISIBLE);
					ind_11.setVisibility(View.VISIBLE);

					ind_1.setText(String.valueOf(api_count));
					ind_2.setText(String.valueOf(api_count + 1));
					ind_3.setText(String.valueOf(api_count + 2));

					hint_tv.setText(hint_array.get(api_count));

					ind_11.setText(String.valueOf(api_count));
					ind_21.setText(String.valueOf(api_count + 1));
					ind_31.setText(String.valueOf(api_count + 2));

				} else if (api_count == 7) {
					strok_3.setVisibility(View.INVISIBLE);
					strok_4.setVisibility(View.INVISIBLE);
					strok_31.setVisibility(View.INVISIBLE);
					strok_41.setVisibility(View.INVISIBLE);
					ind_3.setVisibility(View.INVISIBLE);
					ind_1.setText(api_count + "");
					ind_2.setText(api_count + 1 + "");

					hint_tv.setText(hint_array.get(api_count));

					ind_31.setVisibility(View.INVISIBLE);
					ind_11.setText(api_count + "");
					ind_21.setText(api_count + 1 + "");
					// ind_3.setText(api_count+2+"");

				}

				if (api_count == 0) {

					if (model_no != null) {
						strok_1.setVisibility(View.INVISIBLE);
						ind_1.setVisibility(View.INVISIBLE);
						strok_11.setVisibility(View.INVISIBLE);
						ind_11.setVisibility(View.INVISIBLE);
						strok_2.setVisibility(View.INVISIBLE);
						strok_21.setVisibility(View.INVISIBLE);

						congo_rl.setVisibility(View.INVISIBLE);
						reg_fl.setVisibility(View.VISIBLE);

					} else {

						strok_1.setVisibility(View.INVISIBLE);
						strok_2.setVisibility(View.INVISIBLE);
						hint_tv.setText(hint_array.get(api_count));
						strok_11.setVisibility(View.INVISIBLE);
						strok_21.setVisibility(View.INVISIBLE);

						ind_1.setVisibility(View.INVISIBLE);
						ind_11.setVisibility(View.INVISIBLE);

						if (isWrong) {
							congo_rl.setVisibility(View.INVISIBLE);
							reg_fl.setVisibility(View.VISIBLE);
						} else {

							congo_rl.setVisibility(View.VISIBLE);
							reg_fl.setVisibility(View.INVISIBLE);
						}
					}


					hint_tv.setText(hint_array.get(api_count));
					ind_2.setText(String.valueOf(api_count + 1));
					ind_3.setText(String.valueOf(api_count + 2));

				}

			}

			@Override
			public void onAnimationRepeat(Animation animation) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onAnimationEnd(Animation animation) {

			}
		});

		return inFromRight;
	}

	private Animation outToLeftAnimation() {
		Animation outtoLeft = new TranslateAnimation(
				Animation.RELATIVE_TO_PARENT, 0.0f,
				Animation.RELATIVE_TO_PARENT, -1.0f,
				Animation.RELATIVE_TO_PARENT, 0.0f,
				Animation.RELATIVE_TO_PARENT, 0.0f);
		outtoLeft.setDuration(500);
		outtoLeft.setInterpolator(new AccelerateInterpolator());

		outtoLeft.setAnimationListener(new AnimationListener() {

			@Override
			public void onAnimationStart(Animation animation) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onAnimationRepeat(Animation animation) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onAnimationEnd(Animation animation) {
				Log.v("anim", "animat_log_end" + "in Enddddd");

				pw_two.setVisibility(View.VISIBLE);
				// scan_time_tv.setVisibility(View.VISIBLE);
				ShowProgress();
			}
		});

		return outtoLeft;
	}

	private Animation outToLeftAnimation1() {
		Animation outtoLeft = new TranslateAnimation(
				Animation.RELATIVE_TO_PARENT, 0.0f,
				Animation.RELATIVE_TO_PARENT, -1.0f,
				Animation.RELATIVE_TO_PARENT, 0.0f,
				Animation.RELATIVE_TO_PARENT, 0.0f);
		outtoLeft.setDuration(500);
		outtoLeft.setInterpolator(new AccelerateInterpolator());

		return outtoLeft;
	}

	private Animation outToLeftAnimation2() {
		Animation outtoLeft = new TranslateAnimation(
				Animation.RELATIVE_TO_PARENT, 0.0f,
				Animation.RELATIVE_TO_PARENT, -1.0f,
				Animation.RELATIVE_TO_PARENT, 0.0f,
				Animation.RELATIVE_TO_PARENT, 0.0f);

		outtoLeft.setDuration(500);
		outtoLeft.setInterpolator(new AccelerateInterpolator());

		return outtoLeft;
	}

	private Animation outToRightAnimation() {

		Animation inFromRight = new TranslateAnimation(
				Animation.RELATIVE_TO_PARENT, 0.0f,
				Animation.RELATIVE_TO_PARENT, +1.0f,
				Animation.RELATIVE_TO_PARENT, 0.0f,
				Animation.RELATIVE_TO_PARENT, 0.0f);
		inFromRight.setDuration(500);
		inFromRight.setInterpolator(new AccelerateInterpolator());

		Log.v("anim", "animat_log" + inFromRight);

		return inFromRight;
	}

	private Animation inFromLeftAnimation() {
		Animation outtoLeft = new TranslateAnimation(
				Animation.RELATIVE_TO_PARENT, -1.0f,
				Animation.RELATIVE_TO_PARENT, 0.0f,
				Animation.RELATIVE_TO_PARENT, 0.0f,
				Animation.RELATIVE_TO_PARENT, 0.0f);
		outtoLeft.setDuration(500);
		outtoLeft.setInterpolator(new AccelerateInterpolator());

		outtoLeft.setAnimationListener(new AnimationListener() {

			@Override
			public void onAnimationStart(Animation animation) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onAnimationRepeat(Animation animation) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onAnimationEnd(Animation animation) {
				Log.v("anim", "animat_log_end" + "in Enddddd");

				pw_two.setVisibility(View.VISIBLE);
				// scan_time_tv.setVisibility(View.VISIBLE);
				ShowProgress();
			}
		});

		return outtoLeft;
	}

	public void initialize() {

		reg_fl = (RelativeLayout) findViewById(R.id.reg_fl);
		congo_rl = (RelativeLayout) findViewById(R.id.congo_rl);
		congo_rl_second = (RelativeLayout) findViewById(R.id.congo_rl_second);
		skip_tv = (TextView) findViewById(R.id.skip_tv);
		skip_tv_second = (TextView) findViewById(R.id.skip_tv_second);
		sliding_image_reg = (ImageView) findViewById(R.id.slider_iv_reg);
		scan_time_tv = (TextView) findViewById(R.id.scan_time_tv);
		fram_bg = (FrameLayout) findViewById(R.id.fram_bg);
		indicator_tv = (TextView) findViewById(R.id.indicator_tv);
		start_scann_tv = (TextView) findViewById(R.id.start_scann_tv);
		// init flipper
		flipper = (ViewFlipper) findViewById(R.id.flipper);
		done_tv = (TextView) findViewById(R.id.done_tv);
		accept_iv = (ImageView) findViewById(R.id.accept_iv);

		flipper_top = (ViewFlipper) findViewById(R.id.flipper_top);
		ind_1 = (TextView) findViewById(R.id.ind_1);
		ind_2 = (TextView) findViewById(R.id.ind_2);
		ind_3 = (TextView) findViewById(R.id.ind_3);

		ind_11 = (TextView) findViewById(R.id.ind_11);
		ind_21 = (TextView) findViewById(R.id.ind_21);
		ind_31 = (TextView) findViewById(R.id.ind_31);

		strok_1 = (TextView) findViewById(R.id.strok_1);
		strok_2 = (TextView) findViewById(R.id.strok_2);
		strok_3 = (TextView) findViewById(R.id.strok_3);
		strok_4 = (TextView) findViewById(R.id.strok_4);

		strok_11 = (TextView) findViewById(R.id.strok_11);
		strok_21 = (TextView) findViewById(R.id.strok_21);
		strok_31 = (TextView) findViewById(R.id.strok_31);
		strok_41 = (TextView) findViewById(R.id.strok_41);

		cameraPreview = (FrameLayout) findViewById(R.id.camera_preview);
		mPreview = new CameraPreview(myContext, mCamera);
		cameraPreview.addView(mPreview);

		pw_two = (ProgressWheel) findViewById(R.id.progressBarTwo);

		changeCamera_iv = (ImageView) findViewById(R.id.changeCamera_iv);
		changeCamera_iv.setOnClickListener(switchCameraListener);

		pw_two.setVisibility(View.INVISIBLE);
		// scan_time_tv.setVisibility(View.INVISIBLE);

		hint_tv = (TextView) findViewById(R.id.hint_tv);
		back_iv = (ImageView) findViewById(R.id.back_iv);
		start_scann_tv.setOnClickListener(scanClickListner);
		back_iv.setOnClickListener(backClickListner);
		done_tv.setOnClickListener(doneClickListner);
		accept_iv.setOnClickListener(scanClickListner);
	}

	AnimationListener animationSlideInListener = new AnimationListener() {

		@Override
		public void onAnimationEnd(Animation arg0) {
			if (curSlidingImage == sliding_image_reg) {
				if (!isDone) {
					sliding_image_reg.startAnimation(animationSlideDownOut);
				}
			}
		}

		@Override
		public void onAnimationRepeat(Animation animation) {
		}

		@Override
		public void onAnimationStart(Animation animation) {
		}
	};

	AnimationListener animationSlideOutListener = new AnimationListener() {

		@Override
		public void onAnimationEnd(Animation animation) {
			if (curSlidingImage == sliding_image_reg) {
				curSlidingImage = sliding_image_reg;
				if (!isDone) {
					sliding_image_reg.startAnimation(animationSlideDownIn);
				}
			}
		}

		@Override
		public void onAnimationRepeat(Animation animation) {
		}

		@Override
		public void onAnimationStart(Animation animation) {
		}
	};

	OnClickListener switchCameraListener = new OnClickListener() {
		@Override
		public void onClick(View v) {
			@SuppressWarnings("deprecation")
			int camerasNumber = Camera.getNumberOfCameras();
			if (camerasNumber > 1) {
				releaseCamera();
				chooseCamera();
			} else {
				Toast toast = Toast.makeText(myContext,
						"Sorry, your phone has only one camera!",
						Toast.LENGTH_LONG);
				toast.show();
			}
		}
	};

	OnClickListener backClickListner = new OnClickListener() {

		@Override
		public void onClick(View v) {
			if (isBack_reg) {
				congo_rl.setVisibility(View.VISIBLE);
				congo_rl_second.setVisibility(View.INVISIBLE);
			} else {

			}
		}
	};

	OnClickListener doneClickListner = new OnClickListener() {

		@Override
		public void onClick(View v) {
			if (model_no != null) {

				if (isWrong == false)
				{
					pDialog = ProgressDialog.show(
							CreateModelActivityFromCamera.this, "", "Please Wait");
					if (Integer.parseInt(created_nb_faces) <= 4 || isWrong == true) {
						Toast.makeText(CreateModelActivityFromCamera.this,"Model consists of less than 4 faces",Toast.LENGTH_SHORT).show();

						isBack = true;

						api_count = api_count - 1;

						accept_iv.setVisibility(View.INVISIBLE);
						done_tv.setVisibility(View.INVISIBLE);

						flipper.setInAnimation(inFromRightAnimation());
						flipper.setOutAnimation(outToLeftAnimation1());
						flipper.showNext();

						flipper_top.setInAnimation(inFromRightAnimation1());
						flipper_top.setOutAnimation(outToLeftAnimation2());
						flipper_top.showNext();

					} else {
						model_array.add(created_model_id);
						//new DeleteModelFromIdentity_Api().execute();
						SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(CreateModelActivityFromCamera.this);
						Editor edit = pref.edit();
						edit.putString("indicator_num", "");
						edit.commit();
					}
				} else {

					Toast.makeText(CreateModelActivityFromCamera.this,	"No face detected.  Please try again.",	Toast.LENGTH_SHORT).show();

					isBack = true;

					api_count = api_count - 1;

					accept_iv.setVisibility(View.INVISIBLE);
					done_tv.setVisibility(View.INVISIBLE);

					flipper.setInAnimation(inFromRightAnimation());
					flipper.setOutAnimation(outToLeftAnimation1());
					flipper.showNext();

					flipper_top.setInAnimation(inFromRightAnimation1());
					flipper_top.setOutAnimation(outToLeftAnimation2());
					flipper_top.showNext();

				}
				pDialog.dismiss();
			} else {
				pDialog = ProgressDialog.show(CreateModelActivityFromCamera.this, "", "Please Wait");
				if (isWrong == false) {

					if (Integer.parseInt(created_nb_faces) <= 4) {
						Toast.makeText(CreateModelActivityFromCamera.this,	"Model consists of less than 4 faces",	Toast.LENGTH_SHORT).show();

						isBack = true;

						api_count = api_count - 1;

						accept_iv.setVisibility(View.INVISIBLE);
						done_tv.setVisibility(View.INVISIBLE);

						flipper.setInAnimation(inFromRightAnimation());
						flipper.setOutAnimation(outToLeftAnimation1());
						flipper.showNext();

						flipper_top.setInAnimation(inFromRightAnimation1());
						flipper_top.setOutAnimation(outToLeftAnimation2());
						flipper_top.showNext();

					} else {
						Toast.makeText(getApplicationContext(), "Model Created", Toast.LENGTH_LONG)
								.show();
						//getModel();
						Log.i("chirag", "model_test_created" + " " + model_created);
						if (model_created != "") {
							String[] temp_str = model_created.split(",");
							for (int i = 0; i < temp_str.length; i++) {
								model_array.add(temp_str[i]);
							}
							model_array.add(created_model_id);
							SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(CreateModelActivityFromCamera.this);
							Editor edit = pref.edit();
							edit.putString("models_created", "");
							edit.commit();
							Log.i("chirag", "model_test_created_deleted" + " "
									+ model_created);

							Log.i("created_model",
									"model_test_created_model_array_if_created "
											+ model_array.size() + " "
											+ created_model_id);

						} else {
							model_array.add(created_model_id);
							Log.i("created_model",
									"model_test_created_model_array_if_not_created"
											+ model_array.size() + " "
											+ created_model_id);

							Log.i("created_model",
									"creadted_model " + model_array.size());
						}

						accept_iv.setVisibility(View.INVISIBLE);
						done_tv.setVisibility(View.INVISIBLE);

						flipper.setInAnimation(inFromRightAnimation());
						flipper.setOutAnimation(outToLeftAnimation1());
						flipper.showNext();

						flipper_top.setInAnimation(inFromRightAnimation1());
						flipper_top.setOutAnimation(outToLeftAnimation2());
						flipper_top.showNext();
					}
				} else {
					Toast.makeText(CreateModelActivityFromCamera.this,	"No face detected.  Please try again.",	Toast.LENGTH_SHORT).show();

					isBack = true;

					api_count = api_count - 1;

					accept_iv.setVisibility(View.INVISIBLE);
					done_tv.setVisibility(View.INVISIBLE);

					flipper.setInAnimation(inFromRightAnimation());
					flipper.setOutAnimation(outToLeftAnimation1());
					flipper.showNext();

					flipper_top.setInAnimation(inFromRightAnimation1());
					flipper_top.setOutAnimation(outToLeftAnimation2());
					flipper_top.showNext();
				}
				pDialog.dismiss();
			}

		}
	};

	OnClickListener scanClickListner = new OnClickListener() {

		@Override
		public void onClick(View v) {

			flipper.setInAnimation(inFromRightAnimation());
			flipper.setOutAnimation(outToLeftAnimation());
			flipper.showNext();
		}
	};

	private int height;

	private int width;

	@Override
	protected void onPause() {
		super.onPause();
		isTimerCalling = true;
		releaseCamera();
		progress = 361;
		pw_two.stopSpinning();
		pw_two.resetCount();

		if (api_count != 8 && model_no == null) {
			save_preference();
			model_array.clear();
		}
		if (timer != null) {
			timer.cancel();
		}

		try {
			mediaRecorder.stop(); // stop the recording
			releaseMediaRecorder(); // release the MediaRecorder object
		} catch (Exception e) {
		}
		synchronized (this) {
			try {
				wait(5000);

				runOnUiThread(new Runnable() {
					public void run() {
						sliding_image_reg.setVisibility(View.INVISIBLE);
					}
				});
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		/*if (api_count < 7) {
			int pid = android.os.Process.myPid();
			android.os.Process.killProcess(pid);
			System.exit(0);

		}*/
	}

	@Override
	public void onBackPressed() {

		if (isBack_reg) {
			congo_rl.setVisibility(View.VISIBLE);
			congo_rl_second.setVisibility(View.INVISIBLE);
		} else {

		}

	}

	private boolean hasCamera(Context context) {
		if (context.getPackageManager().hasSystemFeature(
				PackageManager.FEATURE_CAMERA)) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	protected void onResume() {
		super.onResume();

		if (!hasCamera(myContext)) {
			Toast toast = Toast.makeText(myContext,
					"Sorry, your phone does not have a camera!",
					Toast.LENGTH_LONG);
			toast.show();
			finish();
		}

		if (mCamera == null) {
			if (findFrontFacingCamera() < 0) {
				Toast.makeText(this, "No front facing camera found.",
						Toast.LENGTH_LONG).show();
				changeCamera_iv.setVisibility(View.GONE);
			}
			changeCamera_iv.setClickable(true);
			back_iv.setClickable(true);
			try {
				mCamera = Camera.open(findFrontFacingCamera());
				mCamera.setDisplayOrientation(90);
				mPicture = getPictureCallback();
				mPreview.refreshCamera(mCamera);

				Camera.Parameters parameters = mCamera.getParameters();
				Camera.Size size = parameters.getPictureSize();


				height = size.height;
				width = size.width;

				height=1080;
				width=720;

				float megaPix = (width * height) / 1024000 ;
				Log.i("Syso", "camera_mp"  + megaPix + " " + height + " " + width);

			} catch (Exception e) {
				// TODO: handle exception
			}

		}
	}

	private void ShowProgress() {
		api_count = api_count + 1;
		final Runnable r = new Runnable() {
			public void run() {
				running = true;
				while (progress < 361) {
					pw_two.incrementProgress();
					progress++;
					try {
						Thread.sleep(15);

					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				running = false;

				runOnUiThread(new Runnable() {
					public void run() {
						isDone = false;
						sliding_image_reg.startAnimation(animationSlideDownIn);

						sliding_image_reg.setVisibility(View.VISIBLE);
						// scan_time_tv.setVisibility(View.INVISIBLE);
						// fram_bg.setBackgroundColor(Color.TRANSPARENT);
						back_iv.setClickable(false);
						changeCamera_iv.setClickable(false);
						startTimer1();
					}
				});
			}
		};

		if (!running) {
			progress = 0;
			pw_two.resetCount();
			Thread s = new Thread(r);
			s.start();
		}

	}

	private void startTimer1() {

		if (!prepareMediaRecorder()) {
			Toast.makeText(CreateModelActivityFromCamera.this,
					"Fail in prepareMediaRecorder()!\n - Ended -",
					Toast.LENGTH_LONG).show();
			finish();
		}

		if (isTimerCalling == false) {
			// work on UiThread for better performance
			runOnUiThread(new Runnable() {
				public void run() {
					// If there are stories, add them to the table
					try {
						Thread.sleep(1500);
						mediaRecorder.start();
					} catch (final Exception ex) {
						// Log.i("---","Exception in thread");
					}
				}
			});
			recording = true;

			new Handler().postDelayed(new Runnable() {
				@Override
				public void run() {
					MyConstant.bit_array.clear();

					try {
						mediaRecorder.stop(); // stop the recording
						releaseMediaRecorder(); // release the MediaRecorder
						// object
						Thread.sleep(1000);
					} catch (Exception e) {
					}
					recording = false;
					// custom dialog
					isDone = true;
					synchronized (this) {
						try {
							wait(3000);

							runOnUiThread(new Runnable() {
								public void run() {
									sliding_image_reg
											.setVisibility(View.INVISIBLE);
								}
							});
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					}
					/*pDialog = ProgressDialog.show(CreateModelActivityFromCamera.this, "",
							"Please Wait");
					*/
					bit_array.addAll(getFrames(Environment.getExternalStorageDirectory() + "/myvideo_rec.mp4"));
					Log.i("abcd", "file_array" + bit_array.size());
					getBase64Images();

				}
			}, 6500);
		}
	}

	public void getBase64Images() {
		// chronometer.start();
		bARRAY = new ArrayList<byte[]>();
		ArrayList<String> md5_array = new ArrayList<String>();
		for (int i = 0; i < 1; i++) {
			Bitmap bm1 = bit_array.get(i);
			Bitmap bm = null;

			if (bm1 != null) {
				int currentBitmapHeight = bm1.getHeight();
				int currentBitmapWidth = bm1.getWidth();
				Log.i("System out", "Before Modification : " + bm1.getHeight()
						+ " , " + bm1.getWidth());
				bm = bm1;
			}

			if (bm != null) {
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				Log.e("file_path", "file_path_abc_baos" + baos.toString());
				// Bitmap gray_bm = toGrayscale(bm);
				if (bm.compress(Bitmap.CompressFormat.JPEG, 80, baos)) {
					MyConstant.bit_array.add(bm);
//					save_sd_base(bm);
					Log.e("file_path", "file_path_abc_bitmap" + bm);
					bArray = baos.toByteArray();
					bARRAY.add(bArray);

/*
					try {
						String str = new String(bArray, "UTF-8");
						String  md5_image = MD5_Hash(str);
						md5_array.add(md5_image);
						writeStringAsFile(md5_array.toString(), "md5_images");
					}
					catch (UnsupportedEncodingException e) { // TODO  Auto-generated
						e.printStackTrace();
					} */
					// for UTF-8 encoding
//					  }

					String encodedString = Base64.encodeToString(bArray,
							Base64.DEFAULT);

					Log.i("chika", "base64_encode" + " " + encodedString);
					base64Array.add(encodedString);
					Log.e("file_path",
							"file_path_abc_base64" + base64Array.size());

				}
			}
		}

//		writeStringAsFile(md5_array.toString(), "md5_image.txt");

		int base64_size = base64Array.size();

		filePathArray.clear();
		runOnUiThread(new Runnable() {

			@Override
			public void run() {
			}
		});
		Log.i("abcd", "array_size_base" + base64Array.size());
		bit_array.clear();
		if(api_count<=8)
			new Insert_Face_Model_Api().execute();
		//else
		//ShowProgress();

	}

	public static String MD5_Hash(String s) {
		MessageDigest m = null;

		try {
			m = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}

		m.update(s.getBytes(), 0, s.length());
		String hash = new BigInteger(1, m.digest()).toString(16);
		return hash;
	}

	public class Insert_Face_Model_Api extends AsyncTask<String, String, String> {

		@Override
		protected void onPreExecute() {

			super.onPreExecute();

			pDialog = ProgressDialog.show(CreateModelActivityFromCamera.this, "","Please Wait");
			pDialog.setCancelable(true);
			pDialog.show();
		}

		@Override
		protected String doInBackground(String... params) {

			HttpParams httpParameters = new BasicHttpParams();
			HttpConnectionParams.setConnectionTimeout(httpParameters, 10000);
			HttpConnectionParams.setSoTimeout(httpParameters, 10000);
			HttpClient httpclient = new DefaultHttpClient();
			String responseText = null;
			HttpResponse response = null;


			HttpPost httppost = new HttpPost(MyConstant.LOGIN_URL);
			String temp_str = TextUtils.join(",", model_array);

			try
			{
				JSONObject jObjImages=new JSONObject();

				JSONArray jsonArray=new JSONArray();
				String[] images;
				images=base64Array.toString().split(",");

				for(int i=0; i<1; i++){
					String a="";
					if(images[i].contains("[")){
						a=images[i].replace("[", "");
					}
					else if(images[i].contains("]")){
						a=images[i].replace("]", "");
					}else{
						a=images[i];
					}
					jsonArray.put(i,a);
				}

				//jsonArray.put(0,base64Array);
				jObjImages.put("images", jsonArray);
				jObjImages.put("user_id", user_id);
				jObjImages.put("service", "ANDROID_APP");
				Log.v("JSONOBJECT", "DATA"+jObjImages);
				String a=jObjImages.toString()+"c1IaqR8Dp7L6sLVbq5b2VlsouTN0ezNAYYnmf0WGb6zbxT7P";
				String token=encryptPassword(a);
				Log.v("Token", "Token while Identity post" + token);
				List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(4);
				nameValuePairs.add(new BasicNameValuePair("request", "registerFace"));
				nameValuePairs.add(new BasicNameValuePair("public_key", "faceid"));
				nameValuePairs.add(new BasicNameValuePair("token", token));
				nameValuePairs.add(new BasicNameValuePair("data", jObjImages.toString()));
				httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				String reqeust = MyConstant.LOGIN_URL;
				Log.v("requested URl", "reqeusted URL while Identity post:"
						+ reqeust);
				// Execute HTTP Post Request
				response = httpclient.execute(httppost);
				Log.v("Post Status", "Code: "
						+ response.getStatusLine().getStatusCode());
				HttpEntity entity = response.getEntity();
				responseText = EntityUtils.toString(entity);
				Log.v("Response", "Response while Identity post" + responseText);
				// Json Parsing

			} catch (Exception e) {
				e.printStackTrace();
				/*
				 * runOnUiThread(new Runnable() { public void run() {
				 * AlertMessage(LoginActivity.this,
				 * "Your Internet Connection is Poor"); } });
				 */

			}
			return responseText;
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			pDialog.dismiss();
			if (result != null) {
				JSONObject obj;
				//try {
				if(!result.contains("error")){
					if(api_count<8) {

						/*SharedPreferences pref = PreferenceManager
								.getDefaultSharedPreferences(CreateModelActivityFromCamera.this);
						Editor edit = pref.edit();
						edit.putString("has_model", "Yes");
						edit.commit();
						startActivity(new Intent(CreateModelActivityFromCamera.this, CreateModelActivityFromCamera.class));
						overridePendingTransition(R.anim.slide_in, R.anim.slide_out);*/
						base64Array=new ArrayList<>();
						changeCamera_iv.setClickable(true);
						accept_iv.setVisibility(View.INVISIBLE);
						done_tv.setVisibility(View.INVISIBLE);


						flipper.setInAnimation(inFromRightAnimation());
						flipper.setOutAnimation(outToLeftAnimation1());
						flipper.showNext();

						flipper_top.setInAnimation(inFromRightAnimation1());
						flipper_top.setOutAnimation(outToLeftAnimation2());
						flipper_top.showNext();

					}
					else{

						new AlertDialog.Builder(CreateModelActivityFromCamera.this)
								.setTitle("FACE.ID")
								.setMessage("Congratulations you have now completed your FACE.ID biometrics.")
								.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
									public void onClick(DialogInterface dialog, int which) {
										// continue with delete
										SharedPreferences pref = PreferenceManager
												.getDefaultSharedPreferences(CreateModelActivityFromCamera.this);
										Editor edit = pref.edit();
										edit.putString("has_model", "Yes");
										edit.putString("hasCompletedTag", "Yes");
										edit.putString("indicator_num", String.valueOf(0));
										edit.commit();
										startActivity(new Intent(CreateModelActivityFromCamera.this, MemberIdActivity.class));
										overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
										finish();
									}
								})
								.setIcon(R.drawable.ic_launcher)
								.show();

					}

				}else{
					/*Toast.makeText(CreateModelActivityFromCamera.this, "No face detected, Please try again", Toast.LENGTH_LONG).show();

					SharedPreferences pref = PreferenceManager
							.getDefaultSharedPreferences(CreateModelActivityFromCamera.this);
					Editor edit = pref.edit();
					edit.putString("has_model", "Yes");
					api_count=api_count-1;
					edit.putString("indicator_num", String.valueOf(api_count));
					edit.commit();
					startActivity(new Intent(CreateModelActivityFromCamera.this, CreateModelActivityFromCamera.class));
					overridePendingTransition(R.anim.slide_in, R.anim.slide_out);*/
					base64Array=new ArrayList<>();
					Toast.makeText(CreateModelActivityFromCamera.this,	"No face detected.  Please try again.",	Toast.LENGTH_SHORT).show();
					changeCamera_iv.setClickable(true);
					isBack = true;

					api_count = api_count - 1;
						accept_iv.setVisibility(View.INVISIBLE);
						done_tv.setVisibility(View.INVISIBLE);

						flipper.setInAnimation(inFromRightAnimation());
						flipper.setOutAnimation(outToLeftAnimation1());
						flipper.showNext();

						flipper_top.setInAnimation(inFromRightAnimation1());
						flipper_top.setOutAnimation(outToLeftAnimation2());
						flipper_top.showNext();


				}

			}else{
				changeCamera_iv.setClickable(true);
				Toast.makeText(CreateModelActivityFromCamera.this,	"No face detected.  Please try again.",	Toast.LENGTH_SHORT).show();
				base64Array=new ArrayList<>();
				isBack = true;

				api_count = api_count - 1;
				accept_iv.setVisibility(View.INVISIBLE);
				done_tv.setVisibility(View.INVISIBLE);

				flipper.setInAnimation(inFromRightAnimation());
				flipper.setOutAnimation(outToLeftAnimation1());
				flipper.showNext();

				flipper_top.setInAnimation(inFromRightAnimation1());
				flipper_top.setOutAnimation(outToLeftAnimation2());
				flipper_top.showNext();
				/*SharedPreferences pref = PreferenceManager
						.getDefaultSharedPreferences(CreateModelActivityFromCamera.this);
				Editor edit = pref.edit();
				edit.putString("has_model", "Yes");
				edit.commit();
				startActivity(new Intent(CreateModelActivityFromCamera.this, CreateModelActivityFromCamera.class));
				overridePendingTransition(R.anim.slide_in, R.anim.slide_out);*/
			}
		}
	}
	private static String encryptPassword(String password)
	{
		String sha1 = "";
		try
		{
			MessageDigest crypt = MessageDigest.getInstance("SHA-1");
			crypt.reset();
			crypt.update(password.getBytes("UTF-8"));
			sha1 = byteToHex(crypt.digest());
		}
		catch(NoSuchAlgorithmException e)
		{
			e.printStackTrace();
		}
		catch(UnsupportedEncodingException e)
		{
			e.printStackTrace();
		}
		return sha1;
	}

	private static String byteToHex(final byte[] hash)
	{
		Formatter formatter = new Formatter();
		for (byte b : hash)
		{
			formatter.format("%02x", b);
		}
		String result = formatter.toString();
		formatter.close();
		return result;
	}




	public ByteArrayBody decodeImageFile(byte[] array) {

		ByteArrayBody bArrayBody = new ByteArrayBody(array, ".jpg");

		return bArrayBody;
	}

	public MultipartEntity addToMultipart(MultipartEntity reqEntity) {

		ArrayList<ByteArrayBody> bytearraybodylist = new ArrayList<ByteArrayBody>();

		for (int i = 0; i < bARRAY.size() - 1; i++) {
			bytearraybodylist.add(decodeImageFile(bARRAY.get(i)));

		}
		String byteStr = "";

		for (int i = 0; i < bytearraybodylist.size(); i++) {
			reqEntity.addPart("faces[]", bytearraybodylist.get(i));
			Log.e("log", "log");
		}

		try {

			reqEntity.addPart("user", new StringBody("approvedid"));
			reqEntity.addPart("key", new StringBody("Ycsss77jU4UG3AURETdDmua3B3GaaxGIRJzIT1s0bqbIGLfAIn1pQ7"));

		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		bARRAY.clear();
		return reqEntity;
	}

	@SuppressLint("InlinedApi")
	private boolean prepareMediaRecorder() {

		mediaRecorder = new MediaRecorder();
		if (mCamera != null) {
			mCamera.unlock();
			mediaRecorder.setCamera(mCamera);
		}

		mediaRecorder.setAudioSource(MediaRecorder.AudioSource.CAMCORDER);
		mediaRecorder.setVideoSource(MediaRecorder.VideoSource.CAMERA);

		if (cameraFront) {
			if (height < 600 || width < 600) {
				mediaRecorder.setProfile(CamcorderProfile.get(CamcorderProfile.QUALITY_HIGH));
			} else {
				mediaRecorder.setProfile(CamcorderProfile.get(CamcorderProfile.QUALITY_480P));
			}
		} else {
			mediaRecorder.setProfile(CamcorderProfile.get(CamcorderProfile.QUALITY_480P));
		}

		mediaRecorder.setOutputFile(Environment.getExternalStorageDirectory() + "/myvideo_rec.mp4");
		mediaRecorder.setMaxDuration(600000); // Set max duration 60 sec.
		mediaRecorder.setMaxFileSize(50000000); // Set max file size 50M
		if (!isFront) {
			mediaRecorder.setOrientationHint(90);
		} else if (isFront) {
			mediaRecorder.setOrientationHint(270);
		}

		try {
			mediaRecorder.prepare();
		} catch (IllegalStateException e) {
			releaseMediaRecorder();
			return false;
		} catch (IOException e) {
			releaseMediaRecorder();
			return false;
		}
		return true;

	}

	@TargetApi(Build.VERSION_CODES.GINGERBREAD_MR1)
	private ArrayList<Bitmap> getFrames(String path) {
		try {
			ArrayList<Bitmap> bArray1 = new ArrayList<Bitmap>();
			// bArray.clear();
			MediaMetadataRetriever mRetriever = new MediaMetadataRetriever();
			mRetriever.setDataSource(path);
			// chronometer.setBase(SystemClock.elapsedRealtime());

			// chronometer.start();

			for (int i = 0; i <= 5500000; i = i + 750000) {
				Bitmap bm = mRetriever.getFrameAtTime(i,MediaMetadataRetriever.OPTION_CLOSEST);
				// save_sd(bm);
				bArray1.add(bm);
				bm = null;
			}

			// chronometer.stop();
			// frams_time = chronometer.getText().toString();
			return bArray1;
		} catch (Exception e) {
			// TODO: handle exception

			return null;

		}
	}

	private void releaseMediaRecorder() {

		if (mediaRecorder != null) {
			mediaRecorder.reset(); // clear recorder configuration
			mediaRecorder.release(); // release the recorder object
			mediaRecorder = null;
			mCamera.lock(); // lock camera for later use
		}
	}

	private void releaseCamera() {
		// stop and release camera
		if (mCamera != null) {
			mCamera.release();
			mCamera = null;
		}
	}

	public Bitmap toGrayscale(Bitmap bmpOriginal) {
		int width, height;
		height = bmpOriginal.getHeight();
		width = bmpOriginal.getWidth();

		Bitmap bmpGrayscale = Bitmap.createBitmap(width, height,
				Bitmap.Config.ARGB_8888);
		Canvas c = new Canvas(bmpGrayscale);
		Paint paint = new Paint();
		ColorMatrix cm = new ColorMatrix();
		cm.setSaturation(0);
		ColorMatrixColorFilter f = new ColorMatrixColorFilter(cm);
		paint.setColorFilter(f);
		c.drawBitmap(bmpOriginal, 0, 0, paint);
		return bmpGrayscale;
	}

	public void chooseCamera() {
		if (cameraFront) {
			int cameraId = findBackFacingCamera();
			if (cameraId >= 0) {
				mCamera = Camera.open(cameraId);

				mCamera.setDisplayOrientation(90);
				mPicture = getPictureCallback();
				mPreview.refreshCamera(mCamera);
				isFront = false;
			}
		} else {
			int cameraId = findFrontFacingCamera();
			if (cameraId >= 0) {
				mCamera = Camera.open(cameraId);
				mCamera.setDisplayOrientation(90);
				mPicture = getPictureCallback();
				mPreview.refreshCamera(mCamera);
				isFront = true;
			}
		}
	}

	private int findBackFacingCamera() {
		int cameraId = -1;
		int numberOfCameras = Camera.getNumberOfCameras();
		for (int i = 0; i < numberOfCameras; i++) {
			CameraInfo info = new CameraInfo();
			Camera.getCameraInfo(i, info);
			if (info.facing == CameraInfo.CAMERA_FACING_BACK) {
				cameraId = i;
				cameraFront = false;
				break;
			}
		}
		return cameraId;
	}

	private int findFrontFacingCamera() {
		int cameraId = -1;
		// Search for the front facing camera
		int numberOfCameras = Camera.getNumberOfCameras();
		for (int i = 0; i < numberOfCameras; i++) {
			CameraInfo info = new CameraInfo();
			Camera.getCameraInfo(i, info);
			if (info.facing == CameraInfo.CAMERA_FACING_FRONT) {
				cameraId = i;
				cameraFront = true;
				break;
			}
		}
		return cameraId;
	}

	private PictureCallback getPictureCallback() {
		PictureCallback picture = new PictureCallback() {

			@Override
			public void onPictureTaken(byte[] data, Camera camera) {
				File pictureFile = getOutputMediaFile();

				if (pictureFile == null) {
					return;
				}
				try {
					// write the file
					FileOutputStream fos = new FileOutputStream(pictureFile);

					fos.write(data);
					fos.close();

				} catch (IOException e) {

				}
				// refresh camera to continue preview
				mPreview.refreshCamera(mCamera);
			}
		};
		return picture;
	}

	public void save_preference_model_identity() {
		String models = TextUtils.join(",", model_array);
		SharedPreferences pref = PreferenceManager
				.getDefaultSharedPreferences(CreateModelActivityFromCamera.this);
		Editor edit = pref.edit();
		edit.putString("models", models);
		edit.putString("identityID", created_identity_id);
		Log.i("pref_data", "pref_data_cre" + models + " " + created_identity_id);
		edit.commit();
	}

	/*public void save_preference_model_identity_New() {
		String models = TextUtils.join(",", model_array);
		SharedPreferences pref = PreferenceManager
				.getDefaultSharedPreferences(CreateModelActivityFromCamera.this);
		Editor edit = pref.edit();
		edit.putString("identity_created", identity_id);
		Log.i("pref_data", "pref_data_cre" + models + " " + created_identity_id);
		edit.commit();
	}
*/
	// make picture and save to a folder
	private File getOutputMediaFile() {
		// make a new file directory inside the "sdcard" folder
		File mediaStorageDir = new File("/sdcard/", "JCG Camera");

		// if this "JCGCamera folder does not exist
		if (!mediaStorageDir.exists()) {
			// if you cannot make this folder return
			if (!mediaStorageDir.mkdirs()) {
				return null;
			}
		}
		// take the current timeStamp
		String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss")
				.format(new Date());
		File mediaFile;
		// and make a media file:
		mediaFile = new File(mediaStorageDir.getPath() + File.separator
				+ "IMG_" + timeStamp + ".jpg");
		filePath = mediaStorageDir.getPath() + File.separator + "IMG_"
				+ timeStamp + ".jpg";

		return mediaFile;
	}

	public void getPref_user_id() {
		SharedPreferences shre = PreferenceManager
				.getDefaultSharedPreferences(this);
		user_id = shre.getString("user_id", "");
		Log.e("abcd", "identity_created" + user_id);
	}

	public void save_preference() {
		//String temp_str = TextUtils.join(",", model_array);
		SharedPreferences pref = PreferenceManager
				.getDefaultSharedPreferences(CreateModelActivityFromCamera.this);
		Editor edit = pref.edit();
		edit.putString("indicator_num", String.valueOf(api_count));
		//edit.putString("models_created", temp_str);
		//edit.putInt("model_count", model_array.size());
		edit.commit();
	}

	/*public void getModel() {
		SharedPreferences shre = PreferenceManager
				.getDefaultSharedPreferences(this);
		model_created = shre.getString("models_created", "");
	}*/

	public void getPref_indicator() {
		SharedPreferences shre = PreferenceManager
				.getDefaultSharedPreferences(this);
		indicator_num = shre.getString("indicator_num", "");
		//model_array_size = shre.getInt("model_count", 0);
		user_id_login = shre.getString("user_id", "");
		//old_model_deleted = shre.getString("old_model_deleted", "");
		Log.e("abcd", "indicator_num" + indicator_num);
		//Log.i("created_model", "model_test_created_in_shared_pref"
		//		+ model_array_size);

	}
}
