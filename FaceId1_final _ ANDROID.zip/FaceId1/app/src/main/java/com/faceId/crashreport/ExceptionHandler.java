package com.faceId.crashreport;

import android.content.Context;
import android.os.Build;
import android.os.Process;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;

public class ExceptionHandler implements Thread.UncaughtExceptionHandler {
	private final Context myContext;
	private String localPath;
	
	String extStorageDirectory = "storage/sdcard/FaceId/FaceID.txt";
	 private File cacheDir;
	 EmailSend email = new EmailSend();
	 
	public ExceptionHandler(Context context) {
		myContext = context;
	}


	@Override
	public void uncaughtException(Thread thread, Throwable exception) {
		StringWriter stackTrace = new StringWriter();
		exception.printStackTrace(new PrintWriter(stackTrace));
		
		System.err.println(stackTrace);// You can use LogCat too
		   //Find the dir to save cached images also add permission to manifastfile 
        if (android.os.Environment.getExternalStorageState().equals(android.os.Environment.MEDIA_MOUNTED))
        {
            cacheDir=new File(android.os.Environment.getExternalStorageDirectory(),"Shenanigan");
        }
        else
            cacheDir=myContext.getCacheDir();
        if(!cacheDir.exists())
            cacheDir.mkdirs();

		    if (cacheDir != null) 
		    {		     
		    	cacheDir=new File(cacheDir,"Shenanigan.txt");
		    	writeToFile(stackTrace.toString(), cacheDir);
		    	getDeviceName();
		    	email.sendMail(myContext, "",extStorageDirectory);
		    }
		    
		Process.killProcess(Process.myPid());
		System.exit(10);
	}
	   void writeToFile(String stacktrace, File filename) {
		    try {
		    	stacktrace = stacktrace+"\n Version : 1.7\n Device :"+getDeviceName()+"\nOS : "+ Build.VERSION.RELEASE;
			      BufferedWriter bos = new BufferedWriter(new FileWriter(filename,true));
			      bos.write(stacktrace+"\n\n----------------------New Exception------------------------------\n\n");
			      bos.flush();
			      bos.close();
		    } catch (Exception e) {
		      e.printStackTrace();
		    }
		  }
	   
	   public String getDeviceName() {
		   String manufacturer = Build.MANUFACTURER;
		   String model = Build.MODEL;
		   if (model.startsWith(manufacturer)) {
		     return capitalize(model);
		   } else {
		     return capitalize(manufacturer) + " " + model;
		   }
		 }


		 private String capitalize(String s) {
		   if (s == null || s.length() == 0) {
		     return "";
		   }
		   char first = s.charAt(0);
		   if (Character.isUpperCase(first)) {
		     return s;
		   } else {
		     return Character.toUpperCase(first) + s.substring(1);
		   }
		 } 
	   
	   
	   
}