package com.faceId.util;

import org.acra.ACRA;
import org.acra.ReportField;
import org.acra.annotation.ReportsCrashes;
import org.acra.sender.HttpSender;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

@ReportsCrashes(
	     formUri = "https://{myusername}.cloudant.com/acra-{myapp}/_design/acra-storage/_update/report",
	     reportType = HttpSender.Type.JSON,
	     httpMethod = HttpSender.Method.POST,
	     formUriBasicAuthLogin = "GENERATED_USERNAME_WITH_WRITE_PERMISSIONS",
	     formUriBasicAuthPassword = "GENERATED_PASSWORD",
	     formKey = "", // This is required for backward compatibility but not used
	     customReportContent = { ReportField.ANDROID_VERSION, ReportField.PHONE_MODEL, ReportField.CUSTOM_DATA, ReportField.REPORT_ID, ReportField.BUILD, ReportField.STACK_TRACE,
	    		ReportField.LOGCAT }, mailTo = "chirag.shah@credencys.com")


public class MyApplication extends Application {

	@Override
	public void onCreate() {
		super.onCreate();
//		ACRA.init(this);
		SharedPreferences settings =
				getSharedPreferences("com.faceId", Context.MODE_PRIVATE);

		// Get the font size option.  We use "FONT_SIZE" as the key.
		// Make sure to use this key when you set the value in SharedPreferences.
		// We specify "Medium" as the default value, if it does not exist.
		Editor editor = settings.edit();
		editor.putString("FONT_SIZE", "Large");
		editor.commit();
	}
}
