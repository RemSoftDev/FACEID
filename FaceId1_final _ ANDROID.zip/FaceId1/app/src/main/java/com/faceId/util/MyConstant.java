package com.faceId.util;

import java.util.ArrayList;
import java.util.StringTokenizer;

import android.graphics.Bitmap;


public class MyConstant {
	
	/*public static String baseStr = "";
	
	public static String URL1 = "https://klws.keylemon.com/api/recognize/";
	
	public static String URL2 = "https://klws.keylemon.com/api/speaker/recognize/";
	
	public String temp = "http://approvedtrader.directory/faceid1/index.php/webservice/";
	
	public static String URL = "http://approvedtrader.directory/faceid1/index.php/webservice/login";
	
	public static String FACE_URL = "http://approvedtrader.directory/faceid1/index.php/webservice/traderInfo";

	public static String STREAM_URL = "https://klws.keylemon.com/api/stream/";

	public static String PORT_URL = "https://klws.keylemon.com/api/stream/";
	
	public static String IMAGE_URL = "https://klws.keylemon.com/api/stream/";
	
	public static String CREATE_MODEL_URL = "https://klws.keylemon.com/api/model/";
	
	public static String CREATE_IDENTITY_URL = "https://klws.keylemon.com/api/identity/";
	
	public static String LOG_SERVER_URL = "http://dev.credencys.com/testfaceid/index.php/webservice/insertRecord";
	
	public static String LOG_SERVER_URL_NEW = "http://dev.credencys.com/testfaceid/index.php/webservice/insertImages";
	
	public static String INSERT_MODEL = "http://approvedtrader.directory/faceid1/index.php/webservice/addUserModels";
	
	public static String UPDATE_MODEL = "http://approvedtrader.directory/faceid1/index.php/webservice/updateModeldata";
	
	public static ArrayList<Bitmap> bit_array = new ArrayList<Bitmap>();*/
	
	public static String baseStr = "";
	
	public static String URL1 = "https://klws.keylemon.com/api/recognize/";
	
	public static String URL2 = "https://klws.keylemon.com/api/speaker/recognize/";
	
	public String temp = "http://face.id/faceid1/index.php/webservice/";
	
	public static String URL = "https://face.id/api_faceidlogin/";

	public static String LOGIN_URL = "https://face.id/api.php";
	public static String FACE_URL_OLD = "http://face.id/faceid1/index.php/webservice/traderInfo";
	
	public static String FACE_URL = "http://face.id/faceid1/index.php/webservice/memberdetails";
	public static String FACEID_API = "https://face.id/faceidapi.php";

	public static String STREAM_URL = "https://klws.keylemon.com/api/stream/";

	public static String PORT_URL = "https://klws.keylemon.com/api/stream/";
	
	public static String IMAGE_URL = "https://klws.keylemon.com/api/stream/";
	
	public static String CREATE_MODEL_URL = "https://klws.keylemon.com/api/model/";
	
	public static String CREATE_IDENTITY_URL = "https://klws.keylemon.com/api/identity/";
	
	//public static String LOG_SERVER_URL = "http://face.id/faceid1/index.php/webservice/insertRecord";

	public static String LOG_SERVER_URL = "https://face.id/test-api.php";
	
	public static String LOG_SERVER_URL_NEW = "http://face.id/faceid1/index.php/webservice/insertImages";
	
	public static String INSERT_MODEL = "http://face.id/faceid1/index.php/webservice/addUserModels";
	
	public static String UPDATE_MODEL = "http://face.id/faceid1/index.php/webservice/updateModeldata";
	
	public static ArrayList<Bitmap> bit_array = new ArrayList<Bitmap>();
	public static int validImageCount=0;
	public static int loopCount=0;
	
}
