package com.faceId.util;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.EditText;
import android.widget.TextView;

public class TextNormal extends TextView {

	public TextNormal(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		init();
	}

	public TextNormal(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
	}

	public TextNormal(Context context) {
		super(context);
		init();
	}

	public void init() {
		if (!isInEditMode()) {
			Typeface tf = Typeface.createFromAsset(getContext().getAssets(),
					"ROBOTO-REGULAR_1.TTF");
			setTypeface(tf);
		}
	}
}
