package com.faceId.util;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.EditText;

public class EditTextNormal extends EditText {

	public EditTextNormal(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		init();
	}

	public EditTextNormal(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
	}

	public EditTextNormal(Context context) {
		super(context);
		init();
	}

	public void init() {
		if (!isInEditMode()) {
			Typeface tf = Typeface.createFromAsset(getContext().getAssets(),
					"ROBOTO-REGULAR_1.TTF");
			setTypeface(tf);
		}
	}
}
