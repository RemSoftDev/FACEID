﻿using Microsoft.Devices;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Net.NetworkInformation;
using Microsoft.Phone.Tasks;
using Microsoft.Xna.Framework.Media;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.IsolatedStorage;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using Windows.Devices.Geolocation;
using Windows.Storage;

namespace FACEID.User
{
    public partial class Authenticate : PhoneApplicationPage
    {
        public delegate string delegatesendimage(string a, string b, int c);


        #region Declaration

        //declaration
        PhotoCamera cam = new PhotoCamera();
        private static ManualResetEvent pauseFramesEvent = new ManualResetEvent(true);
        private WriteableBitmap wb;
        
       
        IsolatedStorageFile isStore = System.IO.IsolatedStorage.IsolatedStorageFile.GetUserStoreForApplication();
        ImageBrush BlackRoundImage = new ImageBrush();
        ImageBrush OrangeRoundImage = new ImageBrush();
        int ImageCounter = 0;
        
        #endregion

        #region Events
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {

            // Check to see if the camera is available on the phone.

            if (PhotoCamera.IsCameraTypeSupported(CameraType.FrontFacing) == true)
            {
                // Initialize the default camera.


                cam = new Microsoft.Devices.PhotoCamera(CameraType.FrontFacing);

                //Set the VideoBrush source to the camera

                viewfinderBrush.RelativeTransform = new CompositeTransform() { CenterX = 0.5, CenterY = 0.5, Rotation = 90, ScaleX = -1 };
            }
            else
            {
                cam = new Microsoft.Devices.PhotoCamera(CameraType.FrontFacing);
                viewfinderBrush.RelativeTransform = new CompositeTransform() { CenterX = 0.5, CenterY = 0.5, Rotation = 90 };
            }

            viewfinderBrush.SetSource(cam);

            RectangleBox.Visibility = Visibility.Visible;
            StartScaningButton.Visibility = Visibility.Visible;
            grdSwapCamera.Visibility = Visibility.Visible;
            RectangleView.Visibility = Visibility.Visible;
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            NavigationService.Navigate(new Uri("/User/HomePage.xaml", UriKind.RelativeOrAbsolute));
        }
        void cam_Initialized(object sender, Microsoft.Devices.CameraOperationCompletedEventArgs e)
        {
            try
            {

                if (e.Succeeded)
                {

                    for (int i = 4; i > 0; i--)
                    {

                        Thread.Sleep(1000);

                        this.Dispatcher.BeginInvoke(delegate()
                        {
                            numcounter.Text = i.ToString();
                        });
                    }


                    this.Dispatcher.BeginInvoke(delegate()
                    {
                        progressRing1.Visibility = Visibility.Collapsed;
                        progressRing1.IsActive = false;
                        numcounter.Visibility = Visibility.Collapsed;
                        MainImage.Visibility = Visibility.Visible;
                        MainImageSlideIn.Begin();
                        MainImageSlideIn.RepeatBehavior = RepeatBehavior.Forever;

                    });

                 
                    PumpARGBFrames();

                }

            }
            catch (Exception)
            {
                this.Dispatcher.BeginInvoke(delegate()
                {
                    MessageBox.Show("Please Restart Application And Try Again");

                });
            }

        }

        private void SwapCamera_Tap(object sender, System.Windows.Input.GestureEventArgs e)
        {
            if (cam.CameraType == CameraType.FrontFacing)
            {
                cam = new Microsoft.Devices.PhotoCamera(CameraType.Primary);
                viewfinderBrush.RelativeTransform = new CompositeTransform() { CenterX = 0.5, CenterY = 0.5, Rotation = 90 };
                viewfinderBrush.SetSource(cam);

            }

            else
            {
                if ((PhotoCamera.IsCameraTypeSupported(CameraType.FrontFacing) == true))
                {


                    cam = new Microsoft.Devices.PhotoCamera(CameraType.FrontFacing);
                    //viewfinderBrush.RelativeTransform = new CompositeTransform() { CenterX = 0.5, CenterY = 0.5, Rotation = 270, };
                    viewfinderBrush.RelativeTransform = new CompositeTransform() { CenterX = 0.5, CenterY = 0.5, Rotation = 90, ScaleX = -1 };

                    viewfinderBrush.SetSource(cam);

                }
                else
                {
                    this.Dispatcher.BeginInvoke(delegate()
                    {
                        MessageBox.Show("Your Phone Doesn't Support Front Camera");
                    });
                }
            }


        }

        private void StartScaningButton_Tap(object sender, System.Windows.Input.GestureEventArgs e)
        {
            try
            {
                if (isNetworkConnected())
                {
                    grdSwapCamera.Visibility = Visibility.Collapsed;
                    //  GuidTextBlock.Visibility = Visibility.Collapsed;

                    if (cam.CameraType == CameraType.FrontFacing)
                    {
                        cam = new Microsoft.Devices.PhotoCamera(CameraType.FrontFacing);
                        viewfinderBrush.RelativeTransform = new CompositeTransform() { CenterX = 0.5, CenterY = 0.5, Rotation = 90, ScaleX = -1 };
                    }
                    else
                    {
                        cam = new Microsoft.Devices.PhotoCamera(CameraType.Primary);
                        viewfinderBrush.RelativeTransform = new CompositeTransform() { CenterX = 0.5, CenterY = 0.5, Rotation = 90, };
                    }

                    //Event is fired when the PhotoCamera object has been initialized
                    cam.Initialized += new EventHandler<Microsoft.Devices.CameraOperationCompletedEventArgs>(cam_Initialized);

                    //Set the VideoBrush source to the camera


                    viewfinderBrush.SetSource(cam);

                    FocasImage.Visibility = Visibility.Collapsed;
                    RectangleBox.Visibility = Visibility.Visible;
                    //   GuidTextBlock.Visibility = Visibility.Collapsed;
                    StartScaningButton.Visibility = Visibility.Collapsed;

                    progressRing1.Visibility = Visibility.Visible;
                    progressRing1.IsActive = true;

                }

                else
                {


                    this.Dispatcher.BeginInvoke(delegate()
                    {
                        MessageBox.Show("Please Check Internet Connection");
                        NavigationService.Navigate(new Uri("/User/HomePage.xaml", UriKind.RelativeOrAbsolute));
                    });
                }

            }
            catch (Exception)
            {

                this.Dispatcher.BeginInvoke(delegate()
                {
                    MessageBox.Show("Please Try Again");

                    NavigationService.Navigate(new Uri("/User/HomePage.xaml", UriKind.RelativeOrAbsolute));
                });
            }
        }

        private void BackButton_Tap(object sender, System.Windows.Input.GestureEventArgs e)
        {
            NavigationService.Navigate(new Uri("/User/HomePage.xaml", UriKind.RelativeOrAbsolute));
        }

        private void grdStatus_Tap(object sender, System.Windows.Input.GestureEventArgs e)
        {

            NavigationService.Navigate(new Uri("/User/HomePage.xaml", UriKind.RelativeOrAbsolute));
        }

        private void Grid_Tap(object sender, System.Windows.Input.GestureEventArgs e)
        {
            PhoneCallTask ph = new PhoneCallTask();
            ph.PhoneNumber = "0800 888 6644";
            ph.DisplayName = "Face.Id";
            ph.Show();
        }

        #endregion

        #region Methods
        public Authenticate()
        {
            InitializeComponent();
            App.settings = IsolatedStorageSettings.ApplicationSettings;
            StorageFolder folder = ApplicationData.Current.LocalFolder;
        }

        public async void PumpARGBFrames()
        {
            try
            {
                // Create capture buffer.
                int[] ARGBPx = new int[(int)cam.PreviewResolution.Width * (int)cam.PreviewResolution.Height];

   PhotoCamera phCam = (PhotoCamera)cam;

                for (int j = 1; j < 17; j++)
                {
                    pauseFramesEvent.WaitOne();

                    phCam.GetPreviewBufferArgb32(ARGBPx);


                    // Conversion to grayscale.
                    for (int i = 0; i < ARGBPx.Length; i++)
                    {
                        ARGBPx[i] = ColorToGray(ARGBPx[i]);
                    }


                    pauseFramesEvent.Reset();


                    Deployment.Current.Dispatcher.BeginInvoke(delegate()
                    {
                        // Copy to WriteableBitmap.
                        wb = new WriteableBitmap((int)cam.PreviewResolution.Width, (int)cam.PreviewResolution.Height);
                        ARGBPx.CopyTo(wb.Pixels, 0);

                        MediaLibrary library = new MediaLibrary();
                        int angle;
                        if (cam.CameraType == CameraType.FrontFacing)
                        {

                            angle = 270;
                        }

                        else
                        {

                            angle = 90;
                        }
                        WriteableBitmap wbTarget = null;
                        if (angle % 180 == 0)
                        {
                            wbTarget = new WriteableBitmap(wb.PixelWidth, wb.PixelHeight);
                        }
                        else
                        {
                            wbTarget = new WriteableBitmap(wb.PixelHeight, wb.PixelWidth);
                        }

                        for (int x = 0; x < wb.PixelWidth; x++)
                        {
                            for (int y = 0; y < wb.PixelHeight; y++)
                            {
                                switch (angle % 360)
                                {
                                    case 90:
                                        wbTarget.Pixels[(wb.PixelHeight - y - 1) + x * wbTarget.PixelWidth] = wb.Pixels[x + y * wb.PixelWidth];
                                        break;
                                    case 180:
                                        wbTarget.Pixels[(wb.PixelWidth - x - 1) + (wb.PixelHeight - y - 1) * wb.PixelWidth] = wb.Pixels[x + y * wb.PixelWidth];
                                        break;
                                    case 270:
                                        wbTarget.Pixels[y + (wb.PixelWidth - x - 1) * wbTarget.PixelWidth] = wb.Pixels[x + y * wb.PixelWidth];
                                        break;
                                }
                            }
                        }


                        var fileStream = new MemoryStream();
                     
                        wbTarget.SaveJpeg(fileStream, 480, 640, 0, 100);
                        fileStream.Seek(0, SeekOrigin.Begin);
                        wb.Invalidate();

                        Guid g = Guid.NewGuid();
                        
                     //  library.SavePictureToCameraRoll("faceid_" + j + ".jpg", fileStream);

                         string filename = j + ".jpg";
                      
                        using (IsolatedStorageFile isStore = IsolatedStorageFile.GetUserStoreForApplication())
                        {
                            using (IsolatedStorageFileStream targetStream = isStore.OpenFile(filename, FileMode.Create, FileAccess.Write))
                            {
                                // Initialize the buffer for 4KB disk pages.
                                byte[] readBuffer = new byte[4096];
                                int bytesRead = -1;

                                // Copy the thumbnail to isolated storage. 
                                while ((bytesRead = fileStream.Read(readBuffer, 0, readBuffer.Length)) > 0)
                                {
                                    targetStream.Write(readBuffer, 0, bytesRead);
                                }
                            }
                        }

                        pauseFramesEvent.Set();
                    });

                }



                this.Dispatcher.BeginInvoke(delegate()
                {
                    MainImageSlideIn.Stop();
                    MainImage.Visibility = Visibility.Collapsed;
                    grdProgress.Visibility = Visibility.Visible;
                    ProgressBar.IsIndeterminate = true;


                });


                Debug.WriteLine("images captured");


                var uidStatus = await GetUid();
                if (string.IsNullOrEmpty(uidStatus))
               {
                   this.Dispatcher.BeginInvoke(delegate()
                   {
                       MessageBox.Show("Please Try Again");
                       NavigationService.Navigate(new Uri("/User/HomePage.xaml", UriKind.RelativeOrAbsolute));
                   });

               }
                List<StringBuilder> Baselist = new List<StringBuilder>();
                byte[] ImageByteArray = null;
                string FilePath = string.Empty;
                string FileName = string.Empty;
                for (int i = 3; i < 16; i++)
                {
                   FilePath = GetAbsolutePath(i+".jpg");
                   if (!string.IsNullOrEmpty(FilePath))
                   {
                      ImageByteArray =   FileToByteArray.Convert(FilePath);
                      StringBuilder base64string = new StringBuilder();
                      base64string.Append(Convert.ToBase64String(ImageByteArray));
                      Baselist.Add(base64string);
                   }
                
                
                }

                Services(0, Baselist, uidStatus);
                //   Services_test(0, Baselist, uidStatus);
            }
            catch (Exception)
            {
                this.Dispatcher.BeginInvoke(delegate()
                {

                    MainImageSlideIn.Stop();
                    MainImage.Visibility = Visibility.Collapsed;
                    grdProgress.Visibility = Visibility.Visible;
                    ProgressBar.IsIndeterminate = true;

                    MessageBox.Show("Technical Error! Please Try Again");

                });
            }
        }


        public void Services(int tempCounter, List<StringBuilder> Base64List, string uid)
        {
            try
            {

           
            Debug.WriteLine("no. of images in Base64String list - " + Base64List.Count.ToString());
            Debug.WriteLine("   uid :  " + uid);

            var httpClientHandler = new HttpClientHandler();
            using (HttpClient client = new HttpClient(httpClientHandler))
            {

                client.BaseAddress = new Uri("https://klws.keylemon.com/");

                string url = "api/stream/" + uid + "?user=approvedid&key=Ycsss77jU4UG3AURETdDmua3B3GaaxGIRJzIT1s0bqbIGLfAIn1pQ7";


                //  Stream initiated
                var response = client.GetAsync(url);

                Debug.WriteLine("Stream started");
                Debug.WriteLine("uid-  " + uid);

                if (tempCounter >= 22)
                {

                    tempCounter = 0;
                }

                //sending image 
                sendimages_BaseList1(Base64List[tempCounter], uid, tempCounter);
            
                Thread.Sleep(100);
                sendimages_BaseList2(Base64List[tempCounter + 1], uid, tempCounter + 1);
            
                Thread.Sleep(100);
                sendimages_BaseList3(Base64List[tempCounter + 2], uid, tempCounter + 2);
            
                response.Wait();

                if (response.IsCompleted)
                {

                    var data1 = response.Result.Content.ReadAsStringAsync();

                    var objData = JsonConvert.DeserializeObject<Authetication>(data1.Result.ToString());

                    Debug.WriteLine("stream response:");
                    Debug.WriteLine("authenticate: " + objData.authenticated.ToString());
                    Debug.WriteLine("stream closed: " + objData.closed.ToString());

                    string Resultmsg = objData.authenticated;

                    if (objData.closed == "False")
                    {
                        tempCounter = tempCounter + 3;
                        Services2(tempCounter, Base64List, uid);
                    }
                    else if (objData.authenticated == "True")
                    {

                        CallImageLog("true", Base64List, tempCounter + 3);
                        
                    }
                    else if (objData.closed == "True" && objData.authenticated == "False")
                    {
                        CallImageLog("false", Base64List, tempCounter + 3);
                    }

                }
            }

            }
            catch (Exception)
            {
                this.Dispatcher.BeginInvoke(delegate()
                {
                    MessageBox.Show("Please Restart Application And Try Again");
                    NavigationService.Navigate(new Uri("/User/HomePage.xaml", UriKind.RelativeOrAbsolute));
                });

            }


        }

        public void Services2(int tempCounter, List<StringBuilder> Base64List, string uid)
        {

            try
            {

            

            Debug.WriteLine("no. of images in Base64String list - " + Base64List.Count.ToString());

            var httpClientHandler = new HttpClientHandler();
            using (HttpClient client = new HttpClient(httpClientHandler))
            {

                client.BaseAddress = new Uri("https://klws.keylemon.com/");

                string url = "api/stream/" + uid + "?user=approvedid&key=Ycsss77jU4UG3AURETdDmua3B3GaaxGIRJzIT1s0bqbIGLfAIn1pQ7";


                //  Stream initiated
                var response = client.GetAsync(url);

                Debug.WriteLine("Stream started");
                Debug.WriteLine("uid-  " + uid);

                if (tempCounter >= 22)
                {

                    tempCounter = 0;
                }

                //sending image 
                sendimages_BaseList1(Base64List[tempCounter], uid, tempCounter);
              
                Thread.Sleep(100);
                sendimages_BaseList2(Base64List[tempCounter + 1], uid, tempCounter + 1);
                
                Thread.Sleep(100);
                sendimages_BaseList3(Base64List[tempCounter + 2], uid, tempCounter + 2);
               
                response.Wait();

                if (response.IsCompleted)
                {

                    var data1 = response.Result.Content.ReadAsStringAsync();


                    var objData = JsonConvert.DeserializeObject<Authetication>(data1.Result.ToString());

                    Debug.WriteLine("stream response:");
                    Debug.WriteLine("authenticate: " + objData.authenticated.ToString());
                    Debug.WriteLine("stream closed: " + objData.closed.ToString());

                    string Resultmsg = objData.authenticated;

                    if (objData.closed == "False")
                    {
                        tempCounter = tempCounter + 3;
                        Services3(tempCounter, Base64List, uid);
                    }
                    else if (objData.authenticated == "True")
                    {

                        CallImageLog("true", Base64List, tempCounter + 3);
                        

                    }
                    else if (objData.closed == "True" && objData.authenticated == "False")
                    {
                        CallImageLog("false", Base64List, tempCounter + 3);
                     

                    }

                }
            }
            }
            catch (Exception)
            {
                this.Dispatcher.BeginInvoke(delegate()
                {
                    MessageBox.Show("Please Restart Application And Try Again");
                    NavigationService.Navigate(new Uri("/User/HomePage.xaml", UriKind.RelativeOrAbsolute));
                });

            }
            }

        public void Services3(int tempCounter, List<StringBuilder> Base64List, string uid)
        {
            try
            {

            
            Debug.WriteLine("no. of images in Base64String list - " + Base64List.Count.ToString());


            var httpClientHandler = new HttpClientHandler();
            using (HttpClient client = new HttpClient(httpClientHandler))
            {

                client.BaseAddress = new Uri("https://klws.keylemon.com/");

                string url = "api/stream/" + uid + "?user=approvedid&key=Ycsss77jU4UG3AURETdDmua3B3GaaxGIRJzIT1s0bqbIGLfAIn1pQ7";


                //  Stream initiated
                var response = client.GetAsync(url);

                Debug.WriteLine("Stream started");
                Debug.WriteLine("uid-  " + uid);

                if (tempCounter >= 22)
                {

                    tempCounter = 0;
                }

                //sending image 
                sendimages_BaseList1(Base64List[tempCounter], uid, tempCounter);
               
                Thread.Sleep(100);
                sendimages_BaseList2(Base64List[tempCounter + 1], uid, tempCounter + 1);
             

                Thread.Sleep(100);
                sendimages_BaseList3(Base64List[tempCounter + 2], uid, tempCounter + 2);
                

                response.Wait();

                if (response.IsCompleted)
                {

                    var data1 = response.Result.Content.ReadAsStringAsync();



                    var objData = JsonConvert.DeserializeObject<Authetication>(data1.Result.ToString());

                    Debug.WriteLine("stream response:");
                    Debug.WriteLine("authenticate: " + objData.authenticated.ToString());
                    Debug.WriteLine("stream closed: " + objData.closed.ToString());

                    string Resultmsg = objData.authenticated;

                    if (objData.closed == "False")
                    {
                       // tempCounter = tempCounter + 3;
                       // Services4(tempCounter, Base64List, uid);
                        CallImageLog("false", Base64List, tempCounter);
            

                    }
                    else if (objData.authenticated == "True")
                    {

                        CallImageLog("true", Base64List, tempCounter + 3);
                 

                    }
                    else if (objData.closed == "True" && objData.authenticated == "False")
                    {
                        CallImageLog("false", Base64List, tempCounter + 3);
                   
                    }

                }
            }
            }
            catch (Exception)
            {
                this.Dispatcher.BeginInvoke(delegate()
                {
                    MessageBox.Show("Please Restart Application And Try Again");
                    NavigationService.Navigate(new Uri("/User/HomePage.xaml", UriKind.RelativeOrAbsolute));
                });

            }
            
            }

        public void sendimages_BaseList1(StringBuilder base64Image, string uid, int counter)
        {
            try
            {
              
                using (var client = new HttpClient())
                   {
                       string url = "api/stream/" + uid;
                       client.BaseAddress = new Uri("https://klws.keylemon.com/");
                       var values = new MultipartFormDataContent();
                      
                    
                       values.Add(new StringContent(base64Image.ToString()), "image");
                    
                  client.PostAsync(url, values).Wait();
                    
                    Debug.WriteLine("response of image no. " + counter);
                    
                   }
                
            }
            catch (Exception)
            {
                this.Dispatcher.BeginInvoke(delegate()
                {
                    MessageBox.Show("Please Restart Application And Try Again");
                    NavigationService.Navigate(new Uri("/User/HomePage.xaml", UriKind.RelativeOrAbsolute));
                });

            }


        }
        public void sendimages_BaseList2(StringBuilder base64Image, string uid, int counter)
        {
            try
            {
                  using (var client = new HttpClient())
                   {

                          string url = "api/stream/" + uid;
                       client.BaseAddress = new Uri("https://klws.keylemon.com/");
                       var values = new MultipartFormDataContent(); 
                      values.Add(new StringContent(base64Image.ToString()), "image");

                    client.PostAsync(url, values).Wait();
                      
                       Debug.WriteLine("response of image no. " + counter);
                       
                   }


            }
            catch (Exception)
            {
                this.Dispatcher.BeginInvoke(delegate()
                {
                    MessageBox.Show("Please Restart Application And Try Again");
                    NavigationService.Navigate(new Uri("/User/HomePage.xaml", UriKind.RelativeOrAbsolute));
                });

            }


        }

        public void sendimages_BaseList3(StringBuilder base64Image, string uid, int counter)
        {
            try
            {

                  using (var client = new HttpClient())
                   {
                        string url = "api/stream/" + uid;
                       client.BaseAddress = new Uri("https://klws.keylemon.com/");
                       var values = new MultipartFormDataContent();
                       values.Add(new StringContent(base64Image.ToString()), "image");

                       client.PostAsync(url, values).Wait();
                      
                       Debug.WriteLine("response of image no. " + counter);
                     
                   }

            }
            catch (Exception)
            {
                this.Dispatcher.BeginInvoke(delegate()
                {
                    MessageBox.Show("Please Restart Application And Try Again");
                    NavigationService.Navigate(new Uri("/User/HomePage.xaml", UriKind.RelativeOrAbsolute));
                });

            }


        }

        public async void CallImageLog(string status, List<StringBuilder> baselist, int counter)
        {
            var res = await ImageLog(status, baselist, counter);
        }

        public async Task<bool> ImageLog(string status, List<StringBuilder> baselist, int counter)
        {
            Debug.WriteLine("logging images ");
            Debug.WriteLine("counter : " + counter.ToString());
            try
            {

                if (counter >= 23)
                {
                    counter = 22;

                }

                if (counter < 3)
                {
                    counter = 3;
                }
                int temp = ImageCounter;
                var httpClientHandler = new HttpClientHandler();

                using (HttpClient client = new HttpClient(httpClientHandler))

                using (System.Net.Http.MultipartFormDataContent multipart = new MultipartFormDataContent())
                {

                    client.BaseAddress = new Uri("http://face.id/");
                    string url = "faceid1/index.php/webservice/insertRecord/";

                    for (int i = 0; i < counter; i++)
                    {

                        byte[] ByteArrayImage = null;
                        ByteArrayImage = Convert.FromBase64String(baselist[i].ToString());

                        ByteArrayContent bac;

                        bac = new ByteArrayContent(ByteArrayImage);
                        bac.Headers.Add("Content-Type", "application/octet-stream");

                        multipart.Add(bac,
                             String.Format("\"{0}\"", "image[]"), "image.jpg");


                    }

                    //end  forloop

                    Geolocator locationFinder = new Geolocator();
                    String longitude = "";
                    String latitude = "";

                    try
                    {


                        Geoposition currentLocation = await locationFinder.GetGeopositionAsync(
                        maximumAge: TimeSpan.FromSeconds(120),
                        timeout: TimeSpan.FromSeconds(10));
                        longitude = currentLocation.Coordinate.Longitude.ToString("0.0000000");
                        latitude = currentLocation.Coordinate.Latitude.ToString("0.0000000");
                    }

                    catch (Exception)
                    {
                        longitude = "0";
                        latitude = "0";
                    }

                    try
                    {
                        string username = "";
                        string identity_id = "";
                        string member_id = "";
                        if (App.settings.Contains("username") && App.settings.Contains("identity_id") && App.settings.Contains("member_id"))
                        {
                            username = (string)App.settings["username"];
                            identity_id = (string)App.settings["identity_id"];
                            member_id = (string)App.settings["member_id"];

                        }

                        multipart.Add((new StringContent((string)App.settings["identity_id"])),
                       String.Format("\"{0}\"", "identity_value"));
                        Debug.WriteLine(identity_id);
                        multipart.Add((new StringContent(status)),
                            String.Format("\"{0}\"", "result"));
                        Debug.WriteLine(status);
                        multipart.Add((new StringContent((string)App.settings["member_id"])),
                       String.Format("\"{0}\"", "member_id"));
                        Debug.WriteLine(member_id);
                        multipart.Add((new StringContent(latitude)),
                            String.Format("\"{0}\"", "lat"));

                        multipart.Add((new StringContent(longitude)),
                            String.Format("\"{0}\"", "lng"));
                        Debug.WriteLine(longitude);
                        multipart.Add((new StringContent(App.settings["username"].ToString())),
                            String.Format("\"{0}\"", "user_name"));

                        Debug.WriteLine(username);
                        multipart.Add((new StringContent("0")),
                            String.Format("\"{0}\"", "tracer_id"));

                        Debug.WriteLine(counter);
                        var result =  client.PostAsync(url, multipart);
                        result.Wait();

                        Debug.WriteLine("images logged");
                        var res = result.Result.Content.ReadAsStringAsync();


                        if (res.IsCompleted)
                        {
                           if(status=="true")
                           {
                               isStore.Remove();
                               DisplayTrue();
                           }

                          else if (status == "false")
                           {
                               isStore.Remove();
                               DisplayFalse();
                           }
                          
                            //var data = res.Result.Content.ReadAsStringAsync();
                            // Thread.Sleep(200);

                            Debug.WriteLine("image log result on success:   " + res);
                            
                             return true;
                        }
                        else
                        {
                            Debug.WriteLine("image log result not computed ");
                            return false;

                        }

                    }
                    catch (UnauthorizedAccessException)
                    {
                        Debug.WriteLine("images NOT logged");
                         return false;
                    }
                    //using multipart
                }

                //end try
            }
            catch (Exception)
            {
                  return false;
            }
        }

        private string GetAbsolutePath(string filename)
        {
            string absoulutePath = null;
            try
            {

                if (isStore.FileExists(filename))
                {
                    IsolatedStorageFileStream output = new IsolatedStorageFileStream(filename, FileMode.Open, isStore);
                    absoulutePath = output.Name;
                    output.Close();
                    output = null;
                }
                return absoulutePath;


            }
            catch (Exception)
            {

                return absoulutePath;
            }

        }

        public bool isNetworkConnected()
        {
            return DeviceNetworkInformation.IsNetworkAvailable;
        }
        public static class FileToByteArray
        {
            public static byte[] Convert(string FileName)
            {
                byte[] stream = null;
                try
                {

                    System.IO.FileStream fileStream = File.OpenRead(FileName);

                    using (MemoryStream memoryStream = new MemoryStream())
                    {
                        fileStream.CopyTo(memoryStream);
                        fileStream.Close();

                        stream = memoryStream.ToArray();
                        memoryStream.Close();
                        return stream;

                    }
                }
                catch (Exception)
                {

                    return null;
                }



            }
        }

        internal int ColorToGray(int color)
        {
            int gray = 0;

            int a = color >> 24;
            int r = (color & 0x00ff0000) >> 16;
            int g = (color & 0x0000ff00) >> 8;
            int b = (color & 0x000000ff);

            if ((r == g) && (g == b))
            {
                gray = color;
            }
            else
            {
                // Calculate for the illumination.
                // I =(int)(0.109375*R + 0.59375*G + 0.296875*B + 0.5)
                int i = (7 * r + 38 * g + 19 * b + 32) >> 6;

                gray = ((a & 0xFF) << 24) | ((i & 0xFF) << 16) | ((i & 0xFF) << 8) | (i & 0xFF);
            }
            return gray;
        }

        public async Task<string> GetUid()
        {
            try
            {

                var httpClientHandler = new HttpClientHandler();

                using (HttpClient client = new HttpClient(httpClientHandler))
                {
                    client.BaseAddress = new Uri("https://klws.keylemon.com/");

                    string id = string.Empty;

                    if (!App.settings.Contains("identity_id"))
                    {
                        return string.Empty;
                        // App.settings.Add("identity_id", objData.response.identity_id.ToString());
                    }
                    else
                    {
                        id = App.settings["identity_id"].ToString();
                        Debug.WriteLine("Identity id   " + id);
                    }


                    ///api/stream/

                    string url = "api/stream/";
                    var formContent = new FormUrlEncodedContent(new[]
            { 
                new KeyValuePair<string, string>("user","approvedid") ,
                new KeyValuePair<string, string>("key","Ycsss77jU4UG3AURETdDmua3B3GaaxGIRJzIT1s0bqbIGLfAIn1pQ7") ,
                new KeyValuePair<string, string>("identity",id) ,
                new KeyValuePair<string, string>("threshold","0.7") 
            });


                    HttpResponseMessage response = new HttpResponseMessage();
                    response = await client.PostAsync(url, formContent);


                    if (response.IsSuccessStatusCode)
                    {
                        var data = response.Content.ReadAsStringAsync();

                        var objData = JsonConvert.DeserializeObject<GetUid>(data.Result.ToString());

                        return objData.uid;

                    }
                    else { return string.Empty; }
                }

            }
            catch (Exception)
            {
                this.Dispatcher.BeginInvoke(delegate()
                {

                    grdProgress.Visibility = Visibility.Collapsed;
                    ProgressBar.IsIndeterminate = false;
                    
                        MessageBox.Show("Please Restart Application And Try Again");
                        NavigationService.Navigate(new Uri("/User/HomePage.xaml", UriKind.RelativeOrAbsolute));
                    
                });
                return string.Empty;
            }

        }
        public void DisplayTrue()
        {

            String theAddress = "";

            this.Dispatcher.BeginInvoke(delegate()
            {
                grdProgress.Visibility = Visibility.Collapsed;
                ProgressBar.IsIndeterminate = false;
                RectangleView.Visibility = Visibility.Collapsed;

                if (App.settings.Contains("dob"))
                {
                    try
                    {


                        DateTime zeroTime = new DateTime(1, 1, 1);
                        DateTime dob = new DateTime(1, 1, 1);
                        dob = (DateTime)Convert.ToDateTime(App.settings["dob"]);
                        TimeSpan difference = DateTime.Now - dob;
                        int years = (zeroTime + difference).Year - 1;
                        if (years >= 18)
                        {
                            Fullname.Text = (string)App.settings["name"];

                            if (App.settings.Remove("dob"))
                            {
                                App.settings.Remove("dob");
                            }
                        }
                        else
                        {
                            Fullname.Text = (string)App.settings["name"] + " " + years.ToString() + " Years";
                            if (App.settings.Remove("dob"))
                            {
                                App.settings.Remove("dob");
                            }
                        }

                        if(App.settings["user_data"].ToString().ToLower() == "yes")
                        {
                            Debug.WriteLine("[FaceID] We can use the address, now build it");
                            if (App.settings["user_address1"].ToString().Length > 0)
                            {
                                theAddress = theAddress + App.settings["user_address1"].ToString();
                            }
                            if (App.settings["user_address2"].ToString().Length > 0)
                            {
                                if (theAddress.Length > 0)
                                {
                                    theAddress = theAddress + ", ";
                                }
                                theAddress = theAddress + App.settings["user_address2"].ToString();
                            }
                            if (App.settings["user_town"].ToString().Length > 0)
                            {
                                if (theAddress.Length > 0)
                                {
                                    theAddress = theAddress + ", ";
                                }
                                theAddress = theAddress + App.settings["user_town"].ToString();
                            }
                            if (App.settings["user_county"].ToString().Length > 0)
                            {
                                if (theAddress.Length > 0)
                                {
                                    theAddress = theAddress + ", ";
                                }
                                theAddress = theAddress + App.settings["user_county"].ToString();
                            }
                            if (App.settings["user_postcode"].ToString().Length > 0)
                            {
                                if (theAddress.Length > 0)
                                {
                                    theAddress = theAddress + ", ";
                                }
                                theAddress = theAddress + App.settings["user_postcode"].ToString();
                            }
                            Debug.WriteLine("[FaceID] Address string: " + theAddress);
                        }
                    }
                    catch (Exception)
                    {
                        grdProgress.Visibility = Visibility.Collapsed;
                        ProgressBar.IsIndeterminate = false;
                        RectangleView.Visibility = Visibility.Collapsed;

                        grdStatus.Visibility = Visibility.Visible;
                        Fullname.Text = (string)App.settings["name"];
                        SuccessImage.Visibility = Visibility.Visible;
                        TextStatus.Visibility = Visibility.Visible;
                        TextStatus.Text = "Verified Successfully!";
                        RectangleBox.Visibility = Visibility.Collapsed;
                        ContentPanel.Visibility = Visibility.Collapsed;
                        SuccessImage.Visibility = Visibility.Visible;
                        grdcontact.Visibility = Visibility.Collapsed;
                        grdname.Visibility = Visibility.Visible;
                    }

                }

                grdStatus.Visibility = Visibility.Visible;

                SuccessImage.Visibility = Visibility.Visible;
                TextStatus.Visibility = Visibility.Visible;
                TextStatus.Text = "Verified Successfully!";
                // Check if we can use the address
                if (App.settings["user_data"].ToString().ToLower() == "yes")
                {
                    Debug.WriteLine("[FaceID] Displaying the address");
                    addressBlock.Visibility = Visibility.Visible;
                    userAddress.Text = theAddress;
                }
                RectangleBox.Visibility = Visibility.Collapsed;
                ContentPanel.Visibility = Visibility.Collapsed;
                SuccessImage.Visibility = Visibility.Visible;
                grdcontact.Visibility = Visibility.Collapsed;

                grdname.Visibility = Visibility.Visible;


            });



        }
        public void DisplayFalse()
        {
            
            this.Dispatcher.BeginInvoke(delegate()
            {

                grdStatus.Visibility = Visibility.Visible;
                FailedImage.Visibility = Visibility.Visible;

                TextStatus.Visibility = Visibility.Visible;
                TextStatus.Text = "Verification Failed!";
                grdcontact.Visibility = Visibility.Visible;
                RectangleBox.Visibility = Visibility.Collapsed;
                FailedImage.Visibility = Visibility.Visible;
                ContentPanel.Visibility = Visibility.Collapsed;
                grdcontact.Visibility = Visibility.Visible;

                // failMessage.Visibility = Visibility.Visible;

                grdProgress.Visibility = Visibility.Collapsed;
                ProgressBar.IsIndeterminate = false;
                RectangleView.Visibility = Visibility.Collapsed;



            });


        }

        #endregion

    }
}