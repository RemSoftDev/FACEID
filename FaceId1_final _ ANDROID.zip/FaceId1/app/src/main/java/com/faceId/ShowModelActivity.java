package com.faceId;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.faceId.crashreport.ExceptionHandler;
import com.faceId.lazyloading.ImageLoader;

/*
 *  This class shows all models and remove features.. 
 */

public class ShowModelActivity extends Activity {

	ImageView model_cancle;
	GridView model_gv;
	private String identity_id, created_identity_id, nb_models;
	ArrayList<String> image_array = new ArrayList<String>();
	ArrayList<String> model_array = new ArrayList<String>();

	boolean isClicked = false;
	ImageLoader ImageLoader;
	public ModelImageAdapter adapter;
	protected ArrayList<Bitmap> imageArray;
	private ProgressDialog pDialog;;
	ArrayList<TextView> text_array = new ArrayList<TextView>();
	ArrayList<GridObject> myObjects;
	private int last_pos = 10;
	private String identityID;
	HashMap<Integer, Bitmap> image_hashmap = new HashMap<Integer, Bitmap>();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.show_model_activity);
		Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(this));
		ImageLoader = new ImageLoader(ShowModelActivity.this);
		model_cancle = (ImageView) findViewById(R.id.model_cancle);
		model_gv = (GridView) findViewById(R.id.model_gv);
		getPref_identity();
		imageArray= new ArrayList<Bitmap>();

		
		
		model_cancle.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				startActivity(new Intent(ShowModelActivity.this,
						MemberIdActivity.class));
				finish();
			}
		});
		
		model_gv.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,int position, long id) {
				isClicked = true;
				if (last_pos != 10) {
					myObjects.get(last_pos).setState(0);
				}
				last_pos = position;

				TextView tah= (TextView)view.findViewById(R.id.replace_tv);
				 String tag = tah.getTag().toString();
				 if(tag != null) {
			         int positions = Integer.parseInt(tag);
			         myObjects.get(positions).setState(1);
			    }
	             adapter.notifyDataSetChanged();
			}
		});
	}
	
	private boolean isNetworkAvailable() {
		ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo activeNetworkInfo = connectivityManager
				.getActiveNetworkInfo();
		return activeNetworkInfo != null && activeNetworkInfo.isConnected();
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		if (isNetworkAvailable()) {
			new GetModelFromIdentity().execute();
			
			new Handler().postDelayed(new Runnable() {
				@Override
				public void run() {
					pDialog.dismiss();
					adapter=new ModelImageAdapter(ShowModelActivity.this);
					model_gv.setAdapter(adapter);
				}
			},18000);
		} else {
			Toast.makeText(ShowModelActivity.this, "Please check your internet connection", Toast.LENGTH_LONG).show();
		}
	}
	public class GetModelFromIdentity extends AsyncTask<String, String, String> {


		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			pDialog = ProgressDialog
					.show(ShowModelActivity.this, "", "Please Wait");
		}

		@Override
		protected String doInBackground(String... params) {

			HttpParams httpParameters = new BasicHttpParams();
			HttpConnectionParams.setConnectionTimeout(httpParameters, 10000);
			HttpConnectionParams.setSoTimeout(httpParameters, 10000);
			HttpClient httpclient = new DefaultHttpClient();
			HttpResponse response = null;
			String responseText = null;

			String api_post = "https://klws.keylemon.com/api/identity/"
					+ identityID
					+ "/?user=approvedid&key=Ycsss77jU4UG3AURETdDmua3B3GaaxGIRJzIT1s0bqbIGLfAIn1pQ7";
			try {
				HttpGet httpGet = new HttpGet(api_post);
				response = httpclient.execute(httpGet);
				Log.v("Post Status", "Code: "
						+ response.getStatusLine().getStatusCode());
				HttpEntity entity = response.getEntity();
				responseText = EntityUtils.toString(entity);
				Log.v("Response", "Response while face" + responseText);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return responseText;
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);

			// Json Parsing
			JSONObject obj;
			try {
				obj = (JSONObject) new JSONTokener(result).nextValue();
				// JSONArray identities_array = obj.getJSONArray("identities");
				// for (int j = 0; j < obj.length(); j++) {
				// JSONObject jObj = obj.getJSONObject(j);
				identity_id = obj.getString("identity_id");
				nb_models = obj.getString("nb_models");

				if (nb_models.equalsIgnoreCase("0")) {
					AlertMessage(ShowModelActivity.this, "Identity contaions no faces, Click to Add");
				}else {
					Log.i("identity_id_model","identity_id_model" + identity_id);
					JSONArray modelsArray = obj.getJSONArray("models");
					for (int i = 0; i < modelsArray.length(); i++) {
						JSONObject model_details = modelsArray.getJSONObject(i);
						String model_id = model_details.getString("model_id");
						model_array.add(model_id);
						Log.i("model_array", "totla_model_rcv" + model_array.toString());
						String created = model_details.getString("created");
						String modality = model_details.getString("modality");
						String nb_faces = model_details.getString("nb_faces");
						
						JSONArray facesArray = model_details.getJSONArray("faces");
						// for (int k = 0; k < facesArray.length(); k++) {
						JSONObject faces_details = facesArray.getJSONObject(0);
						String face_id = faces_details.getString("face_id");
						String image_url = faces_details.getString("image_url");
						image_array.add("https://klws.keylemon.com" + image_url);
						downloadFile(image_array.get(i) , i);
					}
					myObjects = new ArrayList<GridObject>();
					for (String s : image_array) {
						myObjects.add(new GridObject(s, 0));
					}
				}
				
			} catch (JSONException e) {
				e.printStackTrace();
			}
			
		}
	}
	
	public void AlertMessage(final Activity _this, String msg) {
		AlertDialog.Builder builder = new AlertDialog.Builder(_this);
		builder.setMessage(msg);
		builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				Intent i = new Intent(_this, CreateModelActivityFromCamera.class);
				startActivity(i);
				finish();
			}
		});
		builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				Intent i = new Intent(_this, MemberIdActivity.class);
				startActivity(i);
				finish();
			}
		});
		AlertDialog alert11 = builder.show();
		TextView messageText = (TextView) alert11.findViewById(android.R.id.message);
		messageText.setGravity(Gravity.CENTER);
		alert11.show();
	}
	
	public class DeleteModelFromIdentity_Api extends AsyncTask<String, String, String> {

		int pos;

		public DeleteModelFromIdentity_Api(int position) {
			pos = position;
		}

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			pDialog = ProgressDialog
					.show(ShowModelActivity.this, "", "Please Wait");
		}

		@Override
		protected String doInBackground(String... params) {

			HttpParams httpParameters = new BasicHttpParams();
			HttpConnectionParams.setConnectionTimeout(httpParameters, 10000);
			HttpConnectionParams.setSoTimeout(httpParameters, 10000);
			HttpClient httpclient = new DefaultHttpClient();
			HttpResponse response = null;
			String responseText = null;

			Log.i("model_array", "totla_model_delete" + model_array.get(pos) + " " +  pos);
			save_preference(model_array.get(pos));
			
			String api_post = "https://klws.keylemon.com/api/identity/"
					+ identityID
					+ "/"
					+ model_array.get(pos)
					+ "/?user=approvedid&key=Ycsss77jU4UG3AURETdDmua3B3GaaxGIRJzIT1s0bqbIGLfAIn1pQ7";

			try {

				HttpDelete httpDelete = new HttpDelete(api_post);
				response = httpclient.execute(httpDelete);
				Log.v("Post Status", "Code: "
						+ response.getStatusLine().getStatusCode());
				HttpEntity entity = response.getEntity();
				responseText = EntityUtils.toString(entity);
				Log.v("Response", "Response while face" + responseText);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return responseText;
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			pDialog.dismiss();
			Intent i = new Intent(ShowModelActivity.this,CreateModelActivityFromCamera.class);
			Log.i("model_array", "totla_model_pos_send" + String.valueOf(last_pos));
			i.putExtra("model_no", String.valueOf(last_pos));
			i.putExtra("identity_id", identityID);
			startActivity(i);

			
		}
	}

	public class ModelImageAdapter extends BaseAdapter {
		Context mContext;
		LayoutInflater inflater;

		public ModelImageAdapter(Context cn) {
			mContext = cn;
			inflater = (LayoutInflater) mContext
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		}

		@Override
		public int getCount() {
			return image_array.size();
		}

		@Override
		public Object getItem(int position) {
			return image_array.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@SuppressLint("ViewHolder")
		@Override
		public View getView(  final int position, View convertView,ViewGroup parent) 
		{
			final GridObject object = myObjects.get(position);
			View grid;
			final Holder holder = new Holder();

			LayoutInflater inflater = (LayoutInflater) mContext
						.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			grid = inflater.inflate(R.layout.model_grid_layout, parent, false); 

			holder.imageView = (ImageView) grid.findViewById(R.id.model_iv);
			holder.replace_tv = (TextView) grid.findViewById(R.id.replace_tv);
			holder.cancel_tv = (TextView) grid.findViewById(R.id.cancel_tv);
			holder.replace_tv.setTag(position);
			holder.image_top_ll = (LinearLayout) grid.findViewById(R.id.image_top_ll);
			text_array.add(holder.replace_tv);
			holder.image_top_ll.setVisibility(View.GONE);
			holder.replace_tv.setVisibility(View.GONE);
			holder.cancel_tv.setVisibility(View.GONE);
			holder.imageView.setImageBitmap(image_hashmap.get(position));

			holder.imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
			
			holder.replace_tv.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
//					new DeleteModelFromIdentity_Api(position).execute();
					Intent i = new Intent(ShowModelActivity.this,CreateModelActivityFromCamera.class);
					Log.i("model_array", "totla_model_pos_send" + String.valueOf(last_pos));
					i.putExtra("model_no", String.valueOf(last_pos));
					i.putExtra("identity_id", identityID);
					i.putExtra("modelTodelete", model_array.get(last_pos));
					startActivity(i);
				}
			});
			
			holder.cancel_tv.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					object.setState(0);
					notifyDataSetChanged();
				}
			});
			 if (object.getState() == 1) {
				holder.replace_tv.setVisibility(View.VISIBLE);
				holder.cancel_tv.setVisibility(View.VISIBLE);
				holder.image_top_ll.setVisibility(View.VISIBLE);

	            } else {
	            	holder.cancel_tv.setVisibility(View.GONE);   
	            	holder.replace_tv.setVisibility(View.GONE);
	    			holder.image_top_ll.setVisibility(View.GONE);

	            }
			 
			 

			return grid;
		}

	}
	
	public class GridObject {

	    private String name;
	    private int state;

	    public GridObject(String name, int state) {
	        super();
	        this.name = name;
	        this.state = state;
	    }

	    public String getName() {
	        return name;
	    }

	    public void setName(String name) {
	        this.name = name;
	    }

	    public int getState() {
	        return state;
	    }

	    public void setState(int state) {
	        this.state = state;
	    }   
	}

	public void downloadFile(final String stringURL , final int pos) {
		new Thread(new Runnable() {

			@Override
			public void run() {
				
				try {
					DefaultHttpClient client = new DefaultHttpClient();
					client.getCredentialsProvider()
							.setCredentials(new AuthScope(AuthScope.ANY_HOST,AuthScope.ANY_PORT),
							new UsernamePasswordCredentials("approvedid","Ycsss77jU4UG3AURETdDmua3B3GaaxGIRJzIT1s0bqbIGLfAIn1pQ7"));
					HttpGet request = new HttpGet(stringURL);
					HttpResponse response = client.execute(request);
					HttpEntity entity = response.getEntity();
					InputStream inputStream = entity.getContent();
				Bitmap	bmImg = BitmapFactory.decodeStream(inputStream);
				imageArray.add(bmImg);
				image_hashmap.put(pos, bmImg);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}).start();

	}

	public class Holder {
		ImageView imageView;
		TextView replace_tv;
		TextView cancel_tv;
		LinearLayout image_top_ll;
	}

	@Override
	public void onBackPressed() {
		super.onBackPressed();
		if (isClicked) {
			adapter.notifyDataSetChanged();
//			model_gv.setAdapter(new ModelImageAdapter(ShowModelActivity.this));
		} else {
			startActivity(new Intent(ShowModelActivity.this,
					MemberIdActivity.class));
			finish();
		}
	}

	public void getPref_identity() {
		SharedPreferences shre = PreferenceManager
				.getDefaultSharedPreferences(this);
		created_identity_id = shre.getString("identities_data_face", "");
		identityID = shre.getString("identityID_login", "");
		Log.e("abcd", "identity_created" + identityID);
	}

	public void save_preference(String model_id) {
		SharedPreferences pref = PreferenceManager
				.getDefaultSharedPreferences(ShowModelActivity.this);
		Editor edit = pref.edit();
		edit.putString("old_model_deleted", model_id);
		edit.commit();
	}
}
