package com.faceId;

import java.util.Calendar;
import java.util.GregorianCalendar;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.faceId.crashreport.ExceptionHandler;

/*
 * This class is for business card screen for both success and failure
 * 
 */
public class LatestBusinessCardActivity extends Activity {

	boolean isClicked = false;

	Handler handler;
	Runnable runnable;
	TextView  name, address;
	private String director_name;
	private String director_dob;
	private String userAddress1, userAddress2, userTown, userCounty, userPostcode, userData, individual_level;
	static String isAuthenticated = "false";
	TextView success_tv , unsuccess_tv;

	private String director_last_name;
	private String account_type;


	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.newbusiness_card);
		Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(this));
		RelativeLayout failed_info = (RelativeLayout) findViewById(R.id.failed_info);
		RelativeLayout contact_info_2 = (RelativeLayout) findViewById(R.id.contact_info_2);
		ImageView response_iv = (ImageView) findViewById(R.id.response_iv);
		RelativeLayout bc_ll = (RelativeLayout) findViewById(R.id.bc_ll);
		name = (TextView) findViewById(R.id.name);
		address = (TextView) findViewById(R.id.address);
		success_tv = (TextView) findViewById(R.id.success_tv);
		
		
		getPref_indicator();
		if (isAuthenticated.equalsIgnoreCase("false")) {
			/*try {
				response_iv.setBackgroundResource(R.drawable.failed_shape);
			} catch (Exception e) {
				response_iv.setBackgroundResource(R.drawable.failed_shape);
			}*/
			response_iv.setImageResource(R.drawable.failed_shape);

			isAuthenticated = "false";
			name.setVisibility(View.INVISIBLE);
			address.setVisibility(View.INVISIBLE);
			failed_info.setVisibility(View.VISIBLE);
			success_tv.setText(R.string.verification_failed);
			contact_info_2.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					Intent callIntent = new Intent(Intent.ACTION_CALL);
					callIntent.setData(Uri.parse("tel:+448008886644"));
					startActivity(callIntent);
				}
			});
			
		} else if (isAuthenticated.equalsIgnoreCase("true")) {
			isAuthenticated = "false";
			success_tv.setText(R.string.verified_successfully);
			name.setVisibility(View.VISIBLE);
			address.setVisibility(View.VISIBLE);
			failed_info.setVisibility(View.INVISIBLE);

			/*try {
				response_iv.setBackgroundResource(R.drawable.successful_shape);
			} catch (Exception e) {
				response_iv.setBackgroundResource(R.drawable.successful_shape);
			}*/
			
			response_iv.setImageResource(R.drawable.successful_shape);

			int myAge = getAge(Integer.parseInt(director_dob.split("-")[0]), Integer.parseInt(director_dob.split("-")[1]), 
					Integer.parseInt(director_dob.split("-")[2]));
			try {
				if (myAge < 18) {
					if (myAge == 0) {
						name.setText(director_name+ " " + director_last_name);
					} else if(myAge == 1){
						name.setText(director_name + " " + director_last_name+ " "   + "1 Year");
					} else {
						name.setText(director_name + " " + director_last_name + " " +  String.valueOf(myAge) + " Years");
					}
				}else {
					name.setText(director_name + " " + director_last_name);
				}
				// TODO: Build address string here
				Log.i("FaceID","[LBCA onCreate] User data is allowed: " + userData + " | " + userAddress1);
				if(userData.equalsIgnoreCase("yes")&&individual_level.equalsIgnoreCase("2")&&account_type.equalsIgnoreCase("business"))
				{
					Log.i("FaceID","[LBCA onCreate] Building address string");
					String addressString = userAddress1;
					if(userAddress2.length()>0)
					{
						addressString = addressString + ", ";
						addressString = addressString + userAddress2;
					}
					if(userTown.length()>0)
					{
						addressString = addressString + ", ";
						addressString = addressString + userTown;
					}
					if(userCounty.length()>0)
					{
						addressString = addressString + ", ";
						addressString = addressString + userCounty;
					}
					if(userPostcode.length()>0)
					{
						addressString = addressString + ", ";
						addressString = addressString + userPostcode;
					}
					Log.i("FaceID","[LBCA onCreate] Address string: " + addressString);
					address.setText(addressString);
				}
				else
				{
					Log.i("FaceID","[LBCA onCreate] Not allowed to show address");
					address.setText("");
				}
				Log.i("FaceID","[LBCA onCreate] Built address string");

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		bc_ll.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				startActivity(new Intent(LatestBusinessCardActivity.this,MemberIdActivity.class));
				finish();
			}
		});
		

	}
	
	public int getAge (int _year, int _month, int _day) {

        GregorianCalendar cal = new GregorianCalendar();
        int y, m, d, a;         

        y = cal.get(Calendar.YEAR);
        m = cal.get(Calendar.MONTH)+1;
        d = cal.get(Calendar.DAY_OF_MONTH);
        cal.set(_year, _month, _day);
        a = y - cal.get(Calendar.YEAR);
        if ((m < cal.get(Calendar.MONTH))|| ((m == cal.get(Calendar.MONTH)) && (d < cal .get(Calendar.DAY_OF_MONTH)))) {
                --a;
        }
       /* if(a < 0)
                throw new IllegalArgumentException("Age < 0");*/
        return a;
    }

	@Override
	public void onBackPressed() {

	}

	public void getPref_indicator() {
		SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);
		director_name = sharedPref.getString("first_name", "");
		director_last_name = sharedPref.getString("last_name", "");
		director_dob = sharedPref.getString("dob", "");
		userAddress1 = sharedPref.getString("userAddress1","");
		userAddress2 = sharedPref.getString("userAddress2","");
		userTown = sharedPref.getString("userTown","");
		userPostcode = sharedPref.getString("userPostcode","");
		userCounty = sharedPref.getString("userCounty","");
		userData = sharedPref.getString("showVerifyAddress","");
		individual_level = sharedPref.getString("checkedMemberLevel","");

		account_type = sharedPref.getString("accountType","");
		Log.e("FaceID", "[LBCA getPrefInd] Director name: " + director_name + " " + director_dob);
	}
}
