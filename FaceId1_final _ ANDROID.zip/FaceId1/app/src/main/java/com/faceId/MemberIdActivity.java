package com.faceId;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Formatter;
import java.util.List;
import java.util.Locale;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.faceId.crashreport.ExceptionHandler;
import com.faceId.util.MyConstant;

/*
 * This is the dashbord where user insert there faceid and proceed for Authentication
 */

public class MemberIdActivity extends Activity {

	//int userID;

	//String is_model_created , trader_id , director1_name , director1_dob , identityID ;
	public String can_verify;
	//public String member_id;
	private String verifiers_work_address_postcode, verifiers_work_address_town, verifiers_work_address_2
			,verifiers_work_address;
	private String verifiers_company_name, verifiers_work_tel, verifiers_job_title, verifiers_occuption;
	private String verifiers_email, verifiers_last_name, verifiers_first_name;
	private String verifiers_title, verifiers_name, country_code, individual_level;
	private String verifies, account_type;
	private String postal_code, dob, gender, tel_no, mobile_number;
	private String title;
	private String address1, address2, town_city, country, showAddressVerify="";
	private String has_completed_tag;
	EditText member_id_et;
	ImageView member_sign_out;
	TextView member_id_tv, member_id_photo;
	String id, face_model_response, voice_model_response, member_id,
			trader_name, status, model_id_face, model_id_voice , member_id_login;
	LinearLayout member_id_failed, clear_ll, check_ll, member_expired, clear_all, clear_all_ns, clear_all_na, not_a_member, not_age_verified, not_started, not_active, not_live, clear_nam;
	ProgressDialog pDialog;
	ArrayList<String> filePathArray, base64Array;
	boolean isNetworkAvailable;

	String[] all_path;
	ArrayList<Integer> int_height;
	ArrayList<Integer> int_width;
	TextView textView1, textView2, textView3;
	ArrayList<Long> file_size;
	ArrayList<Integer> image_res;
	String error;
	private String identity_id_voice;
	private String identity_id;
	EditText threshold_et;
	LinearLayout model_ll;
	private String identity_created;
	private String identities_id;
	private String is_model_created , trader_id, userID;
	private String type = null;

	public String director1_dob;
	private String identityID;
	public String first_name;
	public String last_name , identityID_login ,member_id_login_act;
	public String expiryDate="", startDate="", userAddress1, userAddress2, userTown, userCounty, userPostcode, userDataAllow;
	public Integer checkedMemberID, checkedMemberLevel;
	private RelativeLayout signOut ;
	private String email_id;
	private String has_faceid;
	private String account_status;
	private String sub_user_only;
	ArrayList<String> arrSubUsers=new ArrayList<>();
	ArrayList<String> arrSubUsersStartDate=new ArrayList<>();
	ArrayList<String> arrSubUsersExpiryDate=new ArrayList<>();
	private boolean isUser=false;
	private String strExpiryDate="";
	String m_id="";
	public static String user_id="";
	private String pass="";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.add_member_id);
		Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(this));

		member_id_et = (EditText) findViewById(R.id.member_id_et);
		member_sign_out = (ImageView) findViewById(R.id.member_sign_out);
		member_id_tv = (TextView) findViewById(R.id.member_id_tv);
		member_id_photo = (TextView) findViewById(R.id.member_id_photo);
		member_id_failed = (LinearLayout) findViewById(R.id.member_id_failed);
		member_expired = (LinearLayout) findViewById(R.id.member_expired);
		not_started = (LinearLayout) findViewById(R.id.not_started);
		not_active = (LinearLayout) findViewById(R.id.not_active);
		not_live=(LinearLayout)findViewById(R.id.not_live);
		not_a_member = (LinearLayout) findViewById(R.id.not_a_member);
		not_age_verified = (LinearLayout) findViewById(R.id.not_age_verified_lvl1);
		clear_ll = (LinearLayout) findViewById(R.id.clear_ll);
		clear_all = (LinearLayout) findViewById(R.id.clear_all_expired);
		clear_all_ns = (LinearLayout) findViewById(R.id.clear_all_not_started);
		clear_all_na = (LinearLayout) findViewById(R.id.clear_all_not_active);
		clear_nam = (LinearLayout) findViewById(R.id.clear_all_not_a_member);
		check_ll = (LinearLayout) findViewById(R.id.check_ll);
		threshold_et = (EditText) findViewById(R.id.threshold_et);
		int_height = new ArrayList<Integer>();
		int_width = new ArrayList<Integer>();
		textView1 = (TextView) findViewById(R.id.textView1);
		textView2 = (TextView) findViewById(R.id.textView2);
		model_ll = (LinearLayout) findViewById(R.id.model_ll);
		signOut = (RelativeLayout) findViewById(R.id.signOut);
//		textView3 = (TextView) findViewById(R.id.textView3);

		image_res = new ArrayList<Integer>();
		getPref();
		file_size = new ArrayList<Long>();

		member_id_failed.setVisibility(View.GONE);
		member_expired.setVisibility(View.GONE);
		not_a_member.setVisibility(View.GONE);
		not_age_verified.setVisibility(View.GONE);
		not_started.setVisibility(View.GONE);
		not_active.setVisibility(View.GONE);
		not_live.setVisibility(View.GONE);
		check_ll.setVisibility(View.VISIBLE);
		filePathArray = new ArrayList<String>();
		base64Array = new ArrayList<String>();


		/*if (!member_id_login_act.equalsIgnoreCase("")) {
			if (identityID_login.equalsIgnoreCase("")) {
				if (!is_model_created.equalsIgnoreCase("0")) {
					model_ll.setVisibility(View.VISIBLE);
				} else {
					model_ll.setVisibility(View.INVISIBLE);
				}
			}else {
				model_ll.setVisibility(View.VISIBLE);
			}
		} else {
			model_ll.setVisibility(View.INVISIBLE);
		}*/



		member_id_tv.setText(id);
		member_id_tv.setTextColor(Color.WHITE);
		member_id_photo.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				m_id= member_id_et.getText().toString();


				type = "photo";
				if (!member_id_et.getText().toString().equalsIgnoreCase("")) {
					isNetworkAvailable = isNetworkAvailable();
					save_preference_threshold();
					if (isNetworkAvailable) {

						boolean isNetworkAvailable = isNetworkAvailable();
						if (isNetworkAvailable) {
							new login_Api().execute();
						} else {
							Toast t= Toast.makeText(MemberIdActivity.this,
									"Please Check Your Internet Connection",
									Toast.LENGTH_LONG);
							t.show();
						}
						//new Get_UserID_Api().execute(m_id);
					} else {
						AlertMessage(MemberIdActivity.this,
								"Please Check your Internet Connection");
					}
				} else {
					Toast.makeText(MemberIdActivity.this,
							"Please Enter FACE.ID", Toast.LENGTH_LONG).show();
				}
				/*if(m_id.isEmpty()||m_id.equalsIgnoreCase(" ")||m_id.length()==0){
					Toast.makeText(MemberIdActivity.this,
							"Please Enter FACE.ID", Toast.LENGTH_LONG).show();
				}else {
					if (m_id.equalsIgnoreCase(userID)) {
						startActivity(new Intent(MemberIdActivity.this, CameraActivity.class));
						overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
						finish();
					} else {
						Toast.makeText(MemberIdActivity.this,
								"Invalid FACE.ID", Toast.LENGTH_LONG).show();
					}
				}*/
			}
		});


		model_ll.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				startActivity(new Intent(MemberIdActivity.this , ShowModelActivity.class));
				overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
			}
		});

		member_id_failed.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				member_id_et.setText("");
				member_id_failed.setVisibility(View.GONE);
				check_ll.setVisibility(View.VISIBLE);
			}
		});

		member_expired.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				member_id_et.setText("");
				member_expired.setVisibility(View.GONE);
				check_ll.setVisibility(View.VISIBLE);
			}
		});

		not_a_member.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				member_id_et.setText("");
				not_a_member.setVisibility(View.GONE);
				check_ll.setVisibility(View.VISIBLE);
			}
		});

		not_age_verified.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				member_id_et.setText("");
				not_age_verified.setVisibility(View.GONE);
				check_ll.setVisibility(View.VISIBLE);
			}
		});

		not_started.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				member_id_et.setText("");
				not_started.setVisibility(View.GONE);
				check_ll.setVisibility(View.VISIBLE);
			}
		});

		not_active.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				member_id_et.setText("");
				not_active.setVisibility(View.GONE);
				check_ll.setVisibility(View.VISIBLE);
			}
		});
		not_live.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				member_id_et.setText("");
				not_live.setVisibility(View.GONE);
				check_ll.setVisibility(View.VISIBLE);
			}
		});


		signOut.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				save_preference_u_id();
				startActivity(new Intent(MemberIdActivity.this,	LoginActivity.class));
				SharedPreferences pref = PreferenceManager
						.getDefaultSharedPreferences(MemberIdActivity.this);
				Editor edit = pref.edit();

				edit.putString("indicator_num", String.valueOf(0));

				edit.putString("email_id", "");
				edit.putString("user_id", "");
				edit.putString("first_name", "");
				edit.putString("last_name", "");
				edit.putString("dob", "");

				edit.putString("checkedMemberID", "");
				edit.putString("checkedMemberLevel", "");
				edit.putString("accountType", "");
				edit.putString("subuseronly", "");
		/*edit.putString("startDate",startDate);
		edit.putString("expiryDate",expiryDate);*/
				edit.putString("userAddress1","");
				edit.putString("userAddress2","");
				edit.putString("userTown","");
				edit.putString("userCounty","");
				edit.putString("userCounty_code","");
				edit.putString("userPostcode", "");
				edit.putString("userDataAllow", "No");
				edit.putString("hasCompletedTag", "");


				edit.putString("director_name","");
				edit.putString("director_last_name", "");
				edit.putString("director_dob","");
				edit.putString("userAddress1","");
				edit.putString("userAddress2","");
				edit.putString("userTown","");
				edit.putString("userCounty","");
				edit.putString("userDataAllow","No");

				edit.commit();

				finish();
			}
		});
	}

	private boolean isNetworkAvailable() {
		ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo activeNetworkInfo = connectivityManager
				.getActiveNetworkInfo();
		return activeNetworkInfo != null && activeNetworkInfo.isConnected();
	}

	@Override
	public void onBackPressed() {
		super.onBackPressed();
		/*startActivity(new Intent(MemberIdActivity.this , SelectionActivity.class));
		finish();*/
	}

	public void getPref() {
		SharedPreferences shre = PreferenceManager.getDefaultSharedPreferences(this);
		id = shre.getString("email_id", "");
		pass=shre.getString("pass", "");
		identities_id = shre.getString("identities_data_face", "");
		is_model_created = shre.getString("is_model_created", "");
		identity_created = shre.getString("identity_created", "");
		identityID = shre.getString("identityID", "");
		identityID_login = shre.getString("identityID_login", "");
		trader_id = shre.getString("trader_id", "");
		userID = shre.getString("user_id", "");
		member_id_login = shre.getString("member_id", "");
		member_id_login_act= shre.getString("member_id_login_act", "");
		sub_user_only= shre.getString("subuseronly", "");
		account_type=shre.getString("accountType", "");
		dob=shre.getString("dob", "");
		arrSubUsers.clear();
		/*int size = shre.getInt("subUsers_size", 0);

		for (int i=0;i<size;i++)
		{
			arrSubUsers.add(shre.getString("subUsers" + i, null));
			arrSubUsersStartDate.add(shre.getString("subUsersStartDate" + i, null));
			arrSubUsersExpiryDate.add(shre.getString("subUsersExpiryDate" + i, null));

		}*/
		System.out.println("SUNUSERS Data :"+arrSubUsers.toString());

	}

	public class face_model_Api extends AsyncTask<String, String, String>
	{

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			//pDialog = ProgressDialog.show(MemberIdActivity.this, "","Please Wait");
		}

		@Override
		protected String doInBackground(String... params) {
			String m_id = params[0];

			HttpParams httpParameters = new BasicHttpParams();
			HttpConnectionParams.setConnectionTimeout(httpParameters, 10000);
			HttpConnectionParams.setSoTimeout(httpParameters, 10000);
			HttpClient httpclient = new DefaultHttpClient();
			HttpResponse response = null;
			String responseText = null;
			HttpPost httppost = new HttpPost(MyConstant.LOGIN_URL);
			try {
				List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
				nameValuePairs.add(new BasicNameValuePair("member_id",m_id));
				//nameValuePairs.add(new BasicNameValuePair("member_id","9616"));
//				nameValuePairs.add(new BasicNameValuePair("modality", "faces"));

				httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

				// Execute HTTP Post Request
				response = httpclient.execute(httppost);
				Log.v("FaceID", "[MIA faceModelAPI] StatusCode: "+ response.getStatusLine().getStatusCode());
				HttpEntity entity = response.getEntity();
				responseText = EntityUtils.toString(entity);
//				Log.v("FaceID: member ID",member_id);
				Log.v("FaceID", "[MIA faceModelAPI] Response: " + responseText);

				// Json Parsing
				JSONObject obj = (JSONObject) new JSONTokener(responseText).nextValue();
				JSONObject resObj = obj.getJSONObject("response");

				// Face model responses:
				/*
				1: go straight to scanning
				2: Expired
				3: exists but is not a member of the business
				4: level 1 ID, not age verified
				5: Not yet started
				6: Not yet active
				*/
				face_model_response = resObj.getString("status");

				if (face_model_response.equals("1")) {

					first_name = resObj.getString("first_name");
					last_name = resObj.getString("last_name");
					director1_dob = resObj.getString("dob");
					identity_id = resObj.getString("identity_id");
					String msg = resObj.getString("message");

					// Now send to the FaceID API to see if the logged in user is a business and that the punter is a member
					HttpResponse faceIDAPIresponse = null;
					String faceIDAPIResponseText = null;
					String API_version = "?ver=1.0";
					HttpPost memberCheckHttpPost = new HttpPost(MyConstant.FACEID_API + API_version);
					List<NameValuePair> faceIDAPIValuePairs = new ArrayList<NameValuePair>(2);
					Log.v("FaceID", "[MIA faceModelAPI] Sending ID: " + userID);
					faceIDAPIValuePairs.add(new BasicNameValuePair("business_id", userID));
					faceIDAPIValuePairs.add(new BasicNameValuePair("member_id",m_id));
					//faceIDAPIValuePairs.add(new BasicNameValuePair("member_id","9616"));
					memberCheckHttpPost.setEntity(new UrlEncodedFormEntity(faceIDAPIValuePairs));

					// Execute HTTP Post Request
					faceIDAPIresponse = httpclient.execute(memberCheckHttpPost);
					Log.v("FaceID", "[MIA faceModelAPI] FaceID API StatusCode: "+ faceIDAPIresponse.getStatusLine().getStatusCode());
					HttpEntity memberCheckEntity = faceIDAPIresponse.getEntity();
					faceIDAPIResponseText = EntityUtils.toString(memberCheckEntity);
					Log.v("FaceID","[MIA faceModelAPI] FaceID API Response: " + faceIDAPIResponseText);
					// Json Parsing
					JSONObject memberCheckObj = (JSONObject) new JSONTokener(faceIDAPIResponseText).nextValue();
					Integer business = memberCheckObj.getInt("business");
					if(business == 1)
					{
						if(memberCheckObj.isNull("member"))
						{
							// The faceID exists, but is not a member of the business
							face_model_response = "3";
						}
						else {
							JSONObject memberCheckResObj = memberCheckObj.getJSONObject("member");
							checkedMemberID = memberCheckResObj.getInt("user_id");
							checkedMemberLevel = memberCheckResObj.getInt("user_level");
							startDate = memberCheckResObj.getString("start_date");
							expiryDate = memberCheckResObj.getString("expiry_date");
							userAddress1 = "";
							userAddress2 = "";
							userTown = "";
							userCounty = "";
							userPostcode = "";
							userDataAllow = "no";
							SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.UK);
							Date date = new Date();
							String datetime = sdf.format(date);
							Log.v("FaceID","Today: "+ datetime);
							try {
								Date expireDate = sdf.parse(expiryDate);
								Date beginDate = sdf.parse(startDate);
								Date dateToday = sdf.parse(datetime);
								Integer dateCheckB = beginDate.compareTo(dateToday);
								Integer dateCheckE = expireDate.compareTo(dateToday);
								Log.i("FaceID: Start date", dateCheckB.toString());
								Log.i("FaceID: Expiry date", dateCheckE.toString());
								switch(dateCheckE){
									case -1:
										// Expired
										face_model_response = "2";
										break;
									case 0:
										// Expires today
										face_model_response = "1";
										break;
									case 1:
										// Expires in the future
										face_model_response = "1";
										break;
									default:
										face_model_response = "1";
										break;
								}
								switch(dateCheckB){
									case 1:
										// Starts in the future
										face_model_response = "5";
										break;
									default:
										break;
								}
								Log.v("FaceID: response code", face_model_response);
							}
							catch (ParseException e) {
								e.printStackTrace();
							}
						}
					}
					else
					{
						// We're either a business that doesn't care about memberships or we're not a business
						Log.v("FaceID","[MIA faceModelAPI doInBackground] Not a business / don't care about memberships");
						if(memberCheckObj.isNull("member")) {
							// The faceID exists, but is not a member of the business
							face_model_response = "6";
							checkedMemberID = 0;
							checkedMemberLevel = 0;
							startDate = "";
							expiryDate = "";
							userAddress1 = "";
							userAddress2 = "";
							userTown = "";
							userCounty = "";
							userPostcode = "";
							userDataAllow = "no";
						}
						else
						{
							JSONObject memberCheckResObj = memberCheckObj.getJSONObject("member");
							checkedMemberID = memberCheckResObj.getInt("user_id");
							checkedMemberLevel = memberCheckResObj.getInt("user_level");
							userAddress1 = memberCheckResObj.getString("user_address1");
							userAddress2 = memberCheckResObj.getString("user_address2");
							userTown = memberCheckResObj.getString("user_town");
							userCounty = memberCheckResObj.getString("user_county");
							userPostcode = memberCheckResObj.getString("user_postcode");
							userDataAllow = memberCheckResObj.getString("user_data");
							switch(checkedMemberLevel){
								case 2:
									// Age verification details supplied
									face_model_response = "1";
									break;
								default:
									// Age not verified
									face_model_response = "4";
									break;
							}
							startDate = "";
							expiryDate = "";
							startDate = "";
							expiryDate = "";
						}
					}
				}



			} catch (Exception e) {
				e.printStackTrace();
				/*runOnUiThread(new Runnable() {
					public void run() {
						AlertMessage(MemberIdActivity.this,
								"Your Internet Connection is Poor");
					}
				});
*/
			}
			Log.v("FaceID: returning", face_model_response);
			return face_model_response;
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			pDialog.dismiss();
			if (result != null) {

				Log.e("FaceID", "[MIA faceAPI onPostExe]: " + result);
				if (result.equals("-1")) {
					Log.i("FaceID","[faceAPI MA onPostExe] Failed, going away");
					check_ll.setVisibility(View.GONE);
					member_id_failed.setVisibility(View.VISIBLE);
				}
				else {
					if (result.equals("1"))
					{
						Log.i("FaceID","Going to scan");
						save_preference_face();

						if (type.equalsIgnoreCase("photo")) {
							startActivity(new Intent(MemberIdActivity.this,CameraActivity.class));
							overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
							finish();
						} else if (type.equalsIgnoreCase("model"))
						{
							// TODO: Check whether we need this... it doesn't appear to be possible to get here
							startActivity(new Intent(MemberIdActivity.this , ShowModelActivity.class));
							overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
							finish();
						}
					} else if (result.equals("2")) {
						Log.i("FaceID","[faceAPI MA onPostExe] Expired");
						check_ll.setVisibility(View.GONE);
						member_expired.setVisibility(View.VISIBLE);
					} else if (result.equals("3")) {
						Log.i("FaceID","[faceAPI MA onPostExe] Exists but not member");
						check_ll.setVisibility(View.GONE);
						not_a_member.setVisibility(View.VISIBLE);
					} else if (result.equals("4")) {
						Log.i("FaceID", "[faceAPI MA onPostExe] Exists but not age verified");
						check_ll.setVisibility(View.GONE);
						not_age_verified.setVisibility(View.VISIBLE);
					} else if (result.equals("5")) {
						Log.i("FaceID", "[faceAPI MA onPostExe] Exists but not yet started");
						check_ll.setVisibility(View.GONE);
						not_started.setVisibility(View.VISIBLE);
					} else if (result.equals("6")) {
						Log.i("FaceID", "[faceAPI MA onPostExe] Might exist but isn't active");
						check_ll.setVisibility(View.GONE);
						not_active.setVisibility(View.VISIBLE);
					}
				}

			}
		}
	}


	public class Get_UserID_Api extends AsyncTask<String, String, String> {

		String password;
		@Override
		protected void onPreExecute() {

			super.onPreExecute();
			//pDialog = ProgressDialog.show(MemberIdActivity.this, "", "Please Wait");

		}

		@Override
		protected String doInBackground(String... params) {
			String m_id = params[0];
			HttpParams httpParameters = new BasicHttpParams();
			HttpConnectionParams.setConnectionTimeout(httpParameters, 10000);
			HttpConnectionParams.setSoTimeout(httpParameters, 10000);
			HttpClient httpclient = new DefaultHttpClient();
			String responseText = null;
			HttpResponse response = null;
			HttpPost httppost = new HttpPost(MyConstant.LOGIN_URL);

			JSONArray jArr=new JSONArray();

			try {
				JSONObject jObj = new JSONObject();
				jObj.put("member_id", m_id);

				//jObj.put("private", "c1IaqR8Dp7L6sLVbq5b2VlsouTN0ezNAYYnmf0WGb6zbxT7P");
				//jArr.put(jObj);

				String a = jObj.toString() + "c1IaqR8Dp7L6sLVbq5b2VlsouTN0ezNAYYnmf0WGb6zbxT7P";

				String token = encryptPassword(a);
				//5019906bf46dd9302c6deae5a04d41e6f1b84bdc


				List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(4);
				nameValuePairs.add(new BasicNameValuePair("request", "getUserId"));
				nameValuePairs.add(new BasicNameValuePair("data", jObj.toString()));
				nameValuePairs.add(new BasicNameValuePair("token", token));
				nameValuePairs.add(new BasicNameValuePair("public_key", "faceid"));
				httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				String request = MyConstant.LOGIN_URL + "UserValidate" + user_id + " : " + password;
				Log.v("FaceID: requested URl", "requested URL while LoginProcess :" + request);
				// Execute HTTP Post Request
				response = httpclient.execute(httppost);
				Log.v("FaceID Post Status", "Code: " + response.getStatusLine().getStatusCode());
				HttpEntity entity = response.getEntity();
				responseText = EntityUtils.toString(entity);
				Log.v("FaceID Response", "Response while Login" + responseText);
				// Json Parsing
				JSONObject obj = (JSONObject) new JSONTokener(responseText).nextValue();

				if (!responseText.contains("error")) {
					user_id = obj.getString("user_id");
					//userID=Integer.parseInt(userid);

					JSONObject jsonObjectUSer_meta = obj.getJSONObject("user_meta");
				/*login_response = obj.getString("status");
				Log.v("FaceID login_response ",login_response);
				*/


					if (!jsonObjectUSer_meta.toString().equals(" ")) {

						//JSONArray jsonArray=jsonObjectUSer_meta.getJSONArray("has_faceid");
						//has_faceid=jsonArray.get(0).toString();

						JSONArray jsonA = jsonObjectUSer_meta.getJSONArray("nickname");
						email_id = jsonA.get(0).toString();


						JSONArray jsonA1 = jsonObjectUSer_meta.getJSONArray("first_name");
						first_name = jsonA1.get(0).toString();

						JSONArray jsonA2 = jsonObjectUSer_meta.getJSONArray("last_name");
						last_name = jsonA2.get(0).toString();

						JSONArray jsonA3 = jsonObjectUSer_meta.getJSONArray("title");
						title = jsonA3.get(0).toString();

						/*JSONArray jsonA4 = jsonObjectUSer_meta.getJSONArray("mobile_number");
						mobile_number = jsonA4.get(0).toString();

						JSONArray jsonA5 = jsonObjectUSer_meta.getJSONArray("formatted_phone_number");
						tel_no = jsonA5.get(0).toString();*/

						JSONArray jsonA6 = jsonObjectUSer_meta.getJSONArray("gender");
						gender = jsonA6.get(0).toString();

						JSONArray jsonA7=jsonObjectUSer_meta.getJSONArray("dob");
						dob=jsonA7.get(0).toString();

						JSONArray jsonA8 = jsonObjectUSer_meta.getJSONArray("post_code");
						postal_code = jsonA8.get(0).toString();

						//JSONArray jsonA9=jsonObjectUSer_meta.getJSONArray("account_type");
						//account_type=jsonA9.get(0).toString();

						JSONArray jsonA10 = jsonObjectUSer_meta.getJSONArray("verifies");
						verifies = jsonA10.get(0).toString();

						JSONArray jsonA11 = jsonObjectUSer_meta.getJSONArray("member_id");
						member_id = jsonA11.get(0).toString();

						JSONArray jsonA12 = jsonObjectUSer_meta.getJSONArray("has_faceid");
						has_faceid = jsonA12.get(0).toString();

						JSONArray jsonA13 = jsonObjectUSer_meta.getJSONArray("individual_level");
						individual_level = jsonA13.get(0).toString();

						JSONArray jsonA124 = jsonObjectUSer_meta.getJSONArray("account_status");
						account_status = jsonA124.get(0).toString();

						//JSONArray jsonA14 = jsonObjectUSer_meta.getJSONArray("country_code");
						//country_code = jsonA14.get(0).toString();
						country_code="";

						if(individual_level.equalsIgnoreCase("2")){

						JSONArray jsonArrShowAddress = jsonObjectUSer_meta.optJSONArray("show_address_verify");
							if(jsonArrShowAddress!=null)
							showAddressVerify = jsonArrShowAddress.get(0).toString();
							else
								showAddressVerify="";
						}else{
							showAddressVerify="";
						}
						JSONArray jsonA24 = jsonObjectUSer_meta.getJSONArray("address_line1");
						address1 = jsonA24.get(0).toString();

						JSONArray jsonA25 = jsonObjectUSer_meta.getJSONArray("address_line2");
						address2 = jsonA25.get(0).toString();

						JSONArray jsonA26 = jsonObjectUSer_meta.getJSONArray("town_city");
						town_city = jsonA26.get(0).toString();

						JSONArray jsonA27 = jsonObjectUSer_meta.getJSONArray("county");
						country = jsonA27.get(0).toString();

						//JSONArray jsonA123=jsonObjectUSer_meta.getJSONArray("has_completed_tags");
						//has_completed_tag=jsonA123.get(0).toString();




						/*JSONArray jsonA15 = jsonObjectUSer_meta.getJSONArray("verifiers_title");
						verifiers_title = jsonA15.get(0).toString();

						JSONArray jsonA16 = jsonObjectUSer_meta.getJSONArray("verifiers_name");
						verifiers_name = jsonA16.get(0).toString();

						JSONArray jsonA17 = jsonObjectUSer_meta.getJSONArray("verifiers_first_name");
						verifiers_first_name = jsonA17.get(0).toString();

						JSONArray jsonA18 = jsonObjectUSer_meta.getJSONArray("verifiers_last_name");
						verifiers_last_name = jsonA18.get(0).toString();

						JSONArray jsonA19 = jsonObjectUSer_meta.getJSONArray("verifiers_email");
						verifiers_email = jsonA19.get(0).toString();

						JSONArray jsonA20 = jsonObjectUSer_meta.getJSONArray("verifiers_occupation");
						verifiers_occuption = jsonA20.get(0).toString();

						JSONArray jsonA21 = jsonObjectUSer_meta.getJSONArray("verifiers_job_title");
						verifiers_job_title = jsonA21.get(0).toString();

						JSONArray jsonA22 = jsonObjectUSer_meta.getJSONArray("verifiers_work_telephone");
						verifiers_work_tel = jsonA22.get(0).toString();

						JSONArray jsonA23 = jsonObjectUSer_meta.getJSONArray("verifiers_company_name");
						verifiers_company_name = jsonA23.get(0).toString();

						JSONArray jsonA31 = jsonObjectUSer_meta.getJSONArray("verifiers_work_address_street");
						verifiers_work_address = jsonA31.get(0).toString();

						JSONArray jsonA32 = jsonObjectUSer_meta.getJSONArray("verifiers_work_address_street2");
						verifiers_work_address_2 = jsonA32.get(0).toString();

						JSONArray jsonA33 = jsonObjectUSer_meta.getJSONArray("verifiers_work_address_town");
						verifiers_work_address_town = jsonA33.get(0).toString();

						JSONArray jsonA34 = jsonObjectUSer_meta.getJSONArray("verifiers_work_address_postcode");
						verifiers_work_address_postcode = jsonA34.get(0).toString();
*/
						// Face model responses:
					/*
					1: go straight to scanning
					2: Expired
					3: exists but is not a member of the business
					4: level 1 ID, not age verified
					5: Not yet started
					6: Not yet active
					*/

					/*if(individual_level.equalsIgnoreCase("2")&&sub_user_only.equalsIgnoreCase("Yes")){
						face_model_response="1";
					}
					else if(account_type.equalsIgnoreCase("business")&&isUser){
						face_model_response="1";
					}
					else if(account_type.equalsIgnoreCase("individual")&&individual_level.equalsIgnoreCase("2")){
						face_model_response="1";
					}
					else if(!account_status.equalsIgnoreCase("active")){
						face_model_response="6";
					}
					else if(account_type.equalsIgnoreCase("individual")&&!isUser){
						face_model_response="3";
					}
					else if(account_type.equalsIgnoreCase("individual")&&verifies.equalsIgnoreCase("0")){
						face_model_response="4";
					}*/
						Integer dateCheckB = 0;
						Integer dateCheckE = 0;
						if (account_type.equalsIgnoreCase("Business")) {

							if (expiryDate != null && !expiryDate.equalsIgnoreCase("")) {
								SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.UK);
								Date date = new Date();
								String datetime = sdf.format(date);
								Log.v("FaceID", "Today: " + datetime);
								try {
									Date expireDate = sdf.parse(expiryDate);
									Date beginDate = sdf.parse(startDate);
									Date dateToday = sdf.parse(datetime);
									dateCheckB = beginDate.compareTo(dateToday);
									dateCheckE = expireDate.compareTo(dateToday);
									Log.i("FaceID: Start date", dateCheckB.toString());
									Log.i("FaceID: Expiry date", dateCheckE.toString());
									switch (dateCheckE) {
										case -1:
											// Expired
											face_model_response = "2";
											break;
										case 0:
											// Expires today
											//face_model_response = "1";
											break;
										case 1:
											// Expires in the future
											//face_model_response = "1";
											break;
										default:
											//face_model_response = "1";
											break;
									}
									switch (dateCheckB) {
										case 1:
											// Starts in the future
											face_model_response = "5";
											break;
										default:
											break;
									}
								} finally {

								}
							}
						}
						if(sub_user_only.equalsIgnoreCase("Yes")){
							if (!account_status.equalsIgnoreCase("active")) {
								face_model_response = "6";
							}
							/*else if (dateCheckB.toString().equalsIgnoreCase("1")) {
								face_model_response = "5";
							}
							else if (!dateCheckE.toString().equalsIgnoreCase("1")) {
								face_model_response = "2";
							}*/
							else if (individual_level.equalsIgnoreCase("2") && sub_user_only.equalsIgnoreCase("Yes")) {
								face_model_response = "1";
							}else{
								face_model_response = "4";
							}

						}else if(account_type.equalsIgnoreCase("business")){

							if (account_type.equalsIgnoreCase("business") && !isUser) {
								face_model_response = "3";
							}
							else if (!account_status.equalsIgnoreCase("active")) {
								face_model_response = "6";
							}
							else if (dateCheckB.toString().equalsIgnoreCase("1")) {
								face_model_response = "5";
							}
							else if (!dateCheckE.toString().equalsIgnoreCase("1")) {
								face_model_response = "2";
							}
							else if (account_type.equalsIgnoreCase("business") && isUser && !dateCheckE.toString().equalsIgnoreCase("-1")) {
								face_model_response = "1";
							}
						}

						else {
							if (!account_status.equalsIgnoreCase("active")) {
								face_model_response = "6";
							}
							else if (account_type.equalsIgnoreCase("individual") && individual_level.equalsIgnoreCase("2")) {
								face_model_response = "1";
							} else {
								face_model_response = "4";
							}
						}
					}


					else {
						face_model_response = "5";
					}
				}
				else {
					face_model_response = "0";
				}
			}catch (Exception e) {
				e.printStackTrace();
				/*runOnUiThread(new Runnable() {
					public void run() {
						AlertMessage(LoginActivity.this,
								"Your Internet Connection is Poor");
					}
				});*/

			}
			return face_model_response;
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			pDialog.dismiss();
			if (result!="0"&&result!=null) {

				Log.e("FaceID", "[MIA faceAPI onPostExe]: " + result);
				if (result.equals("-1")) {
					Log.i("FaceID","[faceAPI MA onPostExe] Failed, going away");
					check_ll.setVisibility(View.GONE);
					member_id_failed.setVisibility(View.VISIBLE);
				}
				else {
					if (result.equals("1"))
					{
						Log.i("FaceID","Going to scan");
						save_preference_face();

						if (type.equalsIgnoreCase("photo")) {
							startActivity(new Intent(MemberIdActivity.this,CameraActivity.class));
							overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
							finish();
						} else if (type.equalsIgnoreCase("model"))
						{
							// TODO: Check whether we need this... it doesn't appear to be possible to get here
							startActivity(new Intent(MemberIdActivity.this , ShowModelActivity.class));
							overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
							finish();
						}
					} else if (result.equals("2")) {
						Log.i("FaceID","[faceAPI MA onPostExe] Expired");
						check_ll.setVisibility(View.GONE);
						member_expired.setVisibility(View.VISIBLE);
					} else if (result.equals("3")) {
						Log.i("FaceID","[faceAPI MA onPostExe] Exists but not member");
						check_ll.setVisibility(View.GONE);
						not_a_member.setVisibility(View.VISIBLE);
					} else if (result.equals("4")) {
						Log.i("FaceID", "[faceAPI MA onPostExe] Exists but not age verified");
						check_ll.setVisibility(View.GONE);
						not_age_verified.setVisibility(View.VISIBLE);
					} else if (result.equals("5")) {
						Log.i("FaceID", "[faceAPI MA onPostExe] Exists but not yet started");
						check_ll.setVisibility(View.GONE);
						not_started.setVisibility(View.VISIBLE);
					} else if (result.equals("6")) {
						Log.i("FaceID", "[faceAPI MA onPostExe] Might exist but isn't active");
						check_ll.setVisibility(View.GONE);
						not_active.setVisibility(View.VISIBLE);
					}
				}
			}else{
				Log.i("FaceID", "[faceAPI MA onPostExe] Might exist but isn't active");
				check_ll.setVisibility(View.GONE);
				not_live.setVisibility(View.VISIBLE);
			}

		}
	}
	private static String encryptPassword(String password)
	{
		String sha1 = "";
		try
		{
			MessageDigest crypt = MessageDigest.getInstance("SHA-1");
			crypt.reset();
			crypt.update(password.getBytes("UTF-8"));
			sha1 = byteToHex(crypt.digest());
		}
		catch(NoSuchAlgorithmException e)
		{
			e.printStackTrace();
		}
		catch(UnsupportedEncodingException e)
		{
			e.printStackTrace();
		}
		return sha1;
	}
	public void save_preference() {
		SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(MemberIdActivity.this);
		Editor edit = pref.edit();
		//edit.putString("identityID", identity_id);
		//Log.e("model_id", "[MIA save_preference_face] face_model_id " + identity_id);

		edit.putString("user_id", userID);
		edit.putString("first_name", first_name);
		edit.putString("last_name", last_name);
		edit.putString("dob", dob);

		edit.putString("checkedMemberID", member_id);
		edit.putString("checkedMemberLevel", individual_level);
		/*edit.putString("startDate",startDate);
		edit.putString("expiryDate",expiryDate);*/
		edit.putString("userAddress1",address1);
		edit.putString("userAddress2",address2);
		edit.putString("userTown",town_city);
		edit.putString("userCounty",country);
		edit.putString("userCounty_code",country_code);
		edit.putString("userPostcode", postal_code);
		edit.putString("userDataAllow", "No");
		edit.putString("hasCompletedTag", has_completed_tag);


		/*edit.putString("director_name",verifiers_first_name);
		edit.putString("director_last_name",verifiers_last_name);
		edit.putString("director_dob",dob);
		edit.putString("userAddress1",verifiers_work_address);
		edit.putString("userAddress2",verifiers_work_address_2);
		edit.putString("userTown",verifiers_work_address_town);
		edit.putString("userCounty",verifiers_work_address_postcode);*/
		edit.putString("userDataAllow","No");

		edit.commit();
	}

	private static String byteToHex(final byte[] hash)
	{
		Formatter formatter = new Formatter();
		for (byte b : hash)
		{
			formatter.format("%02x", b);
		}
		String result = formatter.toString();
		formatter.close();
		return result;
	}
	public static void AlertMessage(Activity _this, String msg) {
		AlertDialog.Builder builder = new AlertDialog.Builder(_this);
		builder.setMessage(msg);
		builder.setPositiveButton("OK", null);
		AlertDialog alert11 = builder.show();
		TextView messageText = (TextView) alert11.findViewById(android.R.id.message);
		messageText.setGravity(Gravity.CENTER);
		alert11.show();
	}

	public class voice_model_Api extends AsyncTask<String, String, String> {



		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			pDialog = ProgressDialog.show(MemberIdActivity.this, "","Please Wait");
		}

		@Override
		protected String doInBackground(String... params) {
			String m_id = params[0];

			HttpParams httpParameters = new BasicHttpParams();
			HttpConnectionParams.setConnectionTimeout(httpParameters, 10000);
			HttpConnectionParams.setSoTimeout(httpParameters, 10000);
			HttpClient httpclient = new DefaultHttpClient();
			HttpResponse response = null;
			String responseText = null;
			HttpPost httppost = new HttpPost(MyConstant.URL+ "TraderModelRequest");
			try {

				List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
				nameValuePairs.add(new BasicNameValuePair("member_id",m_id));
				nameValuePairs.add(new BasicNameValuePair("modality", "voices"));

				httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

				// Execute HTTP Post Request
				response = httpclient.execute(httppost);
				Log.v("Post Status", "Code: "+ response.getStatusLine().getStatusCode());
				HttpEntity entity = response.getEntity();
				responseText = EntityUtils.toString(entity);
				Log.v("Response", "Response while face" + responseText);

				// Json Parsing
				JSONObject obj = (JSONObject) new JSONTokener(responseText)
						.nextValue();
				voice_model_response = obj.getString("status");
				Log.v("res value :", "res variable face" + face_model_response);

				if (voice_model_response.equals("1")) {
					JSONObject data_obj = obj.getJSONObject("data");
					member_id = data_obj.getString("member_id");
					trader_name = data_obj.getString("trader_name");
					status = data_obj.getString("status");
					model_id_voice = data_obj.getString("model_id");
					identity_id_voice = data_obj.getString("identity_id");
				}

			} catch (Exception e) {
				e.printStackTrace();
				/*runOnUiThread(new Runnable() {
					public void run() {
						AlertMessage(MemberIdActivity.this,
								"Your Internet Connection is Poor");
					}
				});*/

			}
			return voice_model_response;
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			pDialog.dismiss();
			if (result != null) {
				Log.e("FaceID", "voiceAPI MA onPostExe: " + result);
				if (result.equals("1")) {
					Log.i("FaceID","Going to scan");
					save_preference_voice();
					startActivity(new Intent(MemberIdActivity.this,CreateModelActivityFromCamera.class));
					overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
//				} else if (result.equals("-1")) {
				} else {
					Log.i("FaceID","going away");
					check_ll.setVisibility(View.GONE);
					member_id_failed.setVisibility(View.VISIBLE);
				}
			}
		}
	}

	public void save_preference_face() {
		SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(MemberIdActivity.this);
		Editor edit = pref.edit();

		//edit.putString("identityID", identity_id);
		//Log.e("model_id", "[MIA save_preference_face] face_model_id " + identity_id);

		edit.putString("user_id", userID);
		edit.putString("first_name", first_name);
		edit.putString("last_name", last_name);
		edit.putString("dob", dob);

		edit.putString("checkedMemberID", member_id);
		edit.putString("checkedMemberLevel", individual_level);
		/*edit.putString("startDate",startDate);
		edit.putString("expiryDate",expiryDate);*/

		edit.putString("showVerifyAddress",showAddressVerify);
		edit.putString("userAddress1",address1);
		edit.putString("userAddress2",address2);
		edit.putString("userTown",town_city);
		edit.putString("userCounty",country);
		edit.putString("userCounty_code",country_code);
		edit.putString("userPostcode", postal_code);
		edit.putString("userDataAllow", "No");
		edit.putString("hasCompletedTag", has_completed_tag);


		/*edit.putString("director_name",verifiers_first_name);
		edit.putString("director_last_name",verifiers_last_name);
		edit.putString("director_dob",dob);
		edit.putString("userAddress1",verifiers_work_address);
		edit.putString("userAddress2",verifiers_work_address_2);
		edit.putString("userTown",verifiers_work_address_town);
		edit.putString("userCounty",verifiers_work_address_postcode);*/
		edit.putString("userDataAllow","No");

		edit.commit();
	}

	public void save_preference_voice() {
		SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(MemberIdActivity.this);
		Editor edit = pref.edit();
		edit.putString("identities_data_voice", identity_id_voice);
		edit.putString("director_name", first_name);
		edit.putString("director_dob", director1_dob);
		Log.e("model_id", "voice_model_id" + identity_id_voice);
		edit.commit();
	}

	public void save_preference_threshold() {
		SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(MemberIdActivity.this);
		Editor edit = pref.edit();
		if (threshold_et.getText().toString().trim().length() !=0) {
			edit.putString("thoreshold", threshold_et.getText().toString().trim());
			edit.putString("tracer_id", member_id_et.getText().toString());
			Log.e("threshold_et", "threshold_et" + threshold_et.getText().toString().trim());
			edit.commit();
		} else {
			edit.putString("thoreshold", "");
			edit.putString("tracer_id", member_id_et.getText().toString());
			Log.e("threshold_et", "threshold_et" + "");
			edit.commit();
		}

	}

	public void save_preference_u_id() {
		SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(MemberIdActivity.this);
		Editor edit = pref.edit();
		edit.putString("user_id", "");

		edit.commit();
	}

	public class login_Api extends AsyncTask<String, String, String> {

		String user_id, password;
		@Override
		protected void onPreExecute() {
			super.onPreExecute();

			pDialog = ProgressDialog.show(MemberIdActivity.this, "", "Please Wait");
			//user_id= userid_et.getText().toString().trim();
			//password = password_et.getText().toString().trim();
		}

		@Override
		protected String doInBackground(String... params) {

			HttpParams httpParameters = new BasicHttpParams();
			HttpConnectionParams.setConnectionTimeout(httpParameters, 10000);
			HttpConnectionParams.setSoTimeout(httpParameters, 10000);
			HttpClient httpclient = new DefaultHttpClient();
			String responseText = null;
			HttpResponse response = null;
			HttpPost httppost = new HttpPost(MyConstant.LOGIN_URL);

			JSONArray jArr=new JSONArray();

			try {
				JSONObject jObj=new JSONObject();
				jObj.put("email", id);
				jObj.put("password", pass);
				//jObj.put("private", "c1IaqR8Dp7L6sLVbq5b2VlsouTN0ezNAYYnmf0WGb6zbxT7P");
				//jArr.put(jObj);

				String a=jObj.toString()+"c1IaqR8Dp7L6sLVbq5b2VlsouTN0ezNAYYnmf0WGb6zbxT7P";

				String token=encryptPassword(a);
				//5019906bf46dd9302c6deae5a04d41e6f1b84bdc


				List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(4);
				nameValuePairs.add(new BasicNameValuePair("request", "authenticateUser"));
				nameValuePairs.add(new BasicNameValuePair("data",jObj.toString()));
				nameValuePairs.add(new BasicNameValuePair("token",token));
				nameValuePairs.add(new BasicNameValuePair("public_key","faceid"));
				httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				String request = MyConstant.LOGIN_URL + "UserValidate" + id + " : " + pass;
				Log.v("FaceID: requested URl", "requested URL while LoginProcess :" + request);
				// Execute HTTP Post Request
				response = httpclient.execute(httppost);
				Log.v("FaceID Post Status", "Code: " + response.getStatusLine().getStatusCode());
				HttpEntity entity = response.getEntity();
				responseText = EntityUtils.toString(entity);
				Log.v("FaceID Response", "Response while Login" + responseText);
				// Json Parsing
				JSONObject obj = (JSONObject) new JSONTokener(responseText).nextValue();

				if(obj.has("user_id"))
				{
					//String userid= obj.getString("user_id");
					userID= obj.getString("user_id");
					//userID=Integer.parseInt(userid);
				}


				JSONObject jsonObjectUSer_meta=obj.getJSONObject("user_meta");


				JSONArray jsonAuthenticatedUser=obj.getJSONArray("sub_users");
				arrSubUsers=new ArrayList<>();
				arrSubUsersStartDate=new ArrayList<>();
				arrSubUsersExpiryDate=new ArrayList<>();
				for(int i=0; i<jsonAuthenticatedUser.length(); i++){
					//arrSubUsers.add(jsonAuthenticatedUser.get(i).toString());
					JSONObject jObjSubUsers=jsonAuthenticatedUser.getJSONObject(i);
					arrSubUsers.add(jObjSubUsers.get("member_id").toString());
					arrSubUsersStartDate.add(jObjSubUsers.get("start_date").toString());
					arrSubUsersExpiryDate.add(jObjSubUsers.get("expiry_date").toString());


				}

				/*login_response = obj.getString("status");
				Log.v("FaceID login_response ",login_response);
				*/


				if (!jsonObjectUSer_meta.toString().equals(" ")) {

					//JSONArray jsonArray=jsonObjectUSer_meta.getJSONArray("has_faceid");
					//has_faceid=jsonArray.get(0).toString();

					JSONArray jsonA=jsonObjectUSer_meta.getJSONArray("nickname");
					email_id=jsonA.get(0).toString();


					JSONArray jsonA1=jsonObjectUSer_meta.getJSONArray("first_name");
					first_name=jsonA1.get(0).toString();

					JSONArray jsonA2=jsonObjectUSer_meta.getJSONArray("last_name");
					last_name=jsonA2.get(0).toString();

					JSONArray jsonA3=jsonObjectUSer_meta.getJSONArray("title");
					title=jsonA3.get(0).toString();

					JSONArray jsonA4=jsonObjectUSer_meta.getJSONArray("mobile_number");
					mobile_number=jsonA4.get(0).toString();

					JSONArray jsonA5=jsonObjectUSer_meta.getJSONArray("formatted_phone_number");
					tel_no=jsonA5.get(0).toString();

					JSONArray jsonA6=jsonObjectUSer_meta.getJSONArray("gender");
					gender=jsonA6.get(0).toString();

					JSONArray jsonA7=jsonObjectUSer_meta.getJSONArray("dob");
					dob=jsonA7.get(0).toString();

					JSONArray jsonA8=jsonObjectUSer_meta.getJSONArray("post_code");
					postal_code=jsonA8.get(0).toString();

					JSONArray jsonA9=jsonObjectUSer_meta.getJSONArray("account_type");
					account_type=jsonA9.get(0).toString();

					JSONArray jsonA10=jsonObjectUSer_meta.getJSONArray("verifies");
					verifies=jsonA10.get(0).toString();

					JSONArray jsonsubUserOnly=jsonObjectUSer_meta.getJSONArray("sub_users_only");
					sub_user_only=jsonsubUserOnly.get(0).toString();

					JSONArray jsonA11=jsonObjectUSer_meta.getJSONArray("member_id");
					member_id=jsonA11.get(0).toString();

					JSONArray jsonA12=jsonObjectUSer_meta.getJSONArray("has_faceid");
					has_faceid=jsonA12.get(0).toString();

					JSONArray jsonA13=jsonObjectUSer_meta.getJSONArray("individual_level");
					individual_level=jsonA13.get(0).toString();


					JSONArray jsonA24=jsonObjectUSer_meta.getJSONArray("address_line1");
					address1=jsonA24.get(0).toString();

					JSONArray jsonA25=jsonObjectUSer_meta.getJSONArray("address_line2");
					address2=jsonA25.get(0).toString();

					if(account_type.equalsIgnoreCase("individual")){
						JSONArray jsonA123=jsonObjectUSer_meta.getJSONArray("has_completed_tags");
						has_completed_tag=jsonA123.get(0).toString();

					}else{
						has_completed_tag="";
					}



					JSONArray jsonA15=jsonObjectUSer_meta.getJSONArray("verifiers_title");
					verifiers_title=jsonA15.get(0).toString();

					JSONArray jsonA16=jsonObjectUSer_meta.getJSONArray("verifiers_name");
					verifiers_name=jsonA16.get(0).toString();

					JSONArray jsonA17=jsonObjectUSer_meta.getJSONArray("verifiers_first_name");
					verifiers_first_name=jsonA17.get(0).toString();

					JSONArray jsonA18=jsonObjectUSer_meta.getJSONArray("verifiers_last_name");
					verifiers_last_name=jsonA18.get(0).toString();

					JSONArray jsonA19=jsonObjectUSer_meta.getJSONArray("verifiers_email");
					verifiers_email=jsonA19.get(0).toString();

					JSONArray jsonA20=jsonObjectUSer_meta.getJSONArray("verifiers_occupation");
					verifiers_occuption=jsonA20.get(0).toString();

					JSONArray jsonA21=jsonObjectUSer_meta.getJSONArray("verifiers_job_title");
					verifiers_job_title=jsonA21.get(0).toString();

					JSONArray jsonA22=jsonObjectUSer_meta.getJSONArray("verifiers_work_telephone");
					verifiers_work_tel=jsonA22.get(0).toString();

					JSONArray jsonA23=jsonObjectUSer_meta.getJSONArray("verifiers_company_name");
					verifiers_company_name=jsonA23.get(0).toString();

					JSONArray jsonA31=jsonObjectUSer_meta.getJSONArray("verifiers_work_address_street");
					verifiers_work_address=jsonA31.get(0).toString();

					JSONArray jsonA32=jsonObjectUSer_meta.getJSONArray("verifiers_work_address_street2");
					verifiers_work_address_2=jsonA32.get(0).toString();

					JSONArray jsonA33=jsonObjectUSer_meta.getJSONArray("verifiers_work_address_town");
					verifiers_work_address_town=jsonA33.get(0).toString();

					JSONArray jsonA34=jsonObjectUSer_meta.getJSONArray("verifiers_work_address_postcode");
					verifiers_work_address_postcode=jsonA34.get(0).toString();



					JSONArray jsonA26=jsonObjectUSer_meta.getJSONArray("town_city");
					town_city=jsonA26.get(0).toString();
					JSONArray jsonA27=jsonObjectUSer_meta.getJSONArray("county");
					country=jsonA27.get(0).toString();

					JSONArray jsonA14=jsonObjectUSer_meta.getJSONArray("country_code");
					country_code=jsonA14.get(0).toString();



					//email_id=jsonObjectUSer_meta.getString("nickname");



					//has_faceid = jsonObjectUSer_meta.getBoolean("has_faceid");
					/*is_model_created = obj.getString("is_model_created");

					identityID = obj.optString("identityID");
					member_id = obj.optString("member_id");
					JSONObject userData = obj.getJSONObject("data");
					userID = userData.getInt("ID");
					String first_name = obj.optString("first_name");
					String last_name = obj.optString("last_name");
					String dob = obj.optString("dob");
					String user_type = obj.optString("user_type");
					String type_id = obj.optString("type_id");

					Log.v("FaceID userID :", String.valueOf(userID));
					Log.v("FaceID res value :","res variable value of success field while registration:"+ login_response);

					JSONObject obj1 = obj.getJSONObject("data");
//					first_name = obj1.getString("first_name");
//					last_name = obj1.getString("last_name");
					id = obj1.getString("ID");
					*/


				}
			} catch (Exception e) {
				e.printStackTrace();
				/*runOnUiThread(new Runnable() {
					public void run() {
						AlertMessage(LoginActivity.this,
								"Your Internet Connection is Poor");
					}
				});*/

			}
			return responseText;
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			//pDialog.dismiss();
			if (result != null) {
				save_preference1();
				for (int i = 0; i < arrSubUsers.size(); i++) {
					if (m_id.equalsIgnoreCase(arrSubUsers.get(i).toString())) {
						isUser = true;
						expiryDate = arrSubUsersExpiryDate.get(i).toString();
						startDate = arrSubUsersStartDate.get(i).toString();
					}
				}
				new Get_UserID_Api().execute(m_id);
			}
		}
		}

	private void save_preference1() {

		{
			SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(MemberIdActivity.this);
			Editor edit = pref.edit();
			//edit.putString("identityID", identity_id);
			//Log.e("model_id", "[MIA save_preference_face] face_model_id " + identity_id);

			edit.putString("user_id", userID);
			edit.putString("first_name", first_name);
			edit.putString("last_name", last_name);
			edit.putString("dob", dob);

			edit.putString("checkedMemberID", member_id);
			edit.putString("checkedMemberLevel", individual_level);
			edit.putString("accountType", account_type);
			edit.putString("subuseronly", sub_user_only);
		/*edit.putString("startDate",startDate);
		edit.putString("expiryDate",expiryDate);*/
			edit.putString("userAddress1",address1);
			edit.putString("userAddress2",address2);
			edit.putString("userTown",town_city);
			edit.putString("userCounty",country);
			edit.putString("userCounty_code",country_code);
			edit.putString("userPostcode", postal_code);
			edit.putString("userDataAllow", "No");
			edit.putString("hasCompletedTag", has_completed_tag);


			edit.putString("director_name",verifiers_first_name);
			edit.putString("director_last_name", verifiers_last_name);
			edit.putString("director_dob",dob);
			edit.putString("userAddress1",verifiers_work_address);
			edit.putString("userAddress2",verifiers_work_address_2);
			edit.putString("userTown",verifiers_work_address_town);
			edit.putString("userCounty",verifiers_work_address_postcode);
			edit.putString("userDataAllow","No");
			//String strSubUser=arrSubUsers.toString().substring(0, arrSubUsers.toString().length()-1);
			//save the task list to preference
			/*edit.putInt("subUsers_size", arrSubUsers.size());

			for(int i=0;i<arrSubUsers.size();i++)
			{
				edit.remove("subUsers" + i);
				edit.putString("subUsers" + i, arrSubUsers.get(i));
				edit.remove("subUsersStartDate" + i);
				edit.putString("subUsersStartDate" + i, arrSubUsersStartDate.get(i));
				edit.remove("subUsersExpiryDate" + i);
				edit.putString("subUsersExpiryDate" + i, arrSubUsersExpiryDate.get(i));
			}*/
			edit.commit();
		}
	}
}

