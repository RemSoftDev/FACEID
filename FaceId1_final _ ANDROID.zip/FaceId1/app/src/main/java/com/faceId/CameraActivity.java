package com.faceId;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Formatter;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.ByteArrayBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.hardware.Camera;
import android.hardware.Camera.CameraInfo;
import android.hardware.Camera.PictureCallback;
import android.location.Location;
import android.location.LocationManager;
import android.media.CamcorderProfile;
import android.media.MediaMetadataRetriever;
import android.media.MediaRecorder;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.faceId.crashreport.ExceptionHandler;
import com.faceId.customprogressbar.ProgressWheel;
import com.faceId.scan.CDrawer;
import com.faceId.scan.CSampler;
import com.faceId.util.BaseActivity;
import com.faceId.util.MyConstant;

/*
 *  This class is for face Authentication it consists of all 
 *  parameters and components that required for...
 */


public class CameraActivity extends BaseActivity {

	private Camera mCamera;

	private CameraPreview mPreview;
	private PictureCallback mPicture;
	Camera.AutoFocusCallback mAutoFocusCallback1;
	private Context myContext;
	private FrameLayout cameraPreview, fram_bg;
	RelativeLayout rl_bg;
	private boolean cameraFront = false;

	/*private CDrawer.CDrawThread mDrawThread;
	private CDrawer mdrawer;
*/
	private Boolean recording = false;
	/*private View.OnClickListener listener;
	private Boolean m_bStart = Boolean.valueOf(false);

	private CSampler sampler;
*/
	ImageView sliding_image, changeCamera_iv, back_iv;
	Animation animationSlideDownIn, animationSlideDownOut;
	ImageView curSlidingImage;
	TextView scan_time_tv;

	int count = 0;

	boolean running = false;
	int progress = 0;
	boolean isNetworkAvailable = false;
	ProgressWheel pw_two;
	String model_id, filePath;
	ArrayList<String> filePathArray;
	ArrayList<String> base64Array;

	boolean isFront = true;
	boolean isCapture = false;
	ArrayList<Long> file_size;
	ArrayList<Integer> image_res, int_height, int_width;
	String status_response;

	//ArrayList<byte[]> bARRAY;
	ArrayList<byte[]> bARRAY_multi;

	ArrayList<String> score_face_array;

	private String stream_id;
	String closed;
	String authenticated;
	private String thoreshold;

	Timer timer;

	Chronometer chronometer;
	String base64_time , frams_time , service_time;
	int total_count;
	int img_sent_count , temp_sent_count = 0;
	Dialog dialog;

	String identity_created , user_name , tracer_id="authenticateUser";
	 
	Handler m_handler= null ;  
    Runnable m_handlerTask = null ;  
    boolean isTimerCalling = false;
   	private ProgressDialog pDialog;
	int status_code;
	ArrayList<String> md5_array = new ArrayList<String>();

	private int height;

	private int width;
	private String identityID;


	private String user_id;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(this));
		setContentView(R.layout.activity_camera);
		myContext = this;
		initialize();
		sliding_image = (ImageView) findViewById(R.id.slider_iv_1);
		scan_time_tv = (TextView) findViewById(R.id.scan_time_tv);
		fram_bg = (FrameLayout) findViewById(R.id.fram_bg);
		chronometer = (Chronometer) findViewById(R.id.chronometer1);
		chronometer.setFormat("%s");

		filePathArray = new ArrayList<String>();
		base64Array = new ArrayList<String>();
		animationSlideDownIn = AnimationUtils.loadAnimation(this, R.anim.slidedown_in);
		animationSlideDownOut = AnimationUtils.loadAnimation(this, R.anim.slidedown_out);
		curSlidingImage = sliding_image;

		getPref();
		getPref_threshold();
		getPref_identity();

		changeCamera_iv.setClickable(true);

		back_iv.setClickable(true);
		animationSlideDownIn.setAnimationListener(animationSlideInListener);
		animationSlideDownOut.setAnimationListener(animationSlideOutListener);

		file_size = new ArrayList<Long>();
		image_res = new ArrayList<Integer>();
		int_height = new ArrayList<Integer>();
		int_width = new ArrayList<Integer>();
		//bARRAY = new ArrayList<byte[]>();
		bARRAY_multi = new ArrayList<byte[]>();
		score_face_array = new ArrayList<String>();
		scan_time_tv.setVisibility(View.VISIBLE);
	}

	private boolean isNetworkAvailable() {
		ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
		return activeNetworkInfo != null && activeNetworkInfo.isConnected();
	}
	
	AnimationListener animationSlideInListener = new AnimationListener() {

		@Override
		public void onAnimationEnd(Animation arg0) {
			if (curSlidingImage == sliding_image) {
				if (!isDone) {
					sliding_image.startAnimation(animationSlideDownOut);
				}			
			}
		}

		@Override
		public void onAnimationRepeat(Animation animation) {
		}

		@Override
		public void onAnimationStart(Animation animation) {
		}
	};

	AnimationListener animationSlideOutListener = new AnimationListener() {

		@Override
		public void onAnimationEnd(Animation animation) {
			if (curSlidingImage == sliding_image) {
				curSlidingImage = sliding_image;
				if (!isDone) {
					sliding_image.startAnimation(animationSlideDownIn);
				}//				sliding_image.setVisibility(View.VISIBLE);
			}
		}

		@Override
		public void onAnimationRepeat(Animation animation) {
		}

		@Override
		public void onAnimationStart(Animation animation) {
		}
	};

	public void initialize() {
		cameraPreview = (FrameLayout) findViewById(R.id.camera_preview);
		mPreview = new CameraPreview(myContext, mCamera);
		cameraPreview.addView(mPreview);

		pw_two = (ProgressWheel) findViewById(R.id.progressBarTwo);

		changeCamera_iv = (ImageView) findViewById(R.id.changeCamera_iv);
		changeCamera_iv.setOnClickListener(switchCameraListener);

		back_iv = (ImageView) findViewById(R.id.back_iv);
		back_iv.setOnClickListener(backClickListner);
	}

	OnClickListener switchCameraListener = new OnClickListener() {
		@Override
		public void onClick(View v) {
			@SuppressWarnings("deprecation")
			int camerasNumber = Camera.getNumberOfCameras(); 
			if (camerasNumber > 1) {
				releaseCamera();
				chooseCamera();
			} else {
				Toast toast = Toast.makeText(myContext, "Sorry, your phone has only one camera!", Toast.LENGTH_LONG);
				toast.show();
			}
		}
	};

	OnClickListener backClickListner = new OnClickListener() {
		@Override
		public void onClick(View v) {
			
			onPause();
			progress = 361;
			pw_two.stopSpinning();
			pw_two.resetCount();
			isTimerCalling = true;

			sliding_image.setVisibility(View.INVISIBLE);
			if (isCapture) {

			} else if (!isCapture) {
				Intent i = new Intent(CameraActivity.this, MemberIdActivity.class);
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				startActivity(i);
				
				overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
				if (timer2 != null) {
					timer2.cancel();
					// timer2 = null;
					count = 0;
				}
				finish();
			}
		}
	};

	private MediaRecorder mediaRecorder;

	private ArrayList<Bitmap> bit_array = new ArrayList<Bitmap>();

	private int findFrontFacingCamera() {
		int cameraId = -1;
		// Search for the front facing camera
		int numberOfCameras = Camera.getNumberOfCameras();
		for (int i = 0; i < numberOfCameras; i++) {
			CameraInfo info = new CameraInfo();
			Camera.getCameraInfo(i, info);
			if (info.facing == CameraInfo.CAMERA_FACING_FRONT) {
				cameraId = i;
				cameraFront = true;
				break;
			}
		}
		return cameraId;
	}

	private int findBackFacingCamera() {
		int cameraId = -1;
		int numberOfCameras = Camera.getNumberOfCameras();
		for (int i = 0; i < numberOfCameras; i++) {
			CameraInfo info = new CameraInfo();
			Camera.getCameraInfo(i, info);
			if (info.facing == CameraInfo.CAMERA_FACING_BACK) {
				cameraId = i;
				cameraFront = false;
				break;
			}
		}
		return cameraId;
	}

	private void releaseCamera() {
		// stop and release camera
		if (mCamera != null) {
			mCamera.release();
			mCamera = null;
		}
	}

	public void getPref() {
		SharedPreferences shre = PreferenceManager.getDefaultSharedPreferences(this);
		identityID = shre.getString("identityID", "");
		Log.e("FaceID", "[CA getPref] gated_face_id: " + identityID);
	}

	private void startTimer1()
	{

		if (!prepareMediaRecorder())
		{
			Toast.makeText(CameraActivity.this, "Fail in prepareMediaRecorder()!\n - Ended -", Toast.LENGTH_LONG).show();
			finish();
		}
		// work on UiThread for better performance
		runOnUiThread(new Runnable() {
			public void run() {
				// If there are stories, add them to the table
				try {
					Thread.sleep(3000);
					mediaRecorder.start();
				} catch (final Exception ex) {
					// Log.i("---","Exception in thread");
				}
			}
		});

		recording = true;
		if( isTimerCalling == false)
		{
			
		new Handler().postDelayed(new Runnable() {
			@Override
			public void run() {
				MyConstant.bit_array.clear();
				try{
				mediaRecorder.stop(); // stop the recording
				releaseMediaRecorder(); // release the MediaRecorder object
				Thread.sleep(1000);
				}catch(Exception e)
				{
					e.printStackTrace();
				}
				recording = false; 
				bit_array.clear();
				isDone=true;
				// custom dialog
				//sliding_image.setVisibility(View.INVISIBLE);
				//sliding_image.setVisibility(View.GONE);
				synchronized (this) {
					try {
						wait(3000);

						runOnUiThread(new Runnable() {
							public void run() {
								sliding_image
										.setVisibility(View.INVISIBLE);
							}
						});
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
			
				
				if(!((Activity) CameraActivity.this).isFinishing())
				{
				    //show dialog
//					pDialog.show();

				}
				
				bit_array = getFrames(Environment.getExternalStorageDirectory() + "/myvideo.mp4");

				Log.i("FaceID", "[CA startTimer1] file_array " + bit_array.size());
				getBase64Images();	
			}
		}, 10000);
		}
     
	}
	
	private void callTimer(){
		  m_handler = new Handler();  
	        m_handlerTask = new Runnable()
	       {
	           @Override 
	           public void run() {
	                         // do something 
	        	   Log.i("Sys out", "in handler--------------");
	        	   MyConstant.bit_array.clear();
					try{
					mediaRecorder.stop(); // stop the recording
					releaseMediaRecorder(); // release the MediaRecorder object
					}catch(Exception e)
					{
					}
					recording = false; 
					bit_array.clear();
					// custom dialog
					sliding_image.setVisibility(View.INVISIBLE);
					sliding_image.setVisibility(View.GONE);

					dialog = new Dialog(CameraActivity.this);
					dialog.setContentView(R.layout.dialoge);
					dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
					
					if(!((Activity) CameraActivity.this).isFinishing())
					{
					    //show dialog
						dialog.show();
					}
					
					bit_array = getFrames("/sdcard/myvideo.mp4");
					Log.i("abcd", "file_array" + bit_array.size());
		        	Log.i("Sys out", "in handler-enddd--------------");

					getBase64Images();	
	                m_handler.postDelayed(m_handlerTask, 4000);    

	           }
	      };
	      m_handlerTask.run(); // call run
	}

	@SuppressLint("InlinedApi")
	private boolean prepareMediaRecorder() {

		mediaRecorder = new MediaRecorder();
		if (mCamera != null) {
			mCamera.unlock();
			mediaRecorder.setCamera(mCamera);
		}

		mediaRecorder.setAudioSource(MediaRecorder.AudioSource.CAMCORDER);
		mediaRecorder.setVideoSource(MediaRecorder.VideoSource.CAMERA);

		if (cameraFront) {
			if (height < 600 || width < 600) {
				mediaRecorder.setProfile(CamcorderProfile.get(CamcorderProfile.QUALITY_LOW));
			} else {
				mediaRecorder.setProfile(CamcorderProfile.get(CamcorderProfile.QUALITY_480P));
			}
		} else {
			mediaRecorder.setProfile(CamcorderProfile.get(CamcorderProfile.QUALITY_480P));
		}
		
//		mediaRecorder.setOutputFile("/sdcard/myvideo.mp4");
		mediaRecorder.setOutputFile(Environment.getExternalStorageDirectory() + "/myvideo.mp4");
		mediaRecorder.setMaxDuration(600000); // Set max duration 60 sec.
		mediaRecorder.setMaxFileSize(50000000); // Set max file size 50M
		if (!isFront) {
			mediaRecorder.setOrientationHint(90);
		} else if (isFront) {
			mediaRecorder.setOrientationHint(270);
		}

		try {
			mediaRecorder.prepare();
		} catch (IllegalStateException e) {
			releaseMediaRecorder();
			return false;
		} catch (IOException e) {
			releaseMediaRecorder();
			return false;
		}
		return true;

	}

	@TargetApi(Build.VERSION_CODES.GINGERBREAD_MR1)
	private ArrayList<Bitmap> getFrames(String path)
	{
		try {
			ArrayList<Bitmap> bArray1 = new ArrayList<Bitmap>();
			MediaMetadataRetriever mRetriever = new MediaMetadataRetriever();
			mRetriever.setDataSource(path);
			chronometer.start();
			
			for (int i = 0; i <=9000000; i = i + 1000000)
			{
				Bitmap bm = mRetriever.getFrameAtTime(i,MediaMetadataRetriever.OPTION_CLOSEST);
				if(bm!=null)
				{
					// resize and scalling bitmap to reduce size and width
					/*final int maxSize = 720;
					int outWidth;
					int outHeight;
					int inWidth = bm.getWidth();
					int inHeight = bm.getHeight();
					if(inWidth > inHeight){
						outWidth = maxSize;
						outHeight = (inHeight * maxSize) / inWidth;
					} else {
						outHeight = maxSize;
						outWidth = (inWidth * maxSize) / inHeight;
					}
					Bitmap resizedBitmap = Bitmap.createScaledBitmap(bm, outWidth, outHeight, false);
					bm.recycle();
					Log.i("FaceID", "[CA getFrames] messages: " + i + " " + bm);
					*/bArray1.add(bm);
				}else
				{
					// there are issue with video frame
				}


			}
			
			chronometer.stop();
			frams_time = chronometer.getText().toString();
			sliding_image.setVisibility(View.GONE);
			return bArray1;
		} catch (Exception e)
		{
			e.printStackTrace();
			return null;

		}
	}

	private void releaseMediaRecorder() {
		
		if (mediaRecorder != null) {
			mediaRecorder.reset(); // clear recorder configuration
			mediaRecorder.release(); // release the recorder object
			mediaRecorder = null;
			mCamera.lock(); // lock camera for later use
		}
	}

	Camera.AutoFocusCallback mAutoFocusCallback = new Camera.AutoFocusCallback() {
		@Override
		public void onAutoFocus(boolean success, final Camera camera) {
			// camera.takePicture(null, null, mPicture);

			timer2 = new Timer();
			timer2.scheduleAtFixedRate(new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@SuppressWarnings("deprecation")
						public void run() {
							if (mPicture != null && mCamera != null) {
								if (camera != null && mPicture != null) {
									isCapture = true;
									try {
										camera.takePicture(new Camera.ShutterCallback() {
											@Override
											public void onShutter() {


											}
										}, null, mPicture);

										filePathArray.add(filePath);
										Log.e("file_path", "file_path_abc" + filePathArray.size());
										
									} catch (Exception e) {
										Log.i("System out", "exception");
									}

								}
							}
						}
					});
					count++;

					if (count == 11) {
						timer2.cancel();
						timer2 = null;
						count = 0;

						getBase64Images();
					}
				}

			}, 0, 1000);

		}
	};

	private Timer timer2;

	private boolean isDone;

	private String identity;

	private LocationManager mLocationManager;

	public void chooseCamera() {
		if (!cameraFront) {

			int cameraId = findFrontFacingCamera();
			if (cameraId >= 0) {
				mCamera = Camera.open(cameraId);
				mCamera.setDisplayOrientation(90);
				mPicture = getPictureCallback();
				mPreview.refreshCamera(mCamera);
				isFront = true;
			}

		} else {
			/*int cameraId = findFrontFacingCamera();
			if (cameraId >= 0) {
				mCamera = Camera.open(cameraId);
				mCamera.setDisplayOrientation(90);
				mPicture = getPictureCallback();
				mPreview.refreshCamera(mCamera);
				isFront = true;
			}*/

			int cameraId = findBackFacingCamera();
			if (cameraId >= 0) {
				mCamera = Camera.open(cameraId);
				mCamera.setDisplayOrientation(90);
				mPicture = getPictureCallback();
				mPreview.refreshCamera(mCamera);
				isFront = false;


			}
		}
	}

	private PictureCallback getPictureCallback() {
		PictureCallback picture = new PictureCallback() {

			@Override
			public void onPictureTaken(byte[] data, Camera camera) {
				File pictureFile = getOutputMediaFile();

				if (pictureFile == null) {
					return;
				}
				try {
					// write the file
					FileOutputStream fos = new FileOutputStream(pictureFile);

					fos.write(data);
					fos.close();

				} catch (IOException e) {

				}
				// refresh camera to continue preview
				mPreview.refreshCamera(mCamera);
			}
		};
		return picture;
	}

	private File getOutputMediaFile() {
		// make a new file directory inside the "sdcard" folder
		File mediaStorageDir = new File("/sdcard/", "JCG Camera");

		// if this "JCGCamera folder does not exist
		if (!mediaStorageDir.exists()) {
			// if you cannot make this folder return
			if (!mediaStorageDir.mkdirs()) {
				return null;
			}
		}
		// take the current timeStamp
		String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
		File mediaFile;
		// and make a media file:
		mediaFile = new File(mediaStorageDir.getPath() + File.separator + "IMG_" + timeStamp + ".jpg");
		filePath = mediaStorageDir.getPath() + File.separator + "IMG_" + timeStamp + ".jpg";

		return mediaFile;
	}

	@Override
	protected void onPause() {
		super.onPause();
		isTimerCalling = true;
		releaseCamera();
		progress = 361;
		pw_two.stopSpinning();
		pw_two.resetCount();
		
		if (timer != null) {
			timer.cancel();
		}
		if (timer2 != null) {
			timer2.cancel();
		}

		try{
			mediaRecorder.stop(); // stop the recording
			releaseMediaRecorder(); // release the MediaRecorder object
			}catch(Exception e)
			{
			}
		
		sliding_image.setVisibility(View.INVISIBLE);
	}

	private boolean hasCamera(Context context) {
		if (context.getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA)) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public void onBackPressed() {}
	
	@Override
	protected void onResume() {
		super.onResume();
		Log.v("FaceID","[CA onResume] Scanning");

		if (!hasCamera(myContext)) {
			Toast toast = Toast.makeText(myContext, R.string.sorry_no_camera, Toast.LENGTH_LONG);
			toast.show();
			finish();
		}

		if (mCamera == null)
		{
			if (findFrontFacingCamera() < 0)
			{
				Toast.makeText(this, R.string.no_front_camera_found, Toast.LENGTH_LONG).show();
				changeCamera_iv.setVisibility(View.GONE);
			}

			scan_time_tv.setVisibility(View.VISIBLE);
			changeCamera_iv.setClickable(true);
			back_iv.setClickable(true);
			//mCamera = Camera.open(findBackFacingCamera());
			mCamera = Camera.open(findFrontFacingCamera());
			mCamera.setDisplayOrientation(90);
			mPicture = getPictureCallback();
			mPreview.refreshCamera(mCamera);

			Camera.Parameters parameters = mCamera.getParameters();
			Camera.Size size = parameters.getPictureSize();


			height = size.height;
			width = size.width;

			height=1080;
			width=720;


			float megaPix = (width * height) / 1024000 ;
			Log.i("FaceID", "[CA onResume] camera_mp: "  + megaPix + " " + height + " " + width);
			
			if (mCamera != null) {
				// TODO: uncomment this to make the camera be the rear-facing one
				/*
				if (isFront) {
					Log.i("FaceID Media", "Front facing camera in use");
					releaseCamera();
					chooseCamera();
				}
				*/

				final Runnable r = new Runnable() {
					public void run() {
						running = true;
						while (progress < 361)
						{
							pw_two.incrementProgress();
							progress++;
							try
							{
								Thread.sleep(15);

							} catch (InterruptedException e) {
								e.printStackTrace();
							}
						}
						running = false;

						runOnUiThread(new Runnable()
						{
							public void run()
							{
								sliding_image.startAnimation(animationSlideDownIn);
								sliding_image.setVisibility(View.VISIBLE);
								scan_time_tv.setVisibility(View.INVISIBLE);
								// fram_bg.setBackgroundColor(Color.TRANSPARENT);
								back_iv.setClickable(false);
								changeCamera_iv.setClickable(false);
								startTimer1();
							}
						});

					}
				};

				if (!running) {
					progress = 0;
					pw_two.resetCount();
					Thread s = new Thread(r);
					s.start();
				}
			}
		}
	}

	public void getBase64Images()
	{
		{
			// chronometer.start();
			//bARRAY = new ArrayList<byte[]>();
			ArrayList<String> md5_array = new ArrayList<String>();
			int framSize = bit_array.size();
			if (framSize < 8) {
				// need to print message here
			} else
				framSize = 8;

			for (int i = 0; i < framSize; i++) {
				Bitmap bm = bit_array.get(i);
				if (bm != null) {
					ByteArrayOutputStream baos = new ByteArrayOutputStream();
					Log.e("file_path", "file_path_abc_baos" + baos.toString());

					if (bm.compress(Bitmap.CompressFormat.JPEG, 80, baos)) {
						//MyConstant.bit_array.add(bm);
						//	save_sd_base(bm);
						Log.e("file_path", "file_path_abc_bitmap" + bm);
						byte[] bArray = baos.toByteArray();
						//bARRAY.add(bArray);
						String encodedString;
						if (bArray != null && bArray.length > 0) {
							encodedString = Base64.encodeToString(bArray, Base64.DEFAULT);
							Log.i("chika", "base64_encode" + " " + encodedString);
							base64Array.add(encodedString);
						}
						Log.e("file_path", "file_path_abc_base64" + base64Array.size());

					}
				} else {
					// bit map is null go for alternate
				}
			}
			filePathArray.clear();
			Log.i("abcd", "array_size_base" + base64Array.size());
			bit_array.clear();

			new VerifyFace_Model_Api().execute();

		}

	}
	
	public static void writeStringAsFile(final String fileContents, String fileName) {
        try {
            FileWriter out = new FileWriter(new File(Environment.getExternalStorageDirectory(), fileName));
            out.write(fileContents);
            out.close();
        } catch (IOException e) {
        }
    }
	
	public static String MD5_Hash(String s) {
		MessageDigest m = null;

		try {
			m = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}

		m.update(s.getBytes(), 0, s.length());
		String hash = new BigInteger(1, m.digest()).toString(16);
		return hash;
	}
	
	private void save_sd(Bitmap finalBitmap) {
		String root = Environment.getExternalStorageDirectory().toString();
		File myDir = new File(root + "/saved_imagesssss_gray_post_image");    
		myDir.mkdirs();
		Random generator = new Random();
		int n = 10000;
		n = generator.nextInt(n);
		String fname = "Image-"+ n +".jpg";
		File file = new File (myDir, fname);
		if (file.exists ()) file.delete (); 
		try {
		       FileOutputStream out = new FileOutputStream(file);
		       finalBitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
		       out.flush();
		       out.close();

		} catch (Exception e) {
		       e.printStackTrace();
		}
	}
	


	
	public ByteArrayBody decodeImageFile(byte[] array) {
		Calendar cal = Calendar.getInstance();
		ByteArrayBody bArrayBody = new ByteArrayBody(array, ".jpg" , "Image_"+cal.getTimeInMillis()+".jpg");

		return bArrayBody;
	}
	
	public void save_preference() {
		SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(CameraActivity.this);
		Editor edit = pref.edit();
		edit.putString("photo", base64Array.get(0));
		edit.commit();
	}

	public void getPref_threshold() {
		SharedPreferences shre = PreferenceManager.getDefaultSharedPreferences(this);
		thoreshold = shre.getString("thoreshold", "");
		user_name = shre.getString("user_details", "");
		tracer_id = shre.getString("tracer_id", "");
		user_id = shre.getString("user_id", "");
		
		Log.e("FaceID", "[CA getPref_threshold] threshold " + thoreshold + user_name + tracer_id);
	}
	
	public void getPref_identity() {
		SharedPreferences shre = PreferenceManager.getDefaultSharedPreferences(this);
		identity_created = shre.getString("identity_created", "");
		Log.e("FaceID", "[CA getPref_identity] identity_created" + identity_created);
	}


	public class VerifyFace_Model_Api extends AsyncTask<String, String, String> {

		private String identity_response;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			pDialog = ProgressDialog.show(CameraActivity.this, "","Please Wait");
			pDialog.setCancelable(false);
			pDialog.show();

		}

		@Override
		protected String doInBackground(String... params) {

			HttpParams httpParameters = new BasicHttpParams();
			HttpConnectionParams.setConnectionTimeout(httpParameters, 10000);
			HttpConnectionParams.setSoTimeout(httpParameters, 10000);
			HttpClient httpclient = new DefaultHttpClient();
			String responseText = null;
			HttpResponse response = null;
			HttpPost httppost = new HttpPost(MyConstant.LOGIN_URL);

			try
			{

				JSONObject jObjImages=new JSONObject();

				JSONArray jsonArray=new JSONArray();
				String[] images;
				/*for(int a=0; a<base64Array.size(); a++){
					images=base64Array.get(MyConstant.loopCount).toString().split(",");
				}*/

				images=base64Array.toString().split(",");
				for(int i=0; i<4; i++){
					String a="";
					if(images[i].contains("[")){
						a=images[i].replace("[", "");
					}
					else if(images[i].contains("]")){
						a=images[i].replace("]", "");
					}else{
						a=images[i].replace(" ", "");
					}

					jsonArray.put(i,a);
				}
				//jsonArray.put(0,base64Array);
				jObjImages.put("images", jsonArray);
				jObjImages.put("user_id", MemberIdActivity.user_id);
				//jObjImages.put("member_id", "4737");
				jObjImages.put("service", "ANDROID_APP");
				Log.v("JSONOBJECT", "DATA"+jObjImages);
				String a=jObjImages.toString()+"c1IaqR8Dp7L6sLVbq5b2VlsouTN0ezNAYYnmf0WGb6zbxT7P";
				String token=encryptPassword(a);
				Log.v("Token", "Token while Identity post" + token);
				List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(4);
				nameValuePairs.add(new BasicNameValuePair("request", "verifyFace"));
				nameValuePairs.add(new BasicNameValuePair("public_key", "faceid"));
				nameValuePairs.add(new BasicNameValuePair("token", token));
				nameValuePairs.add(new BasicNameValuePair("data", jObjImages.toString()));
				httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				String reqeust = MyConstant.LOGIN_URL;
				Log.v("requested URl", "reqeusted URL while Identity post:"
						+ reqeust);
				// Execute HTTP Post Request
				response = httpclient.execute(httppost);
				Log.v("Post Status", "Code: "
						+ response.getStatusLine().getStatusCode());
				HttpEntity entity = response.getEntity();
				responseText = EntityUtils.toString(entity);
				Log.v("Response", "Response while Identity post" + responseText);
				// Json Parsing

			} catch (Exception e) {
				e.printStackTrace();
				/*
				 * runOnUiThread(new Runnable() { public void run() {
				 * AlertMessage(LoginActivity.this,
				 * "Your Internet Connection is Poor"); } });
				 */
			}
			return responseText;
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);

			if (result != null) {
				JSONObject obj;
				MyConstant.loopCount += 1;
				pDialog.dismiss();

 				if (!result.contains("error"))
				{
					try {
						obj = (JSONObject) new JSONTokener(result).nextValue();
						//JSONObject jObj = obj.getJSONObject("response");
						//String status = jObj.getString("status");
						//String message = jObj.getString("message");
						String response = obj.getString("response");

							if (response.equalsIgnoreCase("success"))
							{
								String message = obj.getString("valid");
								//String[] strMessage=message.split(":");

								if (message.equalsIgnoreCase("true"))
								{
									//MyConstant.validImageCount = MyConstant.validImageCount + 1;
									//new VerifyFace_Model_Api().execute();

									MyConstant.validImageCount = 0;
									MyConstant.loopCount = 0;
									LatestBusinessCardActivity.isAuthenticated = "true";
									startActivity(new Intent(CameraActivity.this, LatestBusinessCardActivity.class));
									finish();


								}
								else
								{
									//Toast.makeText(getApplicationContext(), "Validation Failed", Toast.LENGTH_LONG).show();
									MyConstant.validImageCount = 0;
									MyConstant.loopCount = 0;
									LatestBusinessCardActivity.isAuthenticated = "false";
									startActivity(new Intent(CameraActivity.this, LatestBusinessCardActivity.class));
									finish();
								}

							}

					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} else {

					MyConstant.validImageCount = 0;
					MyConstant.loopCount = 0;
					LatestBusinessCardActivity.isAuthenticated = "false";
					startActivity(new Intent(CameraActivity.this, LatestBusinessCardActivity.class));
					finish();

				}
			}
			else {
				MyConstant.validImageCount = 0;
				MyConstant.loopCount = 0;
				LatestBusinessCardActivity.isAuthenticated = "false";
				startActivity(new Intent(CameraActivity.this, LatestBusinessCardActivity.class));
				finish();

			}
		}
	}
	private static String encryptPassword(String password)
	{
		String sha1 = "";
		try
		{
			MessageDigest crypt = MessageDigest.getInstance("SHA-1");
			crypt.reset();
			crypt.update(password.getBytes("UTF-8"));
			sha1 = byteToHex(crypt.digest());
		}
		catch(NoSuchAlgorithmException e)
		{
			e.printStackTrace();
		}
		catch(UnsupportedEncodingException e)
		{
			e.printStackTrace();
		}
		return sha1;
	}

	private static String byteToHex(final byte[] hash)
	{
		Formatter formatter = new Formatter();
		for (byte b : hash)
		{
			formatter.format("%02x", b);
		}
		String result = formatter.toString();
		formatter.close();
		return result;
	}
}