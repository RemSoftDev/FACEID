package com.faceId;

import java.io.IOException;
import android.Manifest;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.faceId.crashreport.ExceptionHandler;
import com.faceId.util.BaseActivity;
import com.faceId.util.MyConstant;

/*
 * This class is for Login Screen
 */

public class LoginActivity extends BaseActivity implements OnClickListener {

	LinearLayout signin_ll;
	EditText userid_et, password_et;
	String login_response;
	private ProgressBar progressbar_ll;
	String trader_name, status, id, model_id;
	TextView forgot_pw, register_tv;
	ProgressDialog pDialog;
	ImageView login_iv;

	private String first_name;
	private String last_name;
	String has_faceid="";
	String email_id;
	int userID=0;

	String is_model_created , trader_id , director1_name , director1_dob , identityID ;
	public String can_verify;
	public String member_id="";
	private String verifiers_work_address_postcode, verifiers_work_address_town, verifiers_work_address_2
			,verifiers_work_address;
	private String verifiers_company_name, verifiers_work_tel, verifiers_job_title, verifiers_occuption;
	private String verifiers_email, verifiers_last_name, verifiers_first_name;
	private String verifiers_title, verifiers_name, country_code, individual_level;
	private String verifies, account_type="";
	private String postal_code, dob, gender, tel_no, mobile_number;
	private String title;
	private String address1, address2, town_city, country;
	private String has_completed_tag="";
	private String sub_user_only;

	ArrayList<String> arrSubUsers=new ArrayList<>();
	ArrayList<String> arrSubUsersSTartDate=new ArrayList<>();
	ArrayList<String> arrSubUsersExpiryDate=new ArrayList<>();
	String[] strarr;
	private  String account_status="";
	private static final int REQUEST_CODE_CAMERA = 10;
	private static final int RECORD_REQUEST_CODE=99;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(this));
		initUi();

		signin_ll.setOnClickListener(this);
		register_tv.setOnClickListener(this);
		forgot_pw.setOnClickListener(this);
		insertDummyCameraWrapperPhoto();


	}
	protected void makeRequest() {
		ActivityCompat.requestPermissions(this,
				new String[]{Manifest.permission.RECORD_AUDIO},
				RECORD_REQUEST_CODE);
	}


	private void insertDummyCameraWrapperPhoto() {
		List<String> permissionsNeeded = new ArrayList<String>();

		final List<String> permissionsList = new ArrayList<String>();
		if (!addPermission(permissionsList, Manifest.permission.WRITE_EXTERNAL_STORAGE))
			permissionsNeeded.add("WRITE_EXTERNAL_STORAGE");
		if (!addPermission(permissionsList, Manifest.permission.CAMERA))
			permissionsNeeded.add("CAMERA");

		if (permissionsList.size() > 0) {
			if (permissionsNeeded.size() > 0) {
				// Need Rationale
				String message = "You need to grant access to " + permissionsNeeded.get(0);
				for (int i = 1; i < permissionsNeeded.size(); i++)
					message = message + ", " + permissionsNeeded.get(i);
				showMessageOKCancel(this, message,
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int which) {
								ActivityCompat.requestPermissions(LoginActivity.this,
										permissionsList.toArray(new String[permissionsList.size()]),
										REQUEST_CODE_CAMERA);
							}
						});
				return;
			}
			ActivityCompat.requestPermissions(this, permissionsList.toArray(new String[permissionsList.size()]),
					REQUEST_CODE_CAMERA);
			return;
		}else{


		}

	}
	private boolean addPermission(List<String> permissionsList, String permission) {
		if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
			permissionsList.add(permission);
			// Check for Rationale Option
			if (!ActivityCompat.shouldShowRequestPermissionRationale(this, permission))
				return false;
		}
		return true;
	}
	public static void showMessageOKCancel(Context context,String message, DialogInterface.OnClickListener okListener) {
		new AlertDialog.Builder(context)
				.setMessage(message)
				.setPositiveButton("OK", okListener)
				.setNegativeButton("Cancel", null)
				.create()
				.show();
	}

	@Override
	public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
		if (requestCode == REQUEST_CODE_CAMERA) {

			{
				Map<String, Integer> perms = new HashMap<String, Integer>();
				// Initial
				perms.put(Manifest.permission.WRITE_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
				perms.put(Manifest.permission.CAMERA, PackageManager.PERMISSION_GRANTED);
				// Fill with results
				for (int i = 0; i < permissions.length; i++)
					perms.put(permissions[i], grantResults[i]);
				// Check for ACCESS_FINE_LOCATION
				if (perms.get(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
						&& perms.get(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
					// All Permissions Granted
					int permission = ContextCompat.checkSelfPermission(this,
							Manifest.permission.RECORD_AUDIO);

					if (permission != PackageManager.PERMISSION_GRANTED) {
						Log.i("TAG", "Permission to record denied");
						if (ActivityCompat.shouldShowRequestPermissionRationale(this,
								Manifest.permission.RECORD_AUDIO)) {
							AlertDialog.Builder builder = new AlertDialog.Builder(this);
							builder.setMessage("Permission to access the microphone is required for this app to record audio.")
									.setTitle("Permission required");

							builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {

								public void onClick(DialogInterface dialog, int id) {
									Log.i("TAG", "Clicked");
									makeRequest();
								}
							});

							AlertDialog dialog = builder.create();
							dialog.show();
						} else {
							makeRequest();
						}

					}
				} else {
					// Permission Denied
					Toast.makeText(this, "Some Permission is Denied", Toast.LENGTH_SHORT)
							.show();
				}
			}
		}
		else if(requestCode==RECORD_REQUEST_CODE){



				if (grantResults.length == 0
						|| grantResults[0] !=
						PackageManager.PERMISSION_GRANTED) {

					Log.i("TAG", "Permission has been denied by user");
				} else {
					Log.i("TAG", "Permission has been granted by user");
				}
				return;


		}
		else {
			super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		}
	}
	private void initUi() {
		signin_ll = (LinearLayout) findViewById(R.id.signin_ll);
		userid_et = (EditText) findViewById(R.id.userid_et);
		password_et = (EditText) findViewById(R.id.password_et);
		forgot_pw = (TextView) findViewById(R.id.forgot_pw);
		register_tv = (TextView) findViewById(R.id.register_tv);
		login_iv = (ImageView) findViewById(R.id.login_iv);
		login_iv.setVisibility(View.GONE);
		userid_et.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				userid_et.setHint(null);
				password_et.setHint(null);
			}
		});

		password_et.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before,
									  int count) {
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
										  int after) {
			}

			@Override
			public void afterTextChanged(Editable s) {
				String email_id = userid_et.getText().toString().trim();
//				boolean isEmailValid = isValidEmail(email_id);

//				if (isEmailValid) {
				if (password_et.getText().toString().trim() != "") {
					// Commenting this line out because showing the tick mark icon throws off the alignment and it doesn't appear to be needed
					// since the previous developer seems to have commented out a check for valid email
					// login_iv.setVisibility(View.VISIBLE);
//					}
				}
			}
		});
	}

	@Override
	public void onClick(View v) {

		if (v == signin_ll) {
			String email_id = userid_et.getText().toString().trim();
			boolean isEmailValid = isValidEmail(email_id);

//			if (isEmailValid) {
			
			if (email_id.equalsIgnoreCase("") && password_et.getText().toString().equalsIgnoreCase("")) {
				Toast.makeText(LoginActivity.this, "Please enter details", Toast.LENGTH_SHORT).show();
			}else {
				if (password_et.getText().toString().trim() != "") {
					
					boolean isNetworkAvailable = isNetworkAvailable();
					if (isNetworkAvailable) {
						new login_Api().execute();
					} else {
						Toast t= Toast.makeText(LoginActivity.this,
								"Please Check Your Internet Connection",
								Toast.LENGTH_LONG);
						t.show();
					}
				} else {
					Toast.makeText(LoginActivity.this, "Please enter password",
							Toast.LENGTH_LONG).show();
				}
				/*} else {
				Toast.makeText(LoginActivity.this,"Please Enter Proper Email-id", Toast.LENGTH_LONG).show();
			}*/
			}
			
		} else if (v == forgot_pw) {
			WebviewActivity.fromWhere = "forgot Password";
			startActivity(new Intent(LoginActivity.this, WebviewActivity.class));
			overridePendingTransition(R.anim.slide_in, R.anim.slide_out);

		} else if (v == register_tv) {
			WebviewActivity.fromWhere = "register";
			startActivity(new Intent(LoginActivity.this, WebviewActivity.class));
			overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
		}
	}

	private boolean isNetworkAvailable() {
		ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
		return activeNetworkInfo != null && activeNetworkInfo.isConnected();
	}

	public final static boolean isValidEmail(CharSequence target) {
		if (target == null) {
			return false;
		} else {
			return android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
		}
	}

	private static String encryptPassword(String password)
	{
		String sha1 = "";
		try
		{
			MessageDigest crypt = MessageDigest.getInstance("SHA-1");
			crypt.reset();
			crypt.update(password.getBytes("UTF-8"));
			sha1 = byteToHex(crypt.digest());
		}
		catch(NoSuchAlgorithmException e)
		{
			e.printStackTrace();
		}
		catch(UnsupportedEncodingException e)
		{
			e.printStackTrace();
		}
		return sha1;
	}

	private static String byteToHex(final byte[] hash)
	{
		Formatter formatter = new Formatter();
		for (byte b : hash)
		{
			formatter.format("%02x", b);
		}
		String result = formatter.toString();
		formatter.close();
		return result;
	}
	public static String SHA1(String text) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		MessageDigest md = MessageDigest.getInstance("SHA-1");
		byte[] sha1hash = new byte[40];
		md.update(text.getBytes("iso-8859-1"), 0, text.length());
		sha1hash = md.digest();
		return convertToHex(sha1hash);
	}
	private static String convertToHex(byte[] data) {
		StringBuffer buf = new StringBuffer();
		int length = data.length;
		for(int i = 0; i < length; ++i) {
			int halfbyte = (data[i] >>> 4) & 0x0F;
			int two_halfs = 0;
			do {
				if((0 <= halfbyte) && (halfbyte <= 9))
					buf.append((char) ('0' + halfbyte));
				else
					buf.append((char) ('a' + (halfbyte - 10)));
				halfbyte = data[i] & 0x0F;
			}
			while(++two_halfs < 1);
		}
		return buf.toString();
	}
	public class login_Api extends AsyncTask<String, String, String> {

		String user_id, password;
		@Override
		protected void onPreExecute() {
			super.onPreExecute();

			pDialog = ProgressDialog.show(LoginActivity.this, "", "Please Wait");
			user_id= userid_et.getText().toString().trim();
			password = password_et.getText().toString().trim();
		}

		@Override
		protected String doInBackground(String... params) {

			HttpParams httpParameters = new BasicHttpParams();
			HttpConnectionParams.setConnectionTimeout(httpParameters, 10000);
			HttpConnectionParams.setSoTimeout(httpParameters, 10000);
			HttpClient httpclient = new DefaultHttpClient();
			String responseText = null;
			HttpResponse response = null;
			HttpPost httppost = new HttpPost(MyConstant.LOGIN_URL);

			JSONArray jArr=new JSONArray();

			try {
				JSONObject jObj=new JSONObject();
				jObj.put("email", user_id);
				jObj.put("password", password);
				//jObj.put("private", "c1IaqR8Dp7L6sLVbq5b2VlsouTN0ezNAYYnmf0WGb6zbxT7P");
				//jArr.put(jObj);

				String a=jObj.toString()+"c1IaqR8Dp7L6sLVbq5b2VlsouTN0ezNAYYnmf0WGb6zbxT7P";

				String token=encryptPassword(a);
				//5019906bf46dd9302c6deae5a04d41e6f1b84bdc


				List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(4);
				nameValuePairs.add(new BasicNameValuePair("request", "authenticateUser"));
				nameValuePairs.add(new BasicNameValuePair("data",jObj.toString()));
				nameValuePairs.add(new BasicNameValuePair("token",token));
				nameValuePairs.add(new BasicNameValuePair("public_key","faceid"));
				httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				String request = MyConstant.LOGIN_URL + "UserValidate" + user_id + " : " + password;
				Log.v("FaceID: requested URl", "requested URL while LoginProcess :" + request);
				// Execute HTTP Post Request
				response = httpclient.execute(httppost);
				Log.v("FaceID Post Status", "Code: " + response.getStatusLine().getStatusCode());
				HttpEntity entity = response.getEntity();
				responseText = EntityUtils.toString(entity);
				Log.v("FaceID Response", "Response while Login" + responseText);
				// Json Parsing
				JSONObject obj = (JSONObject) new JSONTokener(responseText).nextValue();

				if(obj.has("user_id"))
				{
					String userid= obj.getString("user_id");
					userID=Integer.parseInt(userid);
				}


				JSONObject jsonObjectUSer_meta=obj.getJSONObject("user_meta");


				JSONArray jsonAuthenticatedUser=obj.getJSONArray("sub_users");
				arrSubUsers=new ArrayList<>();
				arrSubUsersSTartDate=new ArrayList<>();
				arrSubUsersExpiryDate=new ArrayList<>();
				for(int i=0; i<jsonAuthenticatedUser.length(); i++){
					//arrSubUsers.add(jsonAuthenticatedUser.get(i).toString());
					JSONObject jObjSubUsers=jsonAuthenticatedUser.getJSONObject(i);
					arrSubUsers.add(jObjSubUsers.get("member_id").toString());
					arrSubUsersSTartDate.add(jObjSubUsers.get("start_date").toString());
					arrSubUsersExpiryDate.add(jObjSubUsers.get("expiry_date").toString());


				}

				/*login_response = obj.getString("status");
				Log.v("FaceID login_response ",login_response);
				*/
				
				
				if (!jsonObjectUSer_meta.toString().equals(" ")) {

					//JSONArray jsonArray=jsonObjectUSer_meta.getJSONArray("has_faceid");
					//has_faceid=jsonArray.get(0).toString();

					JSONArray jsonA=jsonObjectUSer_meta.getJSONArray("nickname");
					email_id=jsonA.get(0).toString();


					JSONArray jsonA1=jsonObjectUSer_meta.getJSONArray("first_name");
					first_name=jsonA1.get(0).toString();

					JSONArray jsonA2=jsonObjectUSer_meta.getJSONArray("last_name");
					last_name=jsonA2.get(0).toString();

					JSONArray jsonA3=jsonObjectUSer_meta.getJSONArray("title");
					title=jsonA3.get(0).toString();

					JSONArray jsonA4=jsonObjectUSer_meta.getJSONArray("mobile_number");
					mobile_number=jsonA4.get(0).toString();

					JSONArray jsonA5=jsonObjectUSer_meta.getJSONArray("formatted_phone_number");
					tel_no=jsonA5.get(0).toString();

					JSONArray jsonA6=jsonObjectUSer_meta.getJSONArray("gender");
					gender=jsonA6.get(0).toString();

					JSONArray jsonA7=jsonObjectUSer_meta.getJSONArray("dob");
					dob=jsonA7.get(0).toString();

					JSONArray jsonA8=jsonObjectUSer_meta.getJSONArray("post_code");
					postal_code=jsonA8.get(0).toString();

					JSONArray jsonA9=jsonObjectUSer_meta.getJSONArray("account_type");
					account_type=jsonA9.get(0).toString();

					JSONArray jsonA10=jsonObjectUSer_meta.getJSONArray("verifies");
					verifies=jsonA10.get(0).toString();

					JSONArray jsonsubUserOnly=jsonObjectUSer_meta.getJSONArray("sub_users_only");
					sub_user_only=jsonsubUserOnly.get(0).toString();

					JSONArray jsonA11=jsonObjectUSer_meta.getJSONArray("member_id");
					member_id=jsonA11.get(0).toString();

					JSONArray jsonA12=jsonObjectUSer_meta.getJSONArray("has_faceid");
					has_faceid=jsonA12.get(0).toString();

					JSONArray jsonA13=jsonObjectUSer_meta.getJSONArray("individual_level");
					individual_level=jsonA13.get(0).toString();


					JSONArray jsonA24=jsonObjectUSer_meta.getJSONArray("address_line1");
					address1=jsonA24.get(0).toString();

					JSONArray jsonA25=jsonObjectUSer_meta.getJSONArray("address_line2");
					address2=jsonA25.get(0).toString();

					if(account_type.equalsIgnoreCase("individual")){
						JSONArray jsonA123=jsonObjectUSer_meta.getJSONArray("has_completed_tags");
						has_completed_tag=jsonA123.get(0).toString();

					}else{
						has_completed_tag="";
					}
					JSONArray jsonA124 = jsonObjectUSer_meta.getJSONArray("account_status");
					account_status = jsonA124.get(0).toString();


					JSONArray jsonA15=jsonObjectUSer_meta.getJSONArray("verifiers_title");
					verifiers_title=jsonA15.get(0).toString();

					JSONArray jsonA16=jsonObjectUSer_meta.getJSONArray("verifiers_name");
					verifiers_name=jsonA16.get(0).toString();

					JSONArray jsonA17=jsonObjectUSer_meta.getJSONArray("verifiers_first_name");
					verifiers_first_name=jsonA17.get(0).toString();

					JSONArray jsonA18=jsonObjectUSer_meta.getJSONArray("verifiers_last_name");
					verifiers_last_name=jsonA18.get(0).toString();

					JSONArray jsonA19=jsonObjectUSer_meta.getJSONArray("verifiers_email");
					verifiers_email=jsonA19.get(0).toString();

					JSONArray jsonA20=jsonObjectUSer_meta.getJSONArray("verifiers_occupation");
					verifiers_occuption=jsonA20.get(0).toString();

					JSONArray jsonA21=jsonObjectUSer_meta.getJSONArray("verifiers_job_title");
					verifiers_job_title=jsonA21.get(0).toString();

					JSONArray jsonA22=jsonObjectUSer_meta.getJSONArray("verifiers_work_telephone");
					verifiers_work_tel=jsonA22.get(0).toString();

					JSONArray jsonA23=jsonObjectUSer_meta.getJSONArray("verifiers_company_name");
					verifiers_company_name=jsonA23.get(0).toString();

					JSONArray jsonA31=jsonObjectUSer_meta.getJSONArray("verifiers_work_address_street");
					verifiers_work_address=jsonA31.get(0).toString();

					JSONArray jsonA32=jsonObjectUSer_meta.getJSONArray("verifiers_work_address_street2");
					verifiers_work_address_2=jsonA32.get(0).toString();

					JSONArray jsonA33=jsonObjectUSer_meta.getJSONArray("verifiers_work_address_town");
					verifiers_work_address_town=jsonA33.get(0).toString();

					JSONArray jsonA34=jsonObjectUSer_meta.getJSONArray("verifiers_work_address_postcode");
					verifiers_work_address_postcode=jsonA34.get(0).toString();



					JSONArray jsonA26=jsonObjectUSer_meta.getJSONArray("town_city");
					town_city=jsonA26.get(0).toString();
					JSONArray jsonA27=jsonObjectUSer_meta.getJSONArray("county");
					country=jsonA27.get(0).toString();

					JSONArray jsonA14=jsonObjectUSer_meta.getJSONArray("country_code");
					country_code=jsonA14.get(0).toString();



					//email_id=jsonObjectUSer_meta.getString("nickname");



					//has_faceid = jsonObjectUSer_meta.getBoolean("has_faceid");
					/*is_model_created = obj.getString("is_model_created");
					
					identityID = obj.optString("identityID");
					member_id = obj.optString("member_id");
					JSONObject userData = obj.getJSONObject("data");
					userID = userData.getInt("ID");
					String first_name = obj.optString("first_name");
					String last_name = obj.optString("last_name");
					String dob = obj.optString("dob");
					String user_type = obj.optString("user_type");
					String type_id = obj.optString("type_id");
					
					Log.v("FaceID userID :", String.valueOf(userID));
					Log.v("FaceID res value :","res variable value of success field while registration:"+ login_response);
					
					JSONObject obj1 = obj.getJSONObject("data");
//					first_name = obj1.getString("first_name");
//					last_name = obj1.getString("last_name");
					id = obj1.getString("ID");
					*/
					
					
				}
			} catch (Exception e) {
				e.printStackTrace();
				/*runOnUiThread(new Runnable() {
					public void run() {
						AlertMessage(LoginActivity.this,
								"Your Internet Connection is Poor");
					}
				});*/

			}
			return responseText;
		}
		
		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			pDialog.dismiss();
			if (result != null) {

				if (userID!=0) {

					if (account_type.equalsIgnoreCase("individual")) {

						if (has_faceid.equalsIgnoreCase("Yes")) {

							if (has_completed_tag.equalsIgnoreCase("")) {
								save_preference();
								startActivity(new Intent(LoginActivity.this, CreateModelActivityFromCamera.class));

								overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
								finish();

							}
							else if (account_status.equalsIgnoreCase("Pending")) {
								new AlertDialog.Builder(LoginActivity.this)
										.setTitle("FACE.ID")
										.setMessage("This account has not yet been set live by admin.")
										.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
											public void onClick(DialogInterface dialog, int which) {
												// continue with delete

											}
										})
										.setIcon(R.drawable.ic_launcher)
										.show();

							}
							else if (has_completed_tag.equalsIgnoreCase("Yes")) {
								save_preference();
								startActivity(new Intent(LoginActivity.this, MemberIdActivity.class));

								overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
								finish();
							}


						} else if (has_faceid.equalsIgnoreCase("No")&&account_status.equalsIgnoreCase("active")) {
							save_preference();
							startActivity(new Intent(LoginActivity.this,
									MemberIdActivity.class));

							overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
							finish();
						}else{
							new AlertDialog.Builder(LoginActivity.this)
									.setTitle("FACE.ID")
									.setMessage("This account has not yet been set live by admin.")
									.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
										public void onClick(DialogInterface dialog, int which) {
											// continue with delete

										}
									})
									.setIcon(R.drawable.ic_launcher)
									.show();
						}

					} else if (account_type.equalsIgnoreCase("Business")&&account_status.equalsIgnoreCase("Active")) {
						save_preference();
						startActivity(new Intent(LoginActivity.this, MemberIdActivity.class));
						overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
						finish();

					}else{
						new AlertDialog.Builder(LoginActivity.this)
								.setTitle("FACE.ID")
								.setMessage("This account has not yet been set live by admin.")
								.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
									public void onClick(DialogInterface dialog, int which) {
										// continue with delete

									}
								})
								.setIcon(R.drawable.ic_launcher)
								.show();

					}


				} else {
					Toast.makeText(LoginActivity.this,
							"Enter Proper User Details", Toast.LENGTH_LONG)
							.show();
				}

			}else{
				Toast.makeText(LoginActivity.this,
						"Connection Timeout? Please try again.", Toast.LENGTH_LONG)
						.show();
			}
			/*if(has_completed_tag.equalsIgnoreCase("Yes")) {

				save_preference();
				startActivity(new Intent(LoginActivity.this,MemberIdActivity.class));
				overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
				finish();

			}else{
				save_preference();
				startActivity(new Intent(LoginActivity.this,CreateModelActivityFromCamera.class));
				overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
				finish();
			}*/
		}
	}

	public void AlertMessage(final Activity _this, String msg) {
		AlertDialog.Builder builder = new AlertDialog.Builder(_this);
		builder.setMessage(msg);
		builder.setPositiveButton("OK", null);
		AlertDialog alert11 = builder.show();
		TextView messageText = (TextView) alert11.findViewById(android.R.id.message);
		messageText.setGravity(Gravity.CENTER);
		alert11.show();
	}

	public void save_preference() {
		SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(LoginActivity.this);
		Editor edit = pref.edit();
		//edit.putString("identityID", identity_id);
		//Log.e("model_id", "[MIA save_preference_face] face_model_id " + identity_id);
		edit.putString("email_id", userid_et.getText().toString());
		edit.putString("pass", password_et.getText().toString());
		edit.putString("user_id", ""+userID);
		edit.putString("first_name", first_name);
		edit.putString("last_name", last_name);
		edit.putString("dob", dob);

		edit.putString("checkedMemberID", member_id);
		edit.putString("checkedMemberLevel", individual_level);
		edit.putString("accountType", account_type);
		edit.putString("subuseronly", sub_user_only);
		/*edit.putString("startDate",startDate);
		edit.putString("expiryDate",expiryDate);*/
		edit.putString("userAddress1",address1);
		edit.putString("userAddress2",address2);
		edit.putString("userTown",town_city);
		edit.putString("userCounty",country);
		edit.putString("userCounty_code",country_code);
		edit.putString("userPostcode", postal_code);
		edit.putString("userDataAllow", "No");
		edit.putString("has_faceid", has_faceid);

		edit.putString("hasCompletedTag", has_completed_tag);


		edit.putString("director_name",verifiers_first_name);
		edit.putString("director_last_name", verifiers_last_name);
		edit.putString("director_dob",dob);
		edit.putString("userAddress1",verifiers_work_address);
		edit.putString("userAddress2",verifiers_work_address_2);
		edit.putString("userTown",verifiers_work_address_town);
		edit.putString("userCounty",verifiers_work_address_postcode);
		edit.putString("userDataAllow","No");
		//String strSubUser=arrSubUsers.toString().substring(0, arrSubUsers.toString().length()-1);
		//save the task list to preference
		edit.putInt("subUsers_size", arrSubUsers.size());

		for(int i=0;i<arrSubUsers.size();i++)
		{
			edit.remove("subUsers" + i);
			edit.putString("subUsers" + i, arrSubUsers.get(i));
			edit.remove("subUsersStartDate" + i);
			edit.putString("subUsersStartDate" + i, arrSubUsersSTartDate.get(i));
			edit.remove("subUsersExpiryDate" + i);
			edit.putString("subUsersExpiryDate" + i, arrSubUsersExpiryDate.get(i));
		}
		edit.commit();
	}

	public void save_preference_voice() {
		SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(LoginActivity.this);
		Editor edit = pref.edit();
		//edit.putString("identities_data_voice", identity_id_voice);
		edit.putString("director_name", first_name);
		edit.putString("director_dob", director1_dob);
		//Log.e("model_id", "voice_model_id" + identity_id_voice);
		edit.commit();
	}
	/*public void save_preference()
	{
		SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(LoginActivity.this);
		Editor edit = pref.edit();
		edit.putString("email_id", userid_et.getText().toString());
		//edit.putString("user_details", userid_et.getText().toString());
		edit.putString("user_id", ""+userID);
		*//*edit.putString("userID", String.valueOf(userID));
		edit.putString("is_model_created", is_model_created);
		edit.putString("trader_id", trader_id);
		edit.putString("identityID", identityID);
		edit.putString("identityID_login", identityID);
		edit.putString("member_id_login_act", member_id);
		*//*
		edit.commit();
	}*/

	@Override
	public void onBackPressed() {
		super.onBackPressed();
		/*Intent startMain = new Intent(Intent.ACTION_MAIN);
		startMain.addCategory(Intent.CATEGORY_HOME);
		startMain.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		startMain.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
		startActivity(startMain);
		finish();*/
		finish();
		System.exit(0);

	}

}
